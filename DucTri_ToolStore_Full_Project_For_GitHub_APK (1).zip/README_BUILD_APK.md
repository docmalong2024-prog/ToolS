# Hướng Dẫn Build Android APK Bằng GitHub Actions (DucTri ToolStore)

## 🌟 3 Bước Tạo File APK Chuẩn:
1. Giải nén hoặc đẩy (push) toàn bộ thư mục này lên GitHub Repository của bạn.
2. Vào tab **Actions** trên GitHub -> Chọn workflow **"Build Android APK"** -> Bấm **Run workflow**.
3. Chờ 2-3 phút, vào mục **Artifacts** tải file **DucTri-ToolStore-Release-APK** (.apk) về cài đặt lên điện thoại Android / Giả lập!

Hỗ trợ: DucTri (Zalo: 0826130621)
