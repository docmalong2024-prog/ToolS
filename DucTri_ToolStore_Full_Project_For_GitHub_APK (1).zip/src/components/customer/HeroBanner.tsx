import React from 'react';
import { useSystem } from '../../contexts/SystemContext';
import {
  Zap,
  ShieldCheck,
  Cpu,
  Layers,
  Sparkles,
  TrendingUp,
  Search,
  CheckCircle2,
  Lock,
  ArrowRight,
  Flame,
  Calculator,
  Activity,
  Server,
  Download
} from 'lucide-react';

interface HeroBannerProps {
  onSearchChange?: (query: string) => void;
  searchQuery?: string;
  onSelectCategory?: (category: string) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onSearchChange,
  searchQuery = '',
  onSelectCategory,
}) => {
  const { settings, setActiveView, setIsKeyValidatorOpen, openKeyValidator, setIsRoiModalOpen, setIsAppDownloadModalOpen } = useSystem();

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-[#0a0a0a] via-[#050505] to-[#050505] border-b border-white/10 py-12 md:py-20 px-4 sm:px-6 lg:px-8">
      {/* Background Cyber Grid Glow */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

      {/* Floating Glowing Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-72 h-72 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-5xl mx-auto text-center space-y-6">
        {/* Top Tag Pill & Live Server Status */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {/* Server Status Live */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-mono">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span>Server Key: <strong>Hoạt Động 99.99%</strong> (Ping 12ms)</span>
          </div>

          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-mono font-medium shadow-[0_0_20px_rgba(37,99,235,0.15)]">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>Cấp Key & Link Tải Tự Động Trong 3 Giây</span>
          </div>

          <a
            href="https://zalo.me/0826130621"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-white/10 hover:border-blue-500/40 text-slate-300 hover:text-white text-xs font-mono transition-all shadow"
          >
            <span>App By DucTri • Zalo: <strong className="text-blue-400">0826130621</strong></span>
          </a>
        </div>

        {/* Hero Title */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight font-sans">
          Kho Tool & Key Bản Quyền{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-slate-100">
            Chuyên Nghiệp Số 1
          </span>
        </h1>

        {/* Hero Subtitle */}
        <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-400 leading-relaxed">
          Tối ưu hóa doanh số MMO, tự động hóa TikTok/Facebook/Shopee, bot cào data và giải pháp AI thông minh. Bảo hành 1-1, hỗ trợ cài đặt và đổi máy tính (HWID Reset) linh hoạt.
        </p>

        {/* Search Bar Input on Hero */}
        <div className="max-w-2xl mx-auto pt-2">
          <div className="relative flex items-center shadow-[0_0_30px_rgba(0,0,0,0.8)] rounded-2xl bg-[#111111] border border-white/10 p-1.5 backdrop-blur-md">
            <Search className="w-5 h-5 text-blue-400 ml-3 shrink-0" />
            <input
              type="text"
              placeholder="Nhập tên tool (VD: TikTok, Shopee Sniper, AI Video, Facebook, Crypto)..."
              value={searchQuery}
              onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
              className="w-full bg-transparent px-3 py-2 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none"
            />
            <button
              onClick={() => setActiveView('catalog')}
              className="px-5 py-2.5 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] transition-all shrink-0 flex items-center gap-1"
            >
              <span>Tìm Kiếm</span>
              <ArrowRight className="w-3.5 h-3.5 hidden sm:inline" />
            </button>
          </div>
        </div>

        {/* Hot Search Category Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-xs">
          <span className="text-slate-500 flex items-center gap-1 font-semibold">
            <Flame className="w-3.5 h-3.5 text-rose-500" />
            Gợi ý hot:
          </span>
          <button
            onClick={() => onSelectCategory && onSelectCategory('marketing_mmo')}
            className="px-3 py-1 rounded-full bg-[#111111] hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all font-mono"
          >
            #TikTok & Facebook Master
          </button>
          <button
            onClick={() => onSelectCategory && onSelectCategory('automation')}
            className="px-3 py-1 rounded-full bg-[#111111] hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all font-mono"
          >
            #Shopee Sniper 0.01s
          </button>
          <button
            onClick={() => onSelectCategory && onSelectCategory('ai_data')}
            className="px-3 py-1 rounded-full bg-[#111111] hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all font-mono"
          >
            #AI Video CapCut Auto
          </button>
          <button
            onClick={() => setIsAppDownloadModalOpen(true)}
            className="px-4 py-1.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 hover:bg-cyan-500 hover:text-slate-950 transition-all font-mono font-bold flex items-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.3)] animate-pulse"
          >
            <Download className="w-3.5 h-3.5" />
            <span>📥 Tải File App (Bản Thử Nghiệm)</span>
          </button>
          <button
            onClick={() => openKeyValidator('activate')}
            className="px-3.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/25 transition-all font-mono font-bold flex items-center gap-1 shadow-[0_0_10px_rgba(16,185,129,0.2)]"
          >
            <Zap className="w-3.5 h-3.5 fill-emerald-400 text-emerald-400" />
            <span>⚡ Kích Hoạt Key</span>
          </button>
          <button
            onClick={() => setIsRoiModalOpen(true)}
            className="px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 hover:bg-purple-500/20 transition-all font-mono flex items-center gap-1"
          >
            <Calculator className="w-3 h-3" />
            <span>📊 Bảng Tính Tiết Kiệm (ROI)</span>
          </button>
          <button
            onClick={() => openKeyValidator('validate')}
            className="px-3 py-1 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/30 hover:bg-blue-500/20 transition-all font-mono"
          >
            🔍 Tra cứu Key
          </button>
        </div>

        {/* Exclusive Preview Glassmorphism App Download Card */}
        <div className="pt-2 max-w-4xl mx-auto">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-cyan-950/40 via-[#06111f]/60 to-blue-950/40 border border-cyan-500/30 backdrop-blur-xl p-4 sm:p-5 shadow-[0_0_40px_rgba(6,182,212,0.15)] flex flex-col sm:flex-row items-center justify-between gap-4 text-left group">
            <div className="flex items-center gap-4 min-w-0">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300 shrink-0 shadow-[0_0_20px_rgba(6,182,212,0.2)]">
                <Download className="w-6 h-6 animate-pulse" />
              </div>
              <div className="min-w-0 space-y-0.5">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-bold text-white tracking-wide">
                    DucTri ToolStore Client Desktop (Bản Thử Nghiệm)
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">
                    ★ Chỉ có trên bản thử nghiệm này
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  Tải ngay tệp cài đặt App Client để tự động phát hiện mã máy HWID, auto-update và điều khiển dàn máy MMO.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsAppDownloadModalOpen(true)}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs transition-all shadow-[0_0_20px_rgba(6,182,212,0.35)] flex items-center gap-2 shrink-0 self-stretch sm:self-auto justify-center"
            >
              <Download className="w-4 h-4" />
              <span>TẢI FILE APP (.EXE)</span>
            </button>
          </div>
        </div>

        {/* Live Counters & Stats */}
        <div className="pt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
          <div className="p-4 rounded-2xl bg-[#0a0a0a] border border-white/10 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">Tổng Key Đã Xuất</span>
              <Zap className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-white mt-1">45,820+</div>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1 mt-0.5">
              <TrendingUp className="w-3 h-3" />
              Tăng trưởng 18% tháng này
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#0a0a0a] border border-white/10 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">Thời Gian Cấp Key</span>
              <Cpu className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 mt-1">~3.2 Giây</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Xử lý tự động VietQR</span>
          </div>

          <div className="p-4 rounded-2xl bg-[#0a0a0a] border border-white/10 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">Đại Lý Phân Phối</span>
              <Layers className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-amber-400 mt-1">180+ Đối Tác</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Chiết khấu tới 35%</span>
          </div>

          <div className="p-4 rounded-2xl bg-[#0a0a0a] border border-white/10 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">Đánh Giá Hài Lòng</span>
              <ShieldCheck className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-purple-400 mt-1">99.6% ⭐</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Bảo hành 1-1 trọn đời</span>
          </div>
        </div>
      </div>
    </div>
  );
};
