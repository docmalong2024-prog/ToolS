import React, { useState } from 'react';
import { useSystem } from '../../contexts/SystemContext';
import {
  Calculator,
  X,
  Sparkles,
  Clock,
  TrendingUp,
  DollarSign,
  Zap,
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface RoiCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RoiCalculatorModal: React.FC<RoiCalculatorModalProps> = ({ isOpen, onClose }) => {
  const { formatVND, setActiveView } = useSystem();

  // Inputs
  const [accountCount, setAccountCount] = useState<number>(10);
  const [hoursPerDay, setHoursPerDay] = useState<number>(4);
  const [hourlyWage, setHourlyWage] = useState<number>(35000); // 35k VND / hour
  const [toolCostPerMonth, setToolCostPerMonth] = useState<number>(299000); // 299k VND

  if (!isOpen) return null;

  // Calculation
  const totalManualHoursPerMonth = hoursPerDay * 30;
  const manualLaborCostPerMonth = totalManualHoursPerMonth * hourlyWage;

  // With tool: Automation reduces 85% of manual time
  const autoHoursPerMonth = Math.round(totalManualHoursPerMonth * 0.15);
  const autoLaborCostPerMonth = autoHoursPerMonth * hourlyWage;

  const totalToolExpense = toolCostPerMonth + autoLaborCostPerMonth;
  const netSavingsPerMonth = Math.max(0, manualLaborCostPerMonth - totalToolExpense);
  const hoursSavedPerMonth = totalManualHoursPerMonth - autoHoursPerMonth;
  const productivityMultiplier = ((totalManualHoursPerMonth / Math.max(1, autoHoursPerMonth))).toFixed(1);

  const handleStartUsing = () => {
    onClose();
    setActiveView('catalog');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#0a0a0a] border border-blue-500/30 rounded-3xl shadow-[0_0_50px_rgba(37,99,235,0.25)] overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 flex items-center justify-between bg-[#050505]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
                <span>Bảng Tính Hiệu Quả & Tiết Kiệm (ROI)</span>
                <span className="text-[10px] font-mono font-normal px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  MMO Automation
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Tính toán thời gian & chi phí tiết kiệm khi sử dụng Tool tự động thay vì thao tác tay
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Sliders Input */}
          <div className="space-y-4 bg-[#111111] p-4 rounded-2xl border border-white/5">
            {/* Account Count */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-300">Số lượng tài khoản (Acc TikTok / Shopee / FB):</span>
                <strong className="font-mono text-blue-400 text-sm">{accountCount} Acc</strong>
              </div>
              <input
                type="range"
                min="1"
                max="100"
                value={accountCount}
                onChange={(e) => setAccountCount(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
            </div>

            {/* Manual hours per day */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-300">Thời gian làm thủ công mỗi ngày:</span>
                <strong className="font-mono text-amber-400 text-sm">{hoursPerDay} Giờ/Ngày</strong>
              </div>
              <input
                type="range"
                min="1"
                max="16"
                value={hoursPerDay}
                onChange={(e) => setHoursPerDay(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            {/* Estimated hourly labor rate */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-300">Giá trị thời gian / Lương nhân sự theo giờ:</span>
                <strong className="font-mono text-emerald-400 text-sm">{formatVND(hourlyWage)}/h</strong>
              </div>
              <input
                type="range"
                min="20000"
                max="150000"
                step="5000"
                value={hourlyWage}
                onChange={(e) => setHourlyWage(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
            </div>
          </div>

          {/* Result Highlight Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 text-center space-y-1">
              <span className="text-[11px] text-emerald-300 font-medium block">Tiết Kiệm Tiền / Tháng</span>
              <div className="text-lg sm:text-xl font-black font-mono text-emerald-400">
                +{formatVND(netSavingsPerMonth)}
              </div>
              <span className="text-[10px] text-slate-400 block">Sau khi trừ tiền thuê tool</span>
            </div>

            <div className="p-4 rounded-2xl bg-blue-950/30 border border-blue-500/30 text-center space-y-1">
              <span className="text-[11px] text-blue-300 font-medium block">Thời Gian Giải Phóng</span>
              <div className="text-lg sm:text-xl font-black font-mono text-blue-400">
                {hoursSavedPerMonth} Giờ
              </div>
              <span className="text-[10px] text-slate-400 block">Tương đương {(hoursSavedPerMonth / 8).toFixed(1)} ngày công</span>
            </div>

            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-500/30 text-center space-y-1">
              <span className="text-[11px] text-purple-300 font-medium block">Năng Suất Tăng</span>
              <div className="text-lg sm:text-xl font-black font-mono text-purple-400">
                x{productivityMultiplier} Lần
              </div>
              <span className="text-[10px] text-slate-400 block">Chạy 24/7 không cần nghỉ</span>
            </div>
          </div>

          {/* Advantages Bullet Points */}
          <div className="p-4 rounded-2xl bg-[#111111] border border-white/10 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Chống checkpoint, lách thuật toán và bảo vệ tài khoản MMO tối đa.</span>
            </div>
            <div className="flex items-center gap-2 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Bảo hành 1-1, hỗ trợ reset HWID khi đổi máy tính làm việc.</span>
            </div>
            <div className="flex items-center gap-2 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Cập nhật tính năng và bản vá miễn phí trọn đời theo gói đã mua.</span>
            </div>
          </div>

          {/* CTA Action */}
          <button
            onClick={handleStartUsing}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-[0_0_25px_rgba(37,99,235,0.4)] transition-all flex items-center justify-center gap-2"
          >
            <Zap className="w-4 h-4" />
            <span>KHÁM PHÁ & BẮT ĐẦU TỰ ĐỘNG HÓA NGAY</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
