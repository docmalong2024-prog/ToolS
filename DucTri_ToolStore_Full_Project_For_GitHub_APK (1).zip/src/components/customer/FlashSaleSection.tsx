import React, { useState, useEffect } from 'react';
import { storage } from '../../services/storage';
import { useSystem } from '../../contexts/SystemContext';
import { useCart } from '../../contexts/CartContext';
import { ToolItem } from '../../types';
import { Flame, Clock, Sparkles, Zap, ShoppingCart, ArrowRight, ShieldCheck, Star } from 'lucide-react';

interface FlashSaleSectionProps {
  onSelectTool?: (tool: ToolItem) => void;
}

export const FlashSaleSection: React.FC<FlashSaleSectionProps> = ({ onSelectTool }) => {
  const { formatVND, showToast } = useSystem();
  const { addToCart, setIsCartOpen } = useCart();
  const tools = storage.getTools();

  // Pick top 3 tools for flash sale
  const flashSaleTools = tools.slice(0, 3);

  // Countdown timer: Target end of today
  const [timeLeft, setTimeLeft] = useState({
    hours: 8,
    minutes: 42,
    seconds: 15,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      const diff = Math.max(0, endOfDay.getTime() - now.getTime());

      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / 1000 / 60) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      setTimeLeft({ hours, minutes, seconds });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleQuickBuy = (tool: ToolItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const primaryPlan = tool.plans[0];
    if (primaryPlan) {
      addToCart(tool, primaryPlan);
      setIsCartOpen(true);
      showToast('Đã thêm gói Flash Sale vào giỏ hàng!', tool.name, 'success');
    }
  };

  if (flashSaleTools.length === 0) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-950/30 via-[#0d0914] to-indigo-950/30 border border-rose-500/30 p-5 sm:p-7 shadow-[0_0_50px_rgba(244,63,94,0.15)]">
        {/* Glow effect */}
        <div className="absolute top-0 right-1/4 w-80 h-80 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Section Header */}
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-white/10">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-mono font-bold tracking-wide">
              <Flame className="w-3.5 h-3.5 text-rose-400 fill-rose-400 animate-pulse" />
              <span>FLASH SALE GIỜ VÀNG • GIẢM TỚI 50%</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              Ưu Đãi Bản Quyền Hôm Nay
            </h2>
            <p className="text-xs text-slate-400">
              Số lượng key ưu đãi có hạn trong ngày. Tự động trả về giá gốc khi hết thời gian!
            </p>
          </div>

          {/* Countdown Clock Box */}
          <div className="flex items-center gap-2 bg-[#050505]/90 border border-rose-500/30 px-4 py-2.5 rounded-2xl shrink-0 shadow-lg">
            <Clock className="w-4 h-4 text-rose-400 animate-spin" style={{ animationDuration: '8s' }} />
            <span className="text-xs font-semibold text-slate-300 mr-1">Kết thúc sau:</span>
            <div className="flex items-center gap-1 font-mono font-bold text-sm">
              <span className="bg-rose-950/80 text-rose-300 px-2 py-1 rounded-lg border border-rose-500/40">
                {String(timeLeft.hours).padStart(2, '0')}
              </span>
              <span className="text-rose-400">:</span>
              <span className="bg-rose-950/80 text-rose-300 px-2 py-1 rounded-lg border border-rose-500/40">
                {String(timeLeft.minutes).padStart(2, '0')}
              </span>
              <span className="text-rose-400">:</span>
              <span className="bg-rose-950/80 text-rose-300 px-2 py-1 rounded-lg border border-rose-500/40">
                {String(timeLeft.seconds).padStart(2, '0')}
              </span>
            </div>
          </div>
        </div>

        {/* Flash Sale Cards Grid */}
        <div className="relative grid grid-cols-1 md:grid-cols-3 gap-5 pt-6">
          {flashSaleTools.map((tool, idx) => {
            const plan = tool.plans[0];
            const originalPrice = plan ? plan.originalPrice : 500000;
            const salePrice = plan ? plan.salePrice : 299000;
            const discountPercent = Math.round(((originalPrice - salePrice) / originalPrice) * 100);
            const soldKeysPercent = Math.min(92, 60 + idx * 12);
            const remainingKeys = 3 + idx * 2;

            return (
              <div
                key={tool.id}
                onClick={() => onSelectTool && onSelectTool(tool)}
                className="group relative rounded-2xl bg-[#080808]/90 border border-white/10 hover:border-rose-500/50 p-4 transition-all duration-300 hover:shadow-[0_0_30px_rgba(244,63,94,0.25)] flex flex-col justify-between cursor-pointer"
              >
                {/* Discount Badge */}
                <div className="absolute -top-2.5 -right-2.5 bg-gradient-to-r from-rose-600 to-orange-500 text-white font-mono font-bold text-xs px-2.5 py-1 rounded-xl shadow-lg border border-white/20 flex items-center gap-1">
                  <Flame className="w-3 h-3 fill-current" />
                  <span>-{discountPercent}%</span>
                </div>

                <div className="space-y-3">
                  {/* Tool Image & Info */}
                  <div className="flex items-center gap-3">
                    <img
                      src={tool.images[0] || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200'}
                      alt={tool.name}
                      className="w-14 h-14 rounded-xl object-cover border border-white/10 shrink-0 group-hover:scale-105 transition-transform"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1 text-[10px] text-amber-400 font-bold mb-0.5">
                        <Star className="w-3 h-3 fill-amber-400" />
                        <span>{tool.rating.toFixed(1)}</span>
                        <span className="text-slate-500 font-normal">({tool.reviewCount})</span>
                      </div>
                      <h3 className="text-sm font-bold text-white group-hover:text-rose-300 transition-colors truncate">
                        {tool.name}
                      </h3>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{tool.tagline}</p>
                    </div>
                  </div>

                  {/* Stock Progress Bar */}
                  <div className="space-y-1 bg-[#111111] p-2 rounded-xl border border-white/5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-rose-400 font-semibold flex items-center gap-1">
                        <Zap className="w-3 h-3" />
                        Chỉ còn <strong className="font-mono text-white">{remainingKeys}</strong> key
                      </span>
                      <span className="text-slate-400 font-mono text-[10px]">Đã bán {soldKeysPercent}%</span>
                    </div>
                    <div className="w-full bg-[#222222] h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-orange-500 to-rose-500 h-full rounded-full transition-all duration-1000"
                        style={{ width: `${soldKeysPercent}%` }}
                      />
                    </div>
                  </div>

                  {/* Pricing Box */}
                  <div className="flex items-baseline justify-between pt-1">
                    <div>
                      <span className="text-[10px] text-slate-500 line-through mr-2 font-mono">
                        {formatVND(originalPrice)}
                      </span>
                      <span className="text-base font-bold text-rose-400 font-mono">
                        {formatVND(salePrice)}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {plan ? plan.name : '1 Tháng'}
                    </span>
                  </div>
                </div>

                {/* Buy Button */}
                <div className="pt-3 border-t border-white/10 mt-3 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(e) => handleQuickBuy(tool, e)}
                    className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(244,63,94,0.3)]"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>Mua Ngay</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectTool && onSelectTool(tool)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors border border-white/10"
                    title="Xem chi tiết tool"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
