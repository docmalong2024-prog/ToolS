import React from 'react';
import { ToolItem, PricingPlan } from '../../types';
import { storage } from '../../services/storage';
import { useCart } from '../../contexts/CartContext';
import { useSystem } from '../../contexts/SystemContext';
import { useAuth } from '../../contexts/AuthContext';
import {
  Star,
  Download,
  ShoppingBag,
  Zap,
  ShieldCheck,
  CheckCircle,
  Eye,
  Sparkles,
  Layers,
  Flame
} from 'lucide-react';

interface ToolCardProps {
  tool: ToolItem;
  onOpenDetail: (tool: ToolItem) => void;
  onQuickBuy?: (tool: ToolItem, plan: PricingPlan) => void;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool, onOpenDetail, onQuickBuy }) => {
  const { addToCart, setIsCartOpen } = useCart();
  const { formatVND, showToast } = useSystem();
  const { currentUser } = useAuth();

  // Lowest sale price and original price
  const lowestPlan = tool.plans.reduce((min, p) => (p.salePrice < min.salePrice ? p : min), tool.plans[0]);
  const highestOriginal = tool.plans.reduce((max, p) => (p.originalPrice > max.originalPrice ? p : max), tool.plans[0]);

  // Check inventory stock in vault
  const totalKeysAvailable = storage.getAvailableKeyCount(tool.id);
  const isLowStock = totalKeysAvailable > 0 && totalKeysAvailable <= tool.warningStockThreshold;
  const isOutOfStock = totalKeysAvailable === 0;

  // Reseller wholesale discount indicator
  const isResellerApproved = currentUser?.role === 'reseller' && currentUser?.resellerStatus === 'approved';
  const resellerDiscountPct = isResellerApproved ? (currentUser?.resellerDiscountPercent || 15) : 0;
  const resellerPrice = isResellerApproved
    ? Math.round(lowestPlan.salePrice * (1 - resellerDiscountPct / 100))
    : lowestPlan.salePrice;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(tool, lowestPlan, 1);
    showToast(`Đã thêm ${tool.name} vào giỏ hàng!`, `${lowestPlan.name} - ${formatVND(lowestPlan.salePrice)}`, 'success');
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onQuickBuy) {
      onQuickBuy(tool, lowestPlan);
    } else {
      addToCart(tool, lowestPlan, 1);
      setIsCartOpen(true);
    }
  };

  return (
    <div
      onClick={() => onOpenDetail(tool)}
      className="group relative flex flex-col rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 hover:border-blue-500/50 hover:shadow-[0_0_35px_rgba(59,130,246,0.25)] hover:bg-white/[0.05] transition-all duration-300 overflow-hidden cursor-pointer shadow-[0_8px_32px_rgba(0,0,0,0.4)]"
    >
      {/* Gloss Reflection Top Glow */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent group-hover:via-blue-400/60 transition-all" />
      {/* Thumbnail Banner */}
      <div className="relative aspect-video w-full overflow-hidden bg-[#050505]">
        <img
          src={tool.images[0]}
          alt={tool.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-black/30" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-10">
          {tool.tags.slice(0, 2).map((tag, idx) => (
            <span
              key={idx}
              className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold uppercase tracking-wider backdrop-blur-md ${
                tag === 'Hot' || tag === 'Best Seller'
                  ? 'bg-rose-500/80 text-white border border-rose-400/40 shadow-[0_0_10px_rgba(244,63,94,0.4)]'
                  : 'bg-blue-600 text-white border border-blue-400/40'
              }`}
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Version Pill */}
        <div className="absolute top-3 right-3 z-10">
          <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-semibold bg-[#050505]/80 text-blue-300 border border-white/10 backdrop-blur-md">
            v{tool.version}
          </span>
        </div>

        {/* Stock status overlay bar */}
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-[11px] font-mono">
          {isOutOfStock ? (
            <span className="px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-500/40 backdrop-blur-md font-bold">
              ● Tạm Hết Key
            </span>
          ) : isLowStock ? (
            <span className="px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-500/40 backdrop-blur-md font-bold animate-pulse">
              🔥 Sắp hết (Còn {totalKeysAvailable} Key)
            </span>
          ) : (
            <span className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 backdrop-blur-md font-bold">
              ⚡ Sẵn {totalKeysAvailable} Key trong kho
            </span>
          )}

          <div className="flex items-center gap-1 text-slate-300 bg-[#0a0a0a]/80 px-2 py-0.5 rounded border border-white/10 backdrop-blur-md">
            <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
            <span>{tool.rating.toFixed(1)}</span>
            <span className="text-slate-500">({tool.reviewCount})</span>
          </div>
        </div>
      </div>

      {/* Content Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          <h3 className="font-bold text-sm sm:text-base text-white group-hover:text-blue-300 transition-colors line-clamp-1">
            {tool.name}
          </h3>
          <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
            {tool.tagline}
          </p>

          {/* Key Feature bullets */}
          <div className="space-y-1 pt-1">
            {tool.features.slice(0, 2).map((feat, idx) => (
              <div key={idx} className="flex items-center gap-1.5 text-[11px] text-slate-300 line-clamp-1">
                <CheckCircle className="w-3 h-3 text-blue-400 shrink-0" />
                <span className="truncate">{feat}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Pricing & Actions */}
        <div className="pt-3 border-t border-white/10 space-y-3">
          <div className="flex items-baseline justify-between">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-semibold">Giá từ:</span>
              <div className="flex items-baseline gap-1.5">
                <span className="font-mono text-base sm:text-lg font-extrabold text-blue-400">
                  {formatVND(isResellerApproved ? resellerPrice : lowestPlan.salePrice)}
                </span>
                {lowestPlan.originalPrice > lowestPlan.salePrice && (
                  <span className="text-[11px] font-mono text-slate-500 line-through">
                    {formatVND(lowestPlan.originalPrice)}
                  </span>
                )}
              </div>
            </div>

            {isResellerApproved && (
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold font-mono">
                Giá Đại Lý -{resellerDiscountPct}%
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleAddToCart}
              disabled={isOutOfStock}
              className="w-full py-2 rounded-xl text-xs font-semibold bg-[#141414] hover:bg-white/10 text-slate-200 border border-white/10 hover:border-white/20 transition-all flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-blue-400" />
              <span>Thêm Giỏ</span>
            </button>

            <button
              onClick={handleBuyNow}
              disabled={isOutOfStock}
              className="w-full py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] transition-all flex items-center justify-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Mua Ngay</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
