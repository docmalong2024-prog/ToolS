import React, { useState, useMemo, useEffect } from 'react';
import { ToolItem, ToolCategory, PricingPlan } from '../../types';
import { storage } from '../../services/storage';
import { ToolCard } from './ToolCard';
import { ToolDetailModal } from './ToolDetailModal';
import { useCart } from '../../contexts/CartContext';
import {
  Layers,
  Sparkles,
  SlidersHorizontal,
  Flame,
  Search,
  CheckCircle,
  Filter,
  ArrowUpDown
} from 'lucide-react';

interface ToolCatalogProps {
  initialCategory?: ToolCategory | 'all';
  searchQuery?: string;
  onSearchChange?: (q: string) => void;
}

const CATEGORIES: { id: ToolCategory | 'all'; label: string; icon: string }[] = [
  { id: 'all', label: 'Tất Cả Tool', icon: '⚡' },
  { id: 'marketing_mmo', label: 'MMO & Social Marketing', icon: '🚀' },
  { id: 'automation', label: 'Tự Động Hóa & Sniper Bot', icon: '🤖' },
  { id: 'ai_data', label: 'AI Video & Xử Lý Data', icon: '🧠' },
  { id: 'seo_traffic', label: 'SEO & Ép Index Google', icon: '📈' },
  { id: 'developer', label: 'Anti-Detect & Tool Dev', icon: '💻' },
];

export const ToolCatalog: React.FC<ToolCatalogProps> = ({
  initialCategory = 'all',
  searchQuery = '',
  onSearchChange,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ToolCategory | 'all'>(initialCategory);
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'popular' | 'rating' | 'price_asc' | 'price_desc' | 'newest'>('popular');
  const [selectedToolForModal, setSelectedToolForModal] = useState<ToolItem | null>(null);

  // Sync category state when initialCategory prop changes (e.g. from HeroBanner or Navigation)
  useEffect(() => {
    if (initialCategory) {
      setSelectedCategory(initialCategory);
    }
  }, [initialCategory]);

  const tools = storage.getTools();

  // Filter and sort tools
  const filteredTools = useMemo(() => {
    return tools
      .filter((tool) => {
        // Category match
        if (selectedCategory !== 'all' && tool.category !== selectedCategory) {
          return false;
        }

        // Tag match
        if (selectedTag !== 'all' && !tool.tags.includes(selectedTag)) {
          return false;
        }

        // Search query match
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = tool.name.toLowerCase().includes(q);
          const matchTagline = tool.tagline.toLowerCase().includes(q);
          const matchFeatures = tool.features.some((f) => f.toLowerCase().includes(q));
          const matchTags = tool.tags.some((t) => t.toLowerCase().includes(q));
          if (!matchName && !matchTagline && !matchFeatures && !matchTags) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'popular') return b.totalSold - a.totalSold;
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'newest') return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();

        const minPriceA = a.plans.reduce((m, p) => (p.salePrice < m ? p.salePrice : m), Infinity);
        const minPriceB = b.plans.reduce((m, p) => (p.salePrice < m ? p.salePrice : m), Infinity);
        if (sortBy === 'price_asc') return minPriceA - minPriceB;
        if (sortBy === 'price_desc') return minPriceB - minPriceA;

        return 0;
      });
  }, [tools, selectedCategory, selectedTag, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-blue-400 uppercase tracking-widest font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Digital License Store</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            Kho Tool Bản Quyền & Phần Mềm Tự Động
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Cung cấp Key bản quyền chính hãng với link tải trực tiếp, kích hoạt tự động 24/7
          </p>
        </div>

        {/* Sort by dropdown */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={sortBy}
            onChange={(e: any) => setSortBy(e.target.value)}
            className="bg-[#111111] border border-white/10 text-xs text-white rounded-xl px-3 py-2 focus:border-blue-500 focus:outline-none font-medium cursor-pointer"
          >
            <option value="popular">Bán Chạy Nhất (Hot)</option>
            <option value="rating">Đánh Giá Cao Nhất (5⭐)</option>
            <option value="price_asc">Giá Thấp Đến Cao</option>
            <option value="price_desc">Giá Cao Đến Thấp</option>
            <option value="newest">Mới Cập Nhật (v5.2)</option>
          </select>
        </div>
      </div>

      {/* Category Tabs Pill Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                isSelected
                  ? 'bg-blue-600 border-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
                  : 'bg-[#0a0a0a] border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tag Filters */}
      <div className="flex items-center gap-2 overflow-x-auto text-xs text-slate-400">
        <span className="flex items-center gap-1 font-semibold text-[11px] uppercase tracking-wider text-slate-500">
          <Filter className="w-3 h-3" />
          Lọc nhanh:
        </span>
        {['all', 'Hot', 'Best Seller', 'Anti-Checkpoint', 'Auto 24/7'].map((tag) => (
          <button
            key={tag}
            onClick={() => setSelectedTag(tag)}
            className={`px-3 py-1 rounded-lg text-[11px] font-mono transition-all ${
              selectedTag === tag
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                : 'bg-[#111111] border border-white/5 text-slate-400 hover:text-slate-200'
            }`}
          >
            {tag === 'all' ? 'Tất Cả Tags' : `#${tag}`}
          </button>
        ))}

        {searchQuery && (
          <div className="ml-auto text-xs text-blue-400 font-mono">
            Kết quả tìm kiếm cho: "{searchQuery}" ({filteredTools.length} tool)
          </div>
        )}
      </div>

      {/* Tools Grid */}
      {filteredTools.length === 0 ? (
        <div className="py-16 text-center rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-[#111111] mx-auto flex items-center justify-center text-slate-500">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-white">Không tìm thấy tool nào phù hợp</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Hãy thử tìm kiếm bằng từ khóa khác hoặc xóa bộ lọc danh mục.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSelectedTag('all');
              onSearchChange && onSearchChange('');
            }}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white"
          >
            Đặt lại bộ lọc
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTools.map((tool) => (
            <ToolCard
              key={tool.id}
              tool={tool}
              onOpenDetail={(t) => setSelectedToolForModal(t)}
            />
          ))}
        </div>
      )}

      {/* Tool Detail Modal */}
      {selectedToolForModal && (
        <ToolDetailModal
          tool={selectedToolForModal}
          isOpen={!!selectedToolForModal}
          onClose={() => setSelectedToolForModal(null)}
        />
      )}
    </div>
  );
};
