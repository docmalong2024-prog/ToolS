import React, { useState } from 'react';
import { ToolItem, PricingPlan, Review } from '../../types';
import { storage } from '../../services/storage';
import { useCart } from '../../contexts/CartContext';
import { useAuth } from '../../contexts/AuthContext';
import { useSystem } from '../../contexts/SystemContext';
import {
  Star,
  Download,
  ShoppingBag,
  Zap,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Cpu,
  Layers,
  Sparkles,
  ExternalLink,
  MessageSquare,
  Clock,
  HardDrive,
  Monitor,
  X,
  Share2
} from 'lucide-react';

interface ToolDetailModalProps {
  tool: ToolItem | null;
  isOpen: boolean;
  onClose: () => void;
  onQuickBuy?: (tool: ToolItem, plan: PricingPlan) => void;
}

export const ToolDetailModal: React.FC<ToolDetailModalProps> = ({
  tool,
  isOpen,
  onClose,
  onQuickBuy,
}) => {
  const { addToCart, setIsCartOpen } = useCart();
  const { currentUser } = useAuth();
  const { formatVND, formatDate, showToast } = useSystem();

  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'features' | 'guide' | 'changelog' | 'reviews'>('features');
  const [activeImageIdx, setActiveImageIdx] = useState<number>(0);

  // Review submission state
  const [newRating, setNewRating] = useState<number>(5);
  const [newComment, setNewComment] = useState<string>('');
  const [reviewsList, setReviewsList] = useState<Review[]>([]);

  // Update selected plan on tool change
  React.useEffect(() => {
    if (tool && tool.plans.length > 0) {
      setSelectedPlanId(tool.plans[0].id);
      setReviewsList(storage.getReviews(tool.id));
      setActiveImageIdx(0);
    }
  }, [tool]);

  if (!isOpen || !tool) return null;

  const selectedPlan = tool.plans.find((p) => p.id === selectedPlanId) || tool.plans[0];
  const keysInStockForSelectedPlan = storage.getAvailableKeyCount(tool.id, selectedPlan.id);
  const isSelectedOutOfStock = keysInStockForSelectedPlan === 0;

  // Reseller discount
  const isResellerApproved = currentUser?.role === 'reseller' && currentUser?.resellerStatus === 'approved';
  const resellerDiscountPct = isResellerApproved ? (currentUser?.resellerDiscountPercent || 15) : 0;
  const planSalePrice = isResellerApproved
    ? Math.round(selectedPlan.salePrice * (1 - resellerDiscountPct / 100))
    : selectedPlan.salePrice;

  const handleAddToCart = () => {
    addToCart(tool, selectedPlan, 1);
    showToast(`Đã thêm ${tool.name} (${selectedPlan.name}) vào giỏ hàng!`, undefined, 'success');
  };

  const handleBuyNow = () => {
    if (onQuickBuy) {
      onQuickBuy(tool, selectedPlan);
    } else {
      addToCart(tool, selectedPlan, 1);
      onClose();
      setIsCartOpen(true);
    }
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) {
      showToast('Vui lòng nhập nội dung đánh giá!', undefined, 'error');
      return;
    }
    const createdRev = storage.addReview({
      toolId: tool.id,
      userId: currentUser?.id || 'guest_user',
      userName: currentUser?.name || 'Khách hàng ẩn danh',
      userAvatar: currentUser?.avatar,
      rating: newRating,
      comment: newComment,
      isVerifiedBuyer: true,
    });
    setReviewsList([createdRev, ...reviewsList]);
    setNewComment('');
    showToast('Cảm ơn bạn đã gửi đánh giá sản phẩm!', undefined, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-[0_0_60px_rgba(0,0,0,0.9)] overflow-hidden my-6 flex flex-col max-h-[90vh]">
        {/* Top Glow Bar */}
        <div className="h-1.5 w-full bg-gradient-to-r from-blue-600 via-indigo-500 to-blue-400" />

        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#050505] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-wide">{tool.name}</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  v{tool.version}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{tool.tagline}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* Top Section: Gallery & Plan Selector */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Left: Image Gallery */}
            <div className="md:col-span-5 space-y-3">
              <div className="aspect-video w-full rounded-xl overflow-hidden bg-[#050505] border border-white/10 relative shadow-inner">
                <img
                  src={tool.images[activeImageIdx] || tool.images[0]}
                  alt={tool.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm text-[10px] font-mono text-slate-300">
                  Cập nhật: {tool.lastUpdated}
                </div>
              </div>

              {/* Thumbnails */}
              {tool.images.length > 1 && (
                <div className="flex gap-2">
                  {tool.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIdx(idx)}
                      className={`relative w-16 h-12 rounded-lg overflow-hidden border transition-all ${
                        activeImageIdx === idx
                          ? 'border-blue-500 shadow-[0_0_10px_rgba(37,99,235,0.4)]'
                          : 'border-white/10 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="Thumb" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Quick Specs */}
              <div className="p-3.5 rounded-xl bg-[#111111] border border-white/10 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <Monitor className="w-3.5 h-3.5 text-blue-400" />
                    Hệ điều hành:
                  </span>
                  <span className="text-white font-mono text-[11px]">{tool.osCompatibility.join(', ')}</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
                    Dung lượng file:
                  </span>
                  <span className="text-white font-mono text-[11px]">{tool.fileSize}</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    Tổng lượt mua:
                  </span>
                  <span className="text-amber-300 font-mono text-[11px] font-bold">{tool.totalSold.toLocaleString()} lượt</span>
                </div>
              </div>
            </div>

            {/* Right: Pricing Plans Selector */}
            <div className="md:col-span-7 space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2">
                  1. Chọn Gói Thời Hạn Bản Quyền:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {tool.plans.map((plan) => {
                    const isSelected = selectedPlan.id === plan.id;
                    const stock = storage.getAvailableKeyCount(tool.id, plan.id);
                    const isPlanResellerPrice = isResellerApproved
                      ? Math.round(plan.salePrice * (1 - resellerDiscountPct / 100))
                      : plan.salePrice;

                    return (
                      <div
                        key={plan.id}
                        onClick={() => setSelectedPlanId(plan.id)}
                        className={`relative p-3.5 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'border-blue-500 bg-blue-500/10 shadow-[0_0_20px_rgba(37,99,235,0.2)]'
                            : 'border-white/10 bg-[#111111] hover:border-white/20'
                        }`}
                      >
                        {plan.badge && (
                          <span className="absolute -top-2 right-2 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow">
                            {plan.badge}
                          </span>
                        )}

                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="text-xs font-bold text-white">{plan.name}</h4>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {plan.durationDays > 90000 ? 'Sử dụng trọn đời' : `${plan.durationDays} ngày`}
                            </span>
                          </div>

                          <div className="text-right">
                            <div className="text-sm font-bold font-mono text-blue-400">
                              {formatVND(isPlanResellerPrice)}
                            </div>
                            {plan.originalPrice > plan.salePrice && (
                              <div className="text-[10px] text-slate-500 font-mono line-through">
                                {formatVND(plan.originalPrice)}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Stock indicator per plan */}
                        <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                          <span className={stock > 0 ? 'text-emerald-400' : 'text-rose-400 font-bold'}>
                            {stock > 0 ? `⚡ Sẵn ${stock} Key` : '● Hết key'}
                          </span>
                          {isResellerApproved && (
                            <span className="text-amber-400 font-bold">Đại lý -{resellerDiscountPct}%</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Price Summary & Action Buttons */}
              <div className="p-4 rounded-xl bg-[#111111] border border-white/10 space-y-3">
                <div className="flex items-baseline justify-between">
                  <div>
                    <span className="text-[11px] text-slate-400 block">Thành tiền cho {selectedPlan.name}:</span>
                    <div className="flex items-baseline gap-2 mt-0.5">
                      <span className="text-2xl font-bold font-mono text-emerald-400">
                        {formatVND(planSalePrice)}
                      </span>
                      {selectedPlan.originalPrice > selectedPlan.salePrice && (
                        <span className="text-xs font-mono text-slate-500 line-through">
                          {formatVND(selectedPlan.originalPrice)}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 block">Hình thức giao hàng:</span>
                    <span className="text-xs font-semibold text-blue-300">⚡ Xuất Key Tức Thì</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <button
                    onClick={handleAddToCart}
                    disabled={isSelectedOutOfStock}
                    className="py-3 rounded-xl text-xs font-bold bg-[#1e1e1e] hover:bg-[#282828] text-white border border-white/10 transition-all flex items-center justify-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4 text-blue-400" />
                    <span>Thêm Vào Giỏ Hàng</span>
                  </button>

                  <button
                    onClick={handleBuyNow}
                    disabled={isSelectedOutOfStock}
                    className="py-3 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.4)] transition-all flex items-center justify-center gap-2"
                  >
                    <Zap className="w-4 h-4" />
                    <span>Thanh Toán & Lấy Key</span>
                  </button>
                </div>

                <div className="flex flex-col gap-2 pt-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      VirusTotal Clean (0/72) • Đổi HWID 3 Lần
                    </span>
                    <a
                      href={tool.downloadUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-400 hover:text-blue-300 font-bold hover:underline flex items-center gap-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Tải Bộ Cài (.EXE)</span>
                    </a>
                  </div>

                  <div className="p-2 rounded-lg bg-[#080808] border border-emerald-500/20 text-[10px] text-slate-400 flex items-center justify-between font-mono">
                    <span>SHA-256: 8f3c7b...4e9a12</span>
                    <span className="text-emerald-400">✔ Không chứa mã độc / Trojan</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="border-b border-white/10 flex gap-2 pt-4">
            <button
              onClick={() => setActiveTab('features')}
              className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all ${
                activeTab === 'features'
                  ? 'border-blue-500 text-blue-300'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Tính Năng Nổi Bật
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all ${
                activeTab === 'guide'
                  ? 'border-blue-500 text-blue-300'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Hướng Dẫn & Yêu Cầu Cấu Hình
            </button>
            <button
              onClick={() => setActiveTab('changelog')}
              className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all ${
                activeTab === 'changelog'
                  ? 'border-blue-500 text-blue-300'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Nhật Ký Phiên Bản (v{tool.version})
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'reviews'
                  ? 'border-blue-500 text-blue-300'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              <span>Đánh Giá Khách Hàng</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-[#111111] text-amber-400">
                {reviewsList.length}
              </span>
            </button>
          </div>

          {/* Tab Content */}
          <div className="space-y-4">
            {activeTab === 'features' && (
              <div className="space-y-4">
                <p className="text-xs text-slate-300 leading-relaxed bg-[#111111] p-4 rounded-xl border border-white/10">
                  {tool.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {tool.features.map((feat, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-[#111111] border border-white/10 flex items-start gap-2.5"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="text-xs text-slate-200 leading-relaxed">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'guide' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 rounded-xl bg-[#111111] border border-white/10 space-y-3">
                  <h4 className="font-bold text-white uppercase text-xs tracking-wider text-blue-400">
                    Quy Trình 3 Bước Kích Hoạt Nhanh:
                  </h4>
                  <ol className="space-y-2 list-decimal list-inside text-slate-300">
                    <li>Tải bộ cài đặt phần mềm từ nút <strong>"Tải Tool"</strong> hoặc biên lai sau khi thanh toán.</li>
                    <li>Chạy file cài đặt với quyền Administrator (Run as Administrator) trên Windows / macOS.</li>
                    <li>Mở phần mềm, dán <strong>Mã Key Bản Quyền</strong> đã nhận và bấm <strong>"Kích Hoạt (Activate)"</strong>.</li>
                    <li>Phần mềm sẽ tự động kết nối máy chủ bản quyền ToolStore Pro và khóa theo mã HWID máy tính của bạn.</li>
                  </ol>
                </div>

                <div className="p-4 rounded-xl bg-[#111111] border border-white/10 space-y-2">
                  <h4 className="font-bold text-white uppercase text-xs tracking-wider text-amber-400">
                    Yêu Cầu Phần Cứng Khuyến Nghị:
                  </h4>
                  <ul className="space-y-1.5 text-slate-300">
                    {tool.requirements.map((req, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {activeTab === 'changelog' && (
              <div className="space-y-3 text-xs">
                <div className="p-4 rounded-xl bg-[#111111] border border-blue-500/30 space-y-2">
                  <div className="flex items-center justify-between font-mono">
                    <span className="font-bold text-blue-300">Phiên bản v{tool.version} (Mới nhất)</span>
                    <span className="text-slate-500">Phát hành: {tool.lastUpdated}</span>
                  </div>
                  <ul className="space-y-1 text-slate-300 list-disc list-inside">
                    <li>Nâng cấp thuật toán chống Checkpoint mới nhất theo cập nhật API 2026.</li>
                    <li>Tối ưu hóa đa luồng (Multi-threading) giảm 35% RAM khi chạy đồng thời 50 profile.</li>
                    <li>Tự động xoay Proxy SOCKS5/HTTP thông minh khi phát hiện IP bị giới hạn.</li>
                    <li>Sửa lỗi nhận diện captcha trượt và hoàn thiện kết nối Webhook Telegram.</li>
                  </ul>
                </div>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="space-y-4 text-xs">
                {/* Submit review */}
                <form onSubmit={handleAddReview} className="p-4 rounded-xl bg-[#111111] border border-white/10 space-y-3">
                  <h4 className="font-bold text-white text-xs">Viết Đánh Giá Của Bạn:</h4>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">Đánh giá sao:</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewRating(star)}
                          className="p-1 text-amber-400 hover:scale-110 transition-transform"
                        >
                          <Star
                            className={`w-4 h-4 ${
                              star <= newRating ? 'fill-amber-400 text-amber-400' : 'text-slate-600'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <textarea
                    rows={2}
                    placeholder="Nhận xét của bạn về tốc độ xử lý, tính năng của tool và chất lượng hỗ trợ..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl p-3 text-xs text-white placeholder:text-slate-600"
                  />

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white transition-all"
                    >
                      Gửi Đánh Giá
                    </button>
                  </div>
                </form>

                {/* Review list */}
                <div className="space-y-2.5">
                  {reviewsList.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-3.5 rounded-xl bg-[#111111] border border-white/10 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <strong className="text-white">{rev.userName}</strong>
                          {rev.isVerifiedBuyer && (
                            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              ✓ Đã mua hàng
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-0.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-slate-300 text-xs leading-relaxed">{rev.comment}</p>
                      <span className="text-[10px] text-slate-500 font-mono block">
                        {formatDate(rev.createdAt)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Bottom Bar */}
        <div className="p-4 border-t border-white/10 bg-[#050505] flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-400">
            Hỗ trợ 24/7 qua Telegram:{' '}
            <strong className="text-blue-300 font-mono">@ToolStorePro_Support</strong>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold bg-[#141414] hover:bg-white/10 text-slate-300 transition-colors"
          >
            Đóng Cửa Sổ
          </button>
        </div>
      </div>
    </div>
  );
};
