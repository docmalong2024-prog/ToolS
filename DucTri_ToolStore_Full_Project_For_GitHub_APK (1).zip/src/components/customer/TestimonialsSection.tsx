import React, { useState } from 'react';
import { Star, ShieldCheck, CheckCircle2, MessageSquare, ThumbsUp, Sparkles, Send } from 'lucide-react';
import { useSystem } from '../../contexts/SystemContext';
import { useAuth } from '../../contexts/AuthContext';

interface Testimonial {
  id: string;
  authorName: string;
  role: string;
  toolUsed: string;
  avatar: string;
  rating: number;
  content: string;
  date: string;
  likes: number;
}

const INITIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    authorName: 'Hoàng Long (MMO Master)',
    role: 'Quản lý 80 Kênh TikTok Shop',
    toolUsed: 'TikTok Shop Master Auto Pro',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    rating: 5,
    content: 'Tool chạy cực kỳ mượt, tự động gắn affiliate và reup video lách âm thanh 100%. Tiết kiệm cho team mình hơn 3 nhân sự edit video mỗi tháng. Cực kỳ đáng tiền!',
    date: '3 ngày trước',
    likes: 42,
  },
  {
    id: 't2',
    authorName: 'Nguyễn Tiến Dũng',
    role: 'Chủ Shop Shopee Mall',
    toolUsed: 'Shopee Sniper & Voucher Bot 0.01s',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
    rating: 5,
    content: 'Tốc độ giật mã flash sale 0.01s chuẩn từng mili-giây. Mua key vĩnh viễn xong được admin hỗ trợ cài đặt qua Ultraview siêu nhiệt tình trong 5 phút.',
    date: '5 ngày trước',
    likes: 38,
  },
  {
    id: 't3',
    authorName: 'Thu Hà Media',
    role: 'Agency Quảng Cáo & Content AI',
    toolUsed: 'AI Video Auto Render CapCut',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    rating: 5,
    content: 'Tự động lấy kịch bản ChatGPT render hàng loạt 50 video 4K sắc nét mỗi ngày không lỗi. Cổng nạp VietQR tự động cấp key ngay lập tức không cần đợi.',
    date: '1 tuần trước',
    likes: 29,
  }
];

export const TestimonialsSection: React.FC = () => {
  const { showToast } = useSystem();
  const { currentUser } = useAuth();

  const [testimonials, setTestimonials] = useState<Testimonial[]>(INITIAL_TESTIMONIALS);
  const [likedMap, setLikedMap] = useState<{ [key: string]: boolean }>({});
  const [showReviewForm, setShowReviewForm] = useState(false);

  // Form State
  const [authorName, setAuthorName] = useState(currentUser?.name || '');
  const [role, setRole] = useState('');
  const [toolUsed, setToolUsed] = useState('TikTok Shop Master Auto Pro');
  const [rating, setRating] = useState(5);
  const [content, setContent] = useState('');

  const handleLike = (id: string) => {
    if (likedMap[id]) return;
    setTestimonials((prev) =>
      prev.map((t) => (t.id === id ? { ...t, likes: t.likes + 1 } : t))
    );
    setLikedMap((prev) => ({ ...prev, [id]: true }));
    showToast('Cảm ơn bạn đã thích đánh giá này!', undefined, 'success');
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !authorName.trim()) {
      showToast('Vui lòng điền đầy đủ họ tên và nội dung đánh giá', undefined, 'error');
      return;
    }

    const newReview: Testimonial = {
      id: `t_${Date.now()}`,
      authorName: authorName.trim(),
      role: role.trim() || 'Người dùng MMO',
      toolUsed,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      rating,
      content: content.trim(),
      date: 'Vừa xong',
      likes: 1,
    };

    setTestimonials([newReview, ...testimonials]);
    setContent('');
    setShowReviewForm(false);
    showToast('Đã gửi đánh giá thành công!', 'Đánh giá của bạn đã được hiển thị công khai.', 'success');
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="space-y-8">
        {/* Section Title */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-mono font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>ĐÁNH GIÁ TỪ KHÁCH HÀNG & ĐẠI LÝ THỰC TẾ</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Khách Hàng Nói Gì Về DucTri ToolStore?
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Hơn 4,200+ khách hàng và đội ngũ MMO tin dùng hàng ngày với tỉ lệ hài lòng 99.6%
            </p>
          </div>

          <button
            onClick={() => setShowReviewForm(!showReviewForm)}
            className="px-4 py-2.5 rounded-xl bg-[#111111] hover:bg-white/10 text-slate-200 hover:text-white border border-white/10 text-xs font-bold transition-all flex items-center gap-2 shrink-0 self-start sm:self-auto"
          >
            <MessageSquare className="w-4 h-4 text-purple-400" />
            <span>{showReviewForm ? 'Đóng Biểu Mẫu' : 'Viết Đánh Giá Của Bạn'}</span>
          </button>
        </div>

        {/* Review Form (Collapsible) */}
        {showReviewForm && (
          <form
            onSubmit={handleSubmitReview}
            className="p-5 sm:p-6 rounded-3xl bg-[#0a0a0a] border border-purple-500/30 shadow-[0_0_30px_rgba(168,85,247,0.15)] space-y-4 animate-in fade-in duration-200"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Gửi Đánh Giá Trải Nghiệm Sử Dụng Phần Mềm</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Tên của bạn hoặc Nickname:</label>
                <input
                  type="text"
                  required
                  placeholder="VD: Tuấn Anh MMO"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Vai trò / Nghề nghiệp:</label>
                <input
                  type="text"
                  placeholder="VD: Dropshipper, Seller TikTok"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Phần mềm bạn đã mua:</label>
                <select
                  value={toolUsed}
                  onChange={(e) => setToolUsed(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="TikTok Shop Master Auto Pro">TikTok Shop Master Auto Pro</option>
                  <option value="Shopee Sniper & Voucher Bot 0.01s">Shopee Sniper & Voucher Bot 0.01s</option>
                  <option value="AI Video Auto Render CapCut">AI Video Auto Render CapCut</option>
                  <option value="Facebook Ads Stealth & Anti-Ban">Facebook Ads Stealth & Anti-Ban</option>
                  <option value="Crypto Sniper DEX & Fast Bot">Crypto Sniper DEX & Fast Bot</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1 text-xs">Đánh giá số sao:</label>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 text-amber-400 hover:scale-110 transition-transform"
                  >
                    <Star
                      className={`w-5 h-5 ${star <= rating ? 'fill-amber-400' : 'text-slate-600'}`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1 text-xs">Nội dung chia sẻ cảm nhận:</label>
              <textarea
                required
                rows={3}
                placeholder="Chia sẻ trải nghiệm về tốc độ kích hoạt key, độ mượt của tool, sự hỗ trợ từ DucTri..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full bg-[#050505] border border-white/10 rounded-xl p-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-purple-500"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg transition-all flex items-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Gửi Đánh Giá Ngay</span>
            </button>
          </form>
        )}

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((item) => (
            <div
              key={item.id}
              className="p-6 rounded-3xl bg-[#0a0a0a] border border-white/10 hover:border-purple-500/40 transition-all duration-300 flex flex-col justify-between space-y-4 hover:shadow-[0_0_30px_rgba(168,85,247,0.1)]"
            >
              <div className="space-y-3">
                {/* Header User info */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.avatar}
                      alt={item.authorName}
                      className="w-11 h-11 rounded-full object-cover border border-white/20"
                    />
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>{item.authorName}</span>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" title="Khách hàng đã xác minh mua key" />
                      </h4>
                      <p className="text-[10px] text-slate-400">{item.role}</p>
                    </div>
                  </div>
                </div>

                {/* Star rating & tool name */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-0.5 text-amber-400">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                    ))}
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 truncate max-w-[140px]">
                    {item.toolUsed}
                  </span>
                </div>

                {/* Content */}
                <p className="text-xs text-slate-300 leading-relaxed italic">
                  "{item.content}"
                </p>
              </div>

              {/* Footer Likes & Date */}
              <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500">
                <span>{item.date}</span>
                <button
                  type="button"
                  onClick={() => handleLike(item.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-colors ${
                    likedMap[item.id]
                      ? 'bg-purple-500/20 text-purple-300 font-bold'
                      : 'hover:bg-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <ThumbsUp className="w-3 h-3" />
                  <span>{item.likes} hữu ích</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
