import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useSystem } from '../../contexts/SystemContext';
import { storage } from '../../services/storage';
import { PurchasedLicense, Transaction } from '../../types';
import {
  Key,
  Download,
  Copy,
  CheckCircle,
  RefreshCw,
  Clock,
  Wallet,
  History,
  User as UserIcon,
  Crown,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  PlusCircle,
  Lock,
  FileText,
  Zap
} from 'lucide-react';

export const UserDashboard: React.FC = () => {
  const { currentUser, refreshUserData } = useAuth();
  const { formatVND, formatDate, showToast, setIsTopupModalOpen, openKeyValidator, setActiveView } = useSystem();

  const [activeTab, setActiveTab] = useState<'licenses' | 'transactions' | 'wallet' | 'profile'>('licenses');
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [hwidModalLicense, setHwidModalLicense] = useState<PurchasedLicense | null>(null);
  const [newHwidInput, setNewHwidInput] = useState<string>('');

  // Reseller upgrade application state
  const [resellerReason, setResellerReason] = useState<string>('');
  const [resellerPhone, setResellerPhone] = useState<string>('');
  const [resellerTelegram, setResellerTelegram] = useState<string>('');

  if (!currentUser) return null;

  const purchasedLicenses = storage.getPurchasedLicenses(currentUser.id);
  const transactions = storage.getTransactions(currentUser.id);

  const handleCopyKey = (license: PurchasedLicense) => {
    navigator.clipboard.writeText(license.keyCode);
    setCopiedKeyId(license.id);
    showToast('Đã sao chép Key bản quyền!', license.keyCode, 'success');
    setTimeout(() => setCopiedKeyId(null), 2500);
  };

  const handleResetHwidSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hwidModalLicense) return;

    try {
      storage.resetHwid(hwidModalLicense.id, newHwidInput || undefined);
      refreshUserData();
      setHwidModalLicense(null);
      setNewHwidInput('');
      showToast('Đổi máy tính (Reset HWID) thành công!', 'Bạn có thể kích hoạt key trên thiết bị mới.', 'success');
    } catch (e: any) {
      showToast('Lỗi đổi thiết bị', e.message, 'error');
    }
  };

  const handleApplyReseller = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const updatedUser = {
        ...currentUser,
        resellerStatus: 'pending' as const,
        resellerNote: resellerReason || 'Đăng ký đại lý phân phối từ giao diện khách hàng',
        phone: resellerPhone || currentUser.phone,
        telegram: resellerTelegram || currentUser.telegram,
      };
      storage.updateUser(updatedUser);
      refreshUserData();
      showToast('Gửi yêu cầu nâng cấp Đại lý thành công!', 'Admin sẽ phê duyệt hồ sơ của bạn trong thời gian sớm nhất.', 'success');
    } catch (e: any) {
      showToast('Lỗi gửi hồ sơ', e.message, 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* User Header Profile Card */}
      <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 shadow-[0_0_30px_rgba(0,0,0,0.8)] flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
            alt={currentUser.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-500/40 shadow"
          />
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl font-bold text-white">{currentUser.name}</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                {currentUser.role === 'admin' ? 'Super Admin' : currentUser.role === 'reseller' ? 'Đại Lý VIP' : 'Khách Hàng'}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">{currentUser.email}</p>
            <div className="flex items-center gap-3 text-xs text-slate-400 mt-2">
              <span>Ngày tham gia: {formatDate(currentUser.createdAt)}</span>
            </div>
          </div>
        </div>

        {/* Quick Wallet Stats */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="p-3.5 rounded-xl bg-[#111111] border border-white/10 text-left min-w-40">
            <span className="text-[11px] text-slate-400 block font-semibold uppercase">Số Dư Ví Khả Dụng</span>
            <div className="text-xl font-mono font-bold text-emerald-400 mt-0.5">
              {formatVND(currentUser.balance)}
            </div>
          </div>

          <button
            onClick={() => setIsTopupModalOpen(true)}
            className="px-5 py-3 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Nạp Tiền Vào Ví</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-white/10 bg-[#0a0a0a] p-1 rounded-xl gap-1">
        <button
          onClick={() => setActiveTab('licenses')}
          className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'licenses'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Kho Key Đã Mua ({purchasedLicenses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('transactions')}
          className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'transactions'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Lịch Sử Giao Dịch ({transactions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('wallet')}
          className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'wallet'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Quản Lý Ví Tiền</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'profile'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Crown className="w-4 h-4" />
          <span>Nâng Cấp Đại Lý / Hồ Sơ</span>
        </button>
      </div>

      {/* Tab 1: Purchased Licenses */}
      {activeTab === 'licenses' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">
                Danh Sách Bản Quyền Đang Sở Hữu
              </h3>
              <span className="text-xs text-slate-400">
                Key được cấp tự động và bảo hành đổi HWID máy tính
              </span>
            </div>

            <button
              onClick={() => openKeyValidator('activate')}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5 shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>+ Kích Hoạt Key Mới</span>
            </button>
          </div>

          {purchasedLicenses.length === 0 ? (
            <div className="py-16 text-center rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
              <Key className="w-12 h-12 text-slate-600 mx-auto" />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">Bạn chưa sở hữu Key bản quyền nào</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Bạn có thể kích hoạt mã key đã nhận hoặc khám phá kho tool tự động để bắt đầu ngay!
                </p>
              </div>
              <div className="flex flex-wrap justify-center gap-3 pt-2">
                <button
                  onClick={() => openKeyValidator('activate')}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-2 shadow-lg transition-all"
                >
                  <Zap className="w-4 h-4" />
                  <span>Kích Hoạt Key Bản Quyền Có Sẵn</span>
                </button>
                <button
                  onClick={() => setActiveView('catalog')}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-2 transition-all"
                >
                  <span>Khám Phá Danh Mục Tool</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {purchasedLicenses.map((lic) => (
                <div
                  key={lic.id}
                  className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 hover:border-blue-500/40 transition-all space-y-4 shadow-lg"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5">
                      <img
                        src={lic.toolIcon}
                        alt={lic.toolName}
                        className="w-12 h-12 rounded-xl object-cover border border-white/10 shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm sm:text-base font-bold text-white">{lic.toolName}</h4>
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                            v{lic.version}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                          <span className="text-blue-400 font-medium">{lic.planName}</span>
                          <span>•</span>
                          <span>Đơn hàng: <strong className="font-mono text-slate-300">{lic.orderId}</strong></span>
                          <span>•</span>
                          <span>Mua ngày: {formatDate(lic.purchasedAt)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Expiration & Status */}
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block uppercase">Hạn Sử Dụng</span>
                        <span className="text-xs font-mono font-bold text-amber-300">
                          {formatDate(lic.expiresAt)}
                        </span>
                      </div>
                      <a
                        href={lic.downloadUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#141414] hover:bg-blue-600/30 text-blue-300 border border-white/10 hover:border-blue-500/40 transition-all"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Tải Bản Cài</span>
                      </a>
                    </div>
                  </div>

                  {/* Key Display Strip */}
                  <div className="p-3 rounded-xl bg-[#050505] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 overflow-x-auto">
                      <Key className="w-4 h-4 text-blue-400 shrink-0" />
                      <span className="font-mono text-xs sm:text-sm font-bold text-blue-300 select-all tracking-wider">
                        {lic.keyCode}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleCopyKey(lic)}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold bg-blue-500/20 hover:bg-blue-500/30 text-blue-200 border border-blue-500/40 transition-all"
                      >
                        {copiedKeyId === lic.id ? (
                          <>
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Đã chép</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Sao chép</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => setHwidModalLicense(lic)}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold bg-[#141414] hover:bg-white/10 text-slate-300 border border-white/10 transition-all"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                        <span>Đổi Máy ({lic.hwidResetsRemaining} lần)</span>
                      </button>
                    </div>
                  </div>

                  {/* HWID current status */}
                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                    <span>Mã HWID hiện tại: <strong className="text-slate-400">{lic.hwid || 'Chưa gán máy (Tự động lưu khi kích hoạt)'}</strong></span>
                    <span>Lượt reset máy còn lại: <strong className="text-emerald-400">{lic.hwidResetsRemaining} / 3</strong></span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Transactions */}
      {activeTab === 'transactions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white tracking-wide">
              Lịch Sử Giao Dịch & Biến Động Số Dư
            </h3>
            <span className="text-xs text-slate-400">Minh bạch 100% mọi luồng tiền</span>
          </div>

          <div className="rounded-2xl bg-[#0a0a0a] border border-white/10 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#050505] border-b border-white/10 text-slate-400 uppercase tracking-wider font-mono">
                  <tr>
                    <th className="p-3.5">Mã Giao Dịch</th>
                    <th className="p-3.5">Loại Giao Dịch</th>
                    <th className="p-3.5">Mô Tả Chi Tiết</th>
                    <th className="p-3.5">Số Tiền</th>
                    <th className="p-3.5">Phương Thức</th>
                    <th className="p-3.5">Thời Gian</th>
                    <th className="p-3.5">Trạng Thái</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono">
                  {transactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                      <td className="p-3.5 font-bold text-blue-400">{tx.code}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          tx.type === 'deposit'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : tx.type === 'purchase'
                            ? 'bg-blue-500/20 text-blue-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}>
                          {tx.type === 'deposit' && 'Nạp Tiền'}
                          {tx.type === 'purchase' && 'Mua Key'}
                          {tx.type === 'reseller_commission' && 'Hoa Hồng'}
                          {tx.type === 'withdrawal' && 'Rút Tiền'}
                          {tx.type === 'admin_adjustment' && 'Admin Điều Chỉnh'}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-300 font-sans max-w-xs truncate">
                        {tx.description}
                      </td>
                      <td className="p-3.5 font-bold">
                        <span className={tx.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {tx.amount >= 0 ? `+${formatVND(tx.amount)}` : formatVND(tx.amount)}
                        </span>
                      </td>
                      <td className="p-3.5 uppercase text-slate-400">{tx.paymentMethod}</td>
                      <td className="p-3.5 text-slate-400">{formatDate(tx.createdAt)}</td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          {tx.status === 'completed' ? 'Thành công' : tx.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Wallet */}
      {activeTab === 'wallet' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Ví Tài Khoản</span>
              <Wallet className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <span className="text-xs text-slate-400">Số dư hiện tại:</span>
              <div className="text-2xl font-mono font-extrabold text-emerald-400 mt-1">
                {formatVND(currentUser.balance)}
              </div>
            </div>
            <button
              onClick={() => setIsTopupModalOpen(true)}
              className="w-full py-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-[0_0_15px_rgba(37,99,235,0.3)] flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Nạp Thêm Tiền Tức Thì</span>
            </button>
          </div>

          <div className="md:col-span-2 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h4 className="text-sm font-bold text-white uppercase text-blue-400">
              Chính Sách Thanh Toán & An Toàn Số Dư:
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Số dư ví được bảo đảm 100% không bị khấu trừ vô cớ hoặc hết hạn theo thời gian.</span>
              </li>
              <li className="flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>Tự động kích hoạt đơn hàng không cần thao tác quét QR mỗi lần mua.</span>
              </li>
              <li className="flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Hỗ trợ rút số dư về tài khoản ngân hàng chính chủ nếu có yêu cầu hoàn tiền.</span>
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab 4: Reseller Upgrade / Profile */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Reseller Application Card */}
          <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Crown className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Chương Trình Đại Lý & Đối Tác</h4>
                <p className="text-xs text-slate-400">Hưởng chiết khấu giá sỉ từ 10% đến 35%</p>
              </div>
            </div>

            {currentUser.role === 'reseller' ? (
              <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-300 space-y-2">
                <div className="font-bold flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Bạn hiện đang là Đại Lý Chính Thức ({currentUser.resellerTier?.toUpperCase() || 'GOLD'})</span>
                </div>
                <p className="text-slate-300">
                  Mức chiết khấu hiện tại của bạn là: <strong>-{currentUser.resellerDiscountPercent || 20}%</strong> cho mọi đơn hàng.
                </p>
              </div>
            ) : currentUser.resellerStatus === 'pending' ? (
              <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-500/40 text-xs text-blue-300 space-y-2">
                <div className="font-bold flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-blue-400" />
                  <span>Hồ sơ nâng cấp Đại Lý đang chờ Admin phê duyệt</span>
                </div>
                <p className="text-slate-300">
                  Admin sẽ liên hệ qua Telegram/Zalo của bạn trong vòng 1-2 giờ làm việc.
                </p>
              </div>
            ) : (
              <form onSubmit={handleApplyReseller} className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Số điện thoại / Zalo:</label>
                  <input
                    type="text"
                    required
                    placeholder="0988xxxxxx..."
                    value={resellerPhone}
                    onChange={(e) => setResellerPhone(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Telegram Username:</label>
                  <input
                    type="text"
                    required
                    placeholder="@username..."
                    value={resellerTelegram}
                    onChange={(e) => setResellerTelegram(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Dự kiến kênh phân phối & doanh số:</label>
                  <textarea
                    rows={2}
                    placeholder="VD: Có group cộng đồng MMO 5000 thành viên, dự kiến bán 20 key/tháng..."
                    value={resellerReason}
                    onChange={(e) => setResellerReason(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 rounded-xl p-2.5 text-white"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl font-bold text-xs bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all shadow-[0_0_15px_rgba(245,158,11,0.3)]"
                >
                  Gửi Hồ Sơ Đăng Ký Đại Lý
                </button>
              </form>
            )}
          </div>

          {/* Account info card */}
          <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h4 className="text-sm font-bold text-white uppercase text-blue-400">Thông Tin Tài Khoản:</h4>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-2 border-b border-white/10">
                <span className="text-slate-400">Tên hiển thị:</span>
                <span className="font-bold text-white">{currentUser.name}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-white/10">
                <span className="text-slate-400">Email:</span>
                <span className="font-mono text-blue-400">{currentUser.email}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-white/10">
                <span className="text-slate-400">Phân quyền RBAC:</span>
                <span className="font-mono text-emerald-400 uppercase font-bold">{currentUser.role}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-white/10">
                <span className="text-slate-400">Trạng thái bảo mật:</span>
                <span className="text-emerald-400">Đã xác minh 100%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* HWID Reset Modal */}
      {hwidModalLicense && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <RefreshCw className="w-4 h-4" />
                <span>Đổi Máy Tính (Reset HWID)</span>
              </div>
              <button onClick={() => setHwidModalLicense(null)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Bạn đang yêu cầu gán Key <strong>{hwidModalLicense.toolName}</strong> sang máy tính mới.
              Số lượt reset còn lại: <strong className="text-emerald-400">{hwidModalLicense.hwidResetsRemaining} lần</strong>.
            </p>

            <form onSubmit={handleResetHwidSubmit} className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Mã HWID mới (Để trống để tự sinh):</label>
                <input
                  type="text"
                  placeholder="HWID-WIN11-XXXX-YYYY..."
                  value={newHwidInput}
                  onChange={(e) => setNewHwidInput(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setHwidModalLicense(null)}
                  className="px-4 py-2 rounded-xl text-xs bg-[#141414] hover:bg-white/10 text-slate-300"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950"
                >
                  Xác Nhận Đổi Máy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
