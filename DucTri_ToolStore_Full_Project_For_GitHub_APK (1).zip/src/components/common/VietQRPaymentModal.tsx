import React, { useState, useEffect } from 'react';
import { useSystem } from '../../contexts/SystemContext';
import {
  QrCode,
  Copy,
  CheckCircle2,
  Clock,
  AlertCircle,
  ShieldCheck,
  X,
  Loader2,
  RefreshCw,
  ExternalLink
} from 'lucide-react';

interface VietQRPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  orderCode: string;
  onPaymentSuccess: () => void;
  title?: string;
  description?: string;
}

export const VietQRPaymentModal: React.FC<VietQRPaymentModalProps> = ({
  isOpen,
  onClose,
  amount,
  orderCode,
  onPaymentSuccess,
  title = 'Thanh Toán Tự Động Qua VietQR / Chuyển Khoản 24/7',
  description = 'Hệ thống tự động kích hoạt và cấp Key ngay sau khi nhận được tiền (từ 1 - 3 giây)',
}) => {
  const { settings, formatVND, showToast } = useSystem();
  const [timeLeft, setTimeLeft] = useState<number>(600); // 10 mins
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const bank = settings.paymentConfig.vietqr;
  const qrUrl = `https://api.vietqr.io/image/${bank.bankId}-${bank.accountNo}-${bank.qrTemplate}.jpg?amount=${amount}&addInfo=${encodeURIComponent(orderCode)}&accountName=${encodeURIComponent(bank.accountName)}`;

  useEffect(() => {
    if (!isOpen) {
      setTimeLeft(600);
      setIsVerifying(false);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    showToast(`Đã sao chép ${fieldName}`, text, 'success');
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSimulatePayment = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      showToast('Xác nhận giao dịch thành công!', `Đã nhận ${formatVND(amount)} mã giao dịch ${orderCode}`, 'success');
      onPaymentSuccess();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.9)] overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#050505]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">{title}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{description}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Countdown & Status Bar */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#111111] border border-white/10 text-xs">
            <div className="flex items-center gap-2 text-blue-400">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Đang chờ chuyển khoản tự động...</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-md border border-amber-500/30">
              <Clock className="w-3.5 h-3.5" />
              <span>{formattedTime}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
            {/* VietQR Code Visual */}
            <div className="flex flex-col items-center justify-center p-4 bg-white rounded-2xl border-2 border-blue-500/50 shadow-[0_0_25px_rgba(37,99,235,0.3)]">
              <img
                src={qrUrl}
                alt="VietQR Code"
                className="w-52 h-52 object-contain rounded-lg"
                onError={(e) => {
                  // Fallback to QR generator if api.vietqr is slow
                  (e.target as HTMLImageElement).src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=2|99|${bank.accountNo}|${amount}|${orderCode}|0|0|${bank.bankId}`;
                }}
              />
              <div className="mt-2 text-[11px] font-semibold text-slate-800 tracking-wider uppercase text-center flex items-center gap-1">
                <span>Quét qua App Ngân Hàng / MoMo</span>
              </div>
            </div>

            {/* Transfer Details Form */}
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Ngân Hàng Thụ Hưởng</label>
                <div className="mt-1 p-2.5 rounded-lg bg-[#111111] border border-white/10 text-xs font-semibold text-white">
                  {bank.bankName}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
                  <span>Số Tài Khoản</span>
                  {copiedField === 'stk' && <span className="text-emerald-400 font-mono lowercase">đã chép!</span>}
                </div>
                <div className="mt-1 flex items-center justify-between p-2.5 rounded-lg bg-[#111111] border border-white/10 text-xs text-white font-mono">
                  <span className="font-bold text-sm text-blue-400">{bank.accountNo}</span>
                  <button
                    onClick={() => copyToClipboard(bank.accountNo, 'stk')}
                    className="p-1 text-slate-400 hover:text-blue-300 hover:bg-white/10 rounded transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Chủ Tài Khoản</label>
                <div className="mt-1 p-2.5 rounded-lg bg-[#111111] border border-white/10 text-xs font-semibold text-slate-200">
                  {bank.accountName}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
                  <span>Số Tiền Chính Xác</span>
                  {copiedField === 'amount' && <span className="text-emerald-400 font-mono lowercase">đã chép!</span>}
                </div>
                <div className="mt-1 flex items-center justify-between p-2.5 rounded-lg bg-[#111111] border border-emerald-500/30 text-xs text-white font-mono">
                  <span className="font-bold text-base text-emerald-400">{formatVND(amount)}</span>
                  <button
                    onClick={() => copyToClipboard(amount.toString(), 'amount')}
                    className="p-1 text-slate-400 hover:text-emerald-400 hover:bg-white/10 rounded transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
                  <span>Nội Dung Chuyển Khoản (Bắt Buộc)</span>
                  {copiedField === 'nd' && <span className="text-emerald-400 font-mono lowercase">đã chép!</span>}
                </div>
                <div className="mt-1 flex items-center justify-between p-2.5 rounded-lg bg-[#111111] border border-amber-500/40 text-xs text-white font-mono">
                  <span className="font-bold text-sm text-amber-300 select-all">{orderCode}</span>
                  <button
                    onClick={() => copyToClipboard(orderCode, 'nd')}
                    className="p-1 text-slate-400 hover:text-amber-300 hover:bg-white/10 rounded transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Warning note */}
          <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30 flex items-start gap-2.5 text-xs text-amber-200/90">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              Vui lòng chuyển <strong>chính xác số tiền</strong> và <strong>nội dung chuyển khoản</strong> để hệ thống tự động nhận diện và xuất key trong 3 giây.
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-5 border-t border-white/10 bg-[#050505] flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <span>Mã hóa SSL 256-bit An toàn tuyệt đối</span>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-semibold bg-[#141414] hover:bg-white/10 text-slate-300 transition-colors"
            >
              Hủy Bỏ
            </button>
            <button
              onClick={handleSimulatePayment}
              disabled={isVerifying}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.4)] transition-all"
            >
              {isVerifying ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang Kiểm Tra Bank...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Tôi Đã Chuyển Tiền / Quét Xong</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
