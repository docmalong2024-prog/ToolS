import React, { useState, useEffect, useRef } from 'react';
import { useSystem } from '../../contexts/SystemContext';
import { storage } from '../../services/storage';
import { ToolItem } from '../../types';
import {
  Search,
  Zap,
  Shield,
  Wallet,
  Compass,
  FileText,
  User,
  Users,
  Headphones,
  Sparkles,
  Command,
  ArrowRight,
  ExternalLink,
  X,
  Download
} from 'lucide-react';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTool?: (tool: ToolItem) => void;
}

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({
  isOpen,
  onClose,
  onSelectTool,
}) => {
  const { setActiveView, openKeyValidator, setIsTopupModalOpen, setIsAppDownloadModalOpen } = useSystem();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const tools = storage.getTools();

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Handle Escape key or Ctrl+K toggle
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) {
          onClose();
        }
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredTools = tools.filter(
    (t) =>
      t.name.toLowerCase().includes(query.toLowerCase()) ||
      t.tagline.toLowerCase().includes(query.toLowerCase()) ||
      t.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase()))
  );

  const quickActions = [
    {
      id: 'download_app',
      label: '📥 Tải File App Client Desktop (.EXE) [Chỉ có trên bản thử nghiệm]',
      icon: Download,
      color: 'text-cyan-400',
      action: () => {
        onClose();
        setIsAppDownloadModalOpen(true);
      },
    },
    {
      id: 'act_key',
      label: 'Kích Hoạt Key Bản Quyền (Nhập License & HWID)',
      icon: Zap,
      color: 'text-emerald-400',
      action: () => {
        onClose();
        openKeyValidator('activate');
      },
    },
    {
      id: 'val_key',
      label: 'Tra Cứu / Kiểm Tra Tính Hợp Lệ Của Key',
      icon: Shield,
      color: 'text-blue-400',
      action: () => {
        onClose();
        openKeyValidator('validate');
      },
    },
    {
      id: 'topup',
      label: 'Nạp Tiền Vào Ví (VietQR Pro 24/7 / MoMo)',
      icon: Wallet,
      color: 'text-amber-400',
      action: () => {
        onClose();
        setIsTopupModalOpen(true);
      },
    },
    {
      id: 'reseller',
      label: 'Trang Đối Tác & Đại Lý Phân Phối Chiết Khấu Cao',
      icon: Users,
      color: 'text-purple-400',
      action: () => {
        onClose();
        setActiveView('reseller_dashboard');
      },
    },
    {
      id: 'zalo_support',
      label: 'Liên Hệ Hỗ Trợ Kỹ Thuật Zalo: 0826130621 (App By DucTri)',
      icon: Headphones,
      color: 'text-sky-400',
      action: () => {
        window.open('https://zalo.me/0826130621', '_blank');
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-[#0a0a0a] border border-blue-500/30 rounded-3xl shadow-[0_0_60px_rgba(0,0,0,0.9),0_0_30px_rgba(37,99,235,0.2)] overflow-hidden">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-white/10 bg-[#050505]">
          <Search className="w-5 h-5 text-blue-400 mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Tìm kiếm nhanh tool, tính năng, kích hoạt key, nạp tiền..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none"
          />
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-2 py-1 text-[10px] font-mono text-slate-400 bg-[#161616] border border-white/10 rounded-md">
            ESC
          </kbd>
          <button
            onClick={onClose}
            className="sm:hidden text-slate-400 hover:text-white p-1 ml-2"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Content List */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {/* Quick Commands */}
          {!query && (
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 px-3 font-semibold">
                Lệnh Thao Tác Nhanh
              </span>
              {quickActions.map((act) => {
                const Icon = act.icon;
                return (
                  <button
                    key={act.id}
                    onClick={act.action}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/5 text-left transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#141414] border border-white/10 flex items-center justify-center">
                        <Icon className={`w-4 h-4 ${act.color}`} />
                      </div>
                      <span className="text-xs font-medium text-slate-200 group-hover:text-white">
                        {act.label}
                      </span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-white transition-transform group-hover:translate-x-1" />
                  </button>
                );
              })}
            </div>
          )}

          {/* Tools List */}
          <div className="space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 px-3 font-semibold flex items-center justify-between">
              <span>{query ? `Kết quả tìm kiếm (${filteredTools.length})` : 'Phần Mềm & Tool Phổ Biến'}</span>
              <span className="text-[10px] text-blue-400 lowercase">Bấm để xem chi tiết</span>
            </span>

            {filteredTools.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-500">
                Không tìm thấy phần mềm phù hợp với từ khóa "{query}"
              </div>
            ) : (
              filteredTools.slice(0, 6).map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => {
                    onClose();
                    if (onSelectTool) onSelectTool(tool);
                    else setActiveView('catalog');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white/5 text-left transition-colors group border border-transparent hover:border-white/10"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={tool.images[0] || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100'}
                      alt={tool.name}
                      className="w-10 h-10 rounded-lg object-cover border border-white/10 shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white group-hover:text-blue-300 truncate">
                          {tool.name}
                        </h4>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 shrink-0">
                          v{tool.version}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">{tool.tagline}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      Từ {tool.plans[0]?.salePrice ? `${(tool.plans[0].salePrice / 1000).toLocaleString('vi-VN')}k` : 'Free'}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-blue-400 transition-transform group-hover:translate-x-1" />
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-[#050505] border-t border-white/10 flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-2">
            <span>Sử dụng phím tắt:</span>
            <kbd className="px-1.5 py-0.5 rounded bg-[#161616] border border-white/10 text-[10px] font-mono text-slate-300">
              Ctrl + K
            </kbd>
            <span>để mở nhanh bảng này ở bất kỳ đâu</span>
          </div>
          <span className="font-mono text-slate-400">DucTri ToolStore Pro v3.5</span>
        </div>
      </div>
    </div>
  );
};
