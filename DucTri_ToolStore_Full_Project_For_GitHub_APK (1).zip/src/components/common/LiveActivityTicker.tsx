import React, { useState, useEffect } from 'react';
import { Zap, CheckCircle2, ShieldCheck, ShoppingCart, UserCheck, X } from 'lucide-react';
import { storage } from '../../services/storage';

interface LiveEvent {
  id: string;
  type: 'purchase' | 'activation' | 'topup';
  user: string;
  location: string;
  content: string;
  detail: string;
  timeAgo: string;
  badge: string;
}

const SAMPLE_EVENTS: LiveEvent[] = [
  {
    id: '1',
    type: 'purchase',
    user: '098***341',
    location: 'Hà Nội',
    content: 'Vừa mua bản quyền TikTok Shop Auto',
    detail: 'Gói Vĩnh Viễn • Kích hoạt tự động',
    timeAgo: '1 phút trước',
    badge: 'Đơn Mới',
  },
  {
    id: '2',
    type: 'activation',
    user: '091***882',
    location: 'TP. Hồ Chí Minh',
    content: 'Đã kích hoạt thành công Shopee Sniper Pro',
    detail: 'Mã HWID: WIN-PC-89A1-** • 3 lượt đổi máy',
    timeAgo: '2 phút trước',
    badge: 'Kích Hoạt',
  },
  {
    id: '3',
    type: 'topup',
    user: '037***995',
    location: 'Đà Nẵng',
    content: 'Nạp +1,500,000đ vào ví tài khoản',
    detail: 'Qua VietQR Pro 24/7 • Đã nhận hoa hồng',
    timeAgo: '4 phút trước',
    badge: 'Nạp Tiền',
  },
  {
    id: '4',
    type: 'purchase',
    user: '086***120',
    location: 'Cần Thơ',
    content: 'Vừa mua AI Video Auto Render 4K',
    detail: 'Gói 1 Năm • Tự động lách bản quyền',
    timeAgo: '6 phút trước',
    badge: 'Đơn Mới',
  },
  {
    id: '5',
    type: 'activation',
    user: '094***653',
    location: 'Hải Phòng',
    content: 'Đã kích hoạt Key Facebook Ads Stealth',
    detail: 'Gói 3 Tháng • Anti-detect proxy',
    timeAgo: '8 phút trước',
    badge: 'Kích Hoạt',
  }
];

export const LiveActivityTicker: React.FC = () => {
  const [currentEventIndex, setCurrentEventIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    if (isPaused || isDismissed) return;

    const interval = setInterval(() => {
      setIsVisible(false);
      setTimeout(() => {
        setCurrentEventIndex((prev) => (prev + 1) % SAMPLE_EVENTS.length);
        setIsVisible(true);
      }, 400);
    }, 6000);

    return () => clearInterval(interval);
  }, [isPaused, isDismissed]);

  if (isDismissed) return null;

  const event = SAMPLE_EVENTS[currentEventIndex];

  return (
    <div
      className={`fixed bottom-20 left-4 z-40 max-w-sm transition-all duration-500 ease-out transform ${
        isVisible ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-4 opacity-0 scale-95'
      }`}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="relative p-3 rounded-2xl bg-[#0a0a0a]/95 border border-white/10 backdrop-blur-xl shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(37,99,235,0.15)] flex items-start gap-3 text-xs">
        {/* Type Icon */}
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
            event.type === 'purchase'
              ? 'bg-blue-500/10 border-blue-500/30 text-blue-400'
              : event.type === 'activation'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
          }`}
        >
          {event.type === 'purchase' && <ShoppingCart className="w-4 h-4" />}
          {event.type === 'activation' && <Zap className="w-4 h-4 fill-current" />}
          {event.type === 'topup' && <ShieldCheck className="w-4 h-4" />}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 pr-4">
          <div className="flex items-center gap-1.5 mb-0.5">
            <span className="font-bold text-white truncate">{event.user}</span>
            <span className="text-[10px] text-slate-500 font-medium">({event.location})</span>
            <span
              className={`text-[9px] font-mono px-1.5 py-0.2 rounded-full font-bold ml-auto shrink-0 ${
                event.type === 'purchase'
                  ? 'bg-blue-500/20 text-blue-300'
                  : event.type === 'activation'
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-amber-500/20 text-amber-300'
              }`}
            >
              {event.badge}
            </span>
          </div>

          <p className="text-slate-200 text-[11px] font-medium leading-snug line-clamp-1">{event.content}</p>
          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
            <span className="truncate text-slate-400">{event.detail}</span>
            <span className="shrink-0 text-slate-500 font-mono">{event.timeAgo}</span>
          </div>
        </div>

        {/* Close Button */}
        <button
          onClick={() => setIsDismissed(true)}
          className="absolute top-2 right-2 text-slate-500 hover:text-white p-1 rounded-md transition-colors"
          title="Tắt thông báo này"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
