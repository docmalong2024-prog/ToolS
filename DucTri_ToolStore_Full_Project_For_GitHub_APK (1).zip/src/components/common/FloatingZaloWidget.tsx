import React, { useState } from 'react';
import { Phone, MessageCircle, X, ExternalLink, Check, Copy, User } from 'lucide-react';

export const FloatingZaloWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const zaloPhone = '0826130621';
  const authorName = 'DucTri';
  const zaloLink = `https://zalo.me/${zaloPhone}`;

  const handleCopyPhone = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(zaloPhone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 font-sans">
      {/* Popover Card when opened */}
      {isOpen && (
        <div className="w-80 p-5 rounded-2xl bg-[#0a0a0a] border border-blue-500/40 shadow-[0_10px_40px_rgba(0,0,0,0.9)] text-slate-200 animate-in fade-in slide-in-from-bottom-4 space-y-4">
          <div className="flex items-start justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-mono font-bold">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-white text-sm">App By {authorName}</h4>
                <p className="text-[11px] text-blue-400 font-mono">Zalo & Hỗ trợ kỹ thuật</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-3.5 rounded-xl bg-[#111111] border border-white/10 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Số điện thoại / Zalo:</span>
              <button
                onClick={handleCopyPhone}
                className="flex items-center gap-1 text-blue-400 hover:text-blue-300 font-mono font-bold"
                title="Sao chép số"
              >
                <span>{zaloPhone}</span>
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <div className="text-[11px] text-slate-400 leading-relaxed">
              Tư vấn mua tool, hướng dẫn kích hoạt key, đăng ký đại lý chiết khấu hoặc đặt làm tool theo yêu cầu.
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <a
              href={zaloLink}
              target="_blank"
              rel="noreferrer"
              className="py-2.5 px-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] transition-all flex items-center justify-center gap-1.5"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Chat Zalo</span>
            </a>

            <a
              href={`tel:${zaloPhone}`}
              className="py-2.5 px-3 rounded-xl font-bold text-xs bg-[#111111] hover:bg-white/10 border border-white/10 text-white transition-all flex items-center justify-center gap-1.5"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Gọi Ngay</span>
            </a>
          </div>
        </div>
      )}

      {/* Floating Main Button */}
      <div className="flex items-center gap-2">
        {/* Quick Tag Label */}
        <a
          href={zaloLink}
          target="_blank"
          rel="noreferrer"
          className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#0a0a0a]/90 backdrop-blur-md border border-blue-500/40 text-xs font-mono shadow-[0_0_20px_rgba(37,99,235,0.2)] hover:border-blue-400 transition-all text-white group"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-blue-400">App By DucTri</span>
          <span className="text-slate-500">•</span>
          <span className="text-slate-300 group-hover:text-blue-300 font-bold">Zalo: {zaloPhone}</span>
          <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-blue-400" />
        </a>

        {/* Floating Bubble Icon */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Liên hệ Zalo DucTri"
          className="relative w-13 h-13 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 text-white p-3.5 shadow-[0_0_25px_rgba(37,99,235,0.6)] hover:scale-105 transition-all flex items-center justify-center border-2 border-white/20 group"
        >
          <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border border-[#0a0a0a]"></span>
          </span>
          <MessageCircle className="w-6 h-6 animate-pulse" />
        </button>
      </div>
    </div>
  );
};
