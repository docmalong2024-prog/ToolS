import React from 'react';
import { useSystem, Toast } from '../../contexts/SystemContext';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useSystem();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2.5 max-w-md w-full pointer-events-none px-4 sm:px-0">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onRemove={() => removeToast(toast.id)} />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{ toast: Toast; onRemove: () => void }> = ({ toast, onRemove }) => {
  const icons = {
    success: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />,
    error: <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />,
    warning: <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />,
    info: <Info className="w-5 h-5 text-cyan-400 shrink-0" />,
  };

  const borderBgs = {
    success: 'border-emerald-500/40 bg-slate-900/95 shadow-[0_0_20px_rgba(16,185,129,0.2)]',
    error: 'border-rose-500/40 bg-slate-900/95 shadow-[0_0_20px_rgba(244,63,94,0.2)]',
    warning: 'border-amber-500/40 bg-slate-900/95 shadow-[0_0_20px_rgba(245,158,11,0.2)]',
    info: 'border-cyan-500/40 bg-slate-900/95 shadow-[0_0_20px_rgba(6,182,212,0.2)]',
  };

  return (
    <div
      className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl border backdrop-blur-md transition-all duration-300 animate-in fade-in slide-in-from-right-5 ${borderBgs[toast.type]}`}
    >
      <div className="mt-0.5">{icons[toast.type]}</div>
      <div className="flex-1 min-w-0">
        <h4 className="text-sm font-semibold text-white tracking-wide">{toast.title}</h4>
        {toast.message && <p className="text-xs text-slate-300 mt-1 leading-relaxed">{toast.message}</p>}
      </div>
      <button
        onClick={onRemove}
        className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-slate-800"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
