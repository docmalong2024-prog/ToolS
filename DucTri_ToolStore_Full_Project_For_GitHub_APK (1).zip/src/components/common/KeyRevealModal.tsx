import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { PurchasedLicense } from '../../types';
import { useSystem } from '../../contexts/SystemContext';
import {
  CheckCircle,
  Copy,
  Download,
  Key,
  ShieldCheck,
  FileText,
  ExternalLink,
  X,
  Sparkles,
  Layers
} from 'lucide-react';

interface KeyRevealModalProps {
  isOpen: boolean;
  onClose: () => void;
  licenses: PurchasedLicense[];
  orderId: string;
}

export const KeyRevealModal: React.FC<KeyRevealModalProps> = ({
  isOpen,
  onClose,
  licenses,
  orderId,
}) => {
  const { showToast, formatDate } = useSystem();
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && licenses.length > 0) {
      // Fire victory confetti
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#06b6d4', '#3b82f6', '#10b981', '#a855f7'],
        });
      } catch (e) {
        console.log('Confetti error:', e);
      }
    }
  }, [isOpen, licenses]);

  if (!isOpen || licenses.length === 0) return null;

  const handleCopy = (license: PurchasedLicense) => {
    navigator.clipboard.writeText(license.keyCode);
    setCopiedKeyId(license.id);
    showToast('Đã sao chép Key bản quyền!', license.keyCode, 'success');
    setTimeout(() => setCopiedKeyId(null), 2500);
  };

  const handleCopyAll = () => {
    const text = licenses
      .map(
        (l, idx) =>
          `[#${idx + 1}] ${l.toolName} (${l.planName})\nKey: ${l.keyCode}\nHạn dùng: ${formatDate(l.expiresAt)}\nLink tải: ${l.downloadUrl}\n------------------------`
      )
      .join('\n\n');
    navigator.clipboard.writeText(text);
    showToast('Đã sao chép toàn bộ danh sách Key!', 'Bạn có thể lưu vào file ghi chú cá nhân.', 'success');
  };

  const handleDownloadTxt = () => {
    const text = `========================================================\n` +
      `TOOLSTORE PRO - BIÊN LAI CẤP PHÁT BẢN QUYỀN TỰ ĐỘNG\n` +
      `Mã Đơn Hàng: ${orderId}\n` +
      `Thời gian cấp: ${new Date().toLocaleString('vi-VN')}\n` +
      `========================================================\n\n` +
      licenses
        .map(
          (l, i) =>
            `SẢN PHẨM #${i + 1}: ${l.toolName}\n` +
            `Gói bản quyền: ${l.planName}\n` +
            `Mã Key: ${l.keyCode}\n` +
            `Hạn sử dụng: ${formatDate(l.expiresAt)}\n` +
            `Phiên bản: v${l.version}\n` +
            `Link tải cài đặt: ${l.downloadUrl}\n` +
            `Lượt đổi HWID còn lại: ${l.hwidResetsRemaining}\n` +
            `--------------------------------------------------------\n`
        )
        .join('\n') +
      `\nHƯỚNG DẪN KÍCH HOẠT:\n` +
      `1. Tải phần mềm từ đường link trên và tiến hành cài đặt.\n` +
      `2. Khởi chạy phần mềm, dán Mã Key vào ô 'License Key' và bấm 'Kích hoạt'.\n` +
      `3. Nếu gặp sự cố hoặc cần đổi máy tính (Reset HWID), vào mục 'Kho Key của tôi' trên website.\n\n` +
      `Hỗ trợ kỹ thuật 24/7 qua Telegram: @ToolStorePro_Support`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ToolStore_Order_${orderId}_Keys.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Đã xuất file text Key bản quyền!', 'File đã được lưu vào máy của bạn.', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.9)] overflow-hidden my-8">
        {/* Neon Top Bar */}
        <div className="h-1.5 w-full bg-gradient-to-r from-blue-600 via-indigo-500 to-blue-400" />

        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-start justify-between bg-[#050505]">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.3)]">
              <Sparkles className="w-6 h-6 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold text-white tracking-wide">Thanh Toán & Cấp Key Tức Thì!</h3>
                <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  {orderId}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Hệ thống tự động kích hoạt và xuất Key bản quyền vào tài khoản của bạn
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Keys List */}
        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          {licenses.map((lic, index) => (
            <div
              key={lic.id}
              className="p-4 rounded-xl bg-[#111111] border border-white/10 hover:border-blue-500/40 transition-all group"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  {lic.toolIcon ? (
                    <img
                      src={lic.toolIcon}
                      alt={lic.toolName}
                      className="w-10 h-10 rounded-lg object-cover border border-white/10 shrink-0"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
                      <Key className="w-5 h-5" />
                    </div>
                  )}
                  <div>
                    <h4 className="text-sm font-bold text-white group-hover:text-blue-300 transition-colors">
                      {lic.toolName}
                    </h4>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span className="text-blue-400 font-medium">{lic.planName}</span>
                      <span>•</span>
                      <span>Hạn dùng: <strong className="text-slate-300">{formatDate(lic.expiresAt)}</strong></span>
                      <span>•</span>
                      <span className="text-emerald-400">v{lic.version}</span>
                    </div>
                  </div>
                </div>

                <a
                  href={lic.downloadUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 text-xs bg-[#181818] hover:bg-blue-600/30 text-blue-300 border border-white/10 hover:border-blue-500/40 px-3 py-1.5 rounded-lg transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tải Tool</span>
                </a>
              </div>

              {/* Key Box */}
              <div className="mt-3 relative flex items-center">
                <div className="w-full bg-[#050505] border border-white/10 rounded-lg px-4 py-2.5 font-mono text-sm text-blue-300 select-all tracking-wider shadow-inner flex items-center justify-between">
                  <div className="flex items-center gap-2 overflow-x-auto">
                    <Key className="w-4 h-4 text-blue-400 shrink-0" />
                    <span className="font-bold">{lic.keyCode}</span>
                  </div>
                  <button
                    onClick={() => handleCopy(lic)}
                    className="ml-3 shrink-0 flex items-center gap-1 text-xs px-2.5 py-1 rounded bg-blue-500/20 hover:bg-blue-500/30 text-blue-200 border border-blue-500/40 transition-all"
                  >
                    {copiedKeyId === lic.id ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-300 font-medium">Đã chép!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Sao chép</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}

          {/* Guide notice */}
          <div className="p-3.5 rounded-xl bg-blue-950/20 border border-blue-500/20 flex items-start gap-3 text-xs text-slate-300">
            <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-blue-300">Bảo hành 100% trọn thời hạn:</strong> Key đã được lưu trữ vĩnh viễn trong mục <strong>"Kho Key của tôi"</strong>. Mỗi key hỗ trợ tối đa 3 lần đổi máy tính (HWID Reset) miễn phí.
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t border-white/10 bg-[#050505] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyAll}
              className="flex items-center gap-1.5 text-xs bg-[#141414] hover:bg-white/10 text-slate-200 px-3.5 py-2 rounded-xl border border-white/10 transition-colors"
            >
              <Copy className="w-4 h-4" />
              <span>Chép tất cả Key</span>
            </button>
            <button
              onClick={handleDownloadTxt}
              className="flex items-center gap-1.5 text-xs bg-[#141414] hover:bg-white/10 text-slate-200 px-3.5 py-2 rounded-xl border border-white/10 transition-colors"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>Xuất File .TXT</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl font-semibold text-sm bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.4)] transition-all"
          >
            Hoàn Tất & Xem Kho Key
          </button>
        </div>
      </div>
    </div>
  );
};
