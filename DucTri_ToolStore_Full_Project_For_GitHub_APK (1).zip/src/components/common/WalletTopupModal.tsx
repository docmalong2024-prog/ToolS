import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useSystem } from '../../contexts/SystemContext';
import { storage } from '../../services/storage';
import { VietQRPaymentModal } from './VietQRPaymentModal';
import {
  Wallet,
  CreditCard,
  QrCode,
  Smartphone,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  X
} from 'lucide-react';

interface WalletTopupModalProps {
  isOpen?: boolean;
  onClose?: () => void;
}

const PRESET_AMOUNTS = [
  50000,
  100000,
  200000,
  500000,
  1000000,
  2000000,
  5000000,
  10000000,
];

export const WalletTopupModal: React.FC<WalletTopupModalProps> = ({
  isOpen: propIsOpen,
  onClose: propOnClose,
}) => {
  const { currentUser, refreshUserData, isAuthenticated } = useAuth();
  const {
    isTopupModalOpen,
    setIsTopupModalOpen,
    formatVND,
    showToast,
    setIsAuthModalOpen,
  } = useSystem();

  const isOpen = propIsOpen !== undefined ? propIsOpen : isTopupModalOpen;
  const onClose = propOnClose || (() => setIsTopupModalOpen(false));

  const [selectedAmount, setSelectedAmount] = useState<number>(200000);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'vietqr' | 'momo'>('vietqr');
  const [showQRModal, setShowQRModal] = useState<boolean>(false);
  const [activeTxRef, setActiveTxRef] = useState<string>('');

  if (!isOpen) return null;

  const currentAmount = customAmount ? parseInt(customAmount.replace(/\D/g, ''), 10) || 0 : selectedAmount;

  const handleStartTopup = () => {
    if (currentAmount < 10000) {
      showToast('Số tiền nạp tối thiểu là 10.000 ₫', undefined, 'error');
      return;
    }
    const txRef = `NAP${Math.floor(100000 + Math.random() * 900000)}`;
    setActiveTxRef(txRef);
    setShowQRModal(true);
  };

  const handlePaymentSuccess = () => {
    const targetUserId = currentUser?.id || 'user_customer';
    try {
      storage.topupWallet({
        userId: targetUserId,
        amount: currentAmount,
        paymentMethod,
        txRef: activeTxRef,
        description: `Nạp tiền tài khoản ${formatVND(currentAmount)} qua ${paymentMethod.toUpperCase()}`,
      });
      refreshUserData();
      setShowQRModal(false);
      onClose();
      showToast(`Nạp thành công +${formatVND(currentAmount)} vào ví!`, 'Số dư ví đã được cộng tiền ngay lập tức.', 'success');
    } catch (e: any) {
      showToast('Lỗi nạp tiền', e.message, 'error');
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
        <div className="relative w-full max-w-lg bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.9)] overflow-hidden my-6">
          {/* Header */}
          <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#050505]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white tracking-wide">Nạp Tiền Vào Ví ToolStore</h3>
                <p className="text-xs text-slate-400">
                  Số dư hiện tại:{' '}
                  <strong className="text-emerald-400 font-mono">
                    {currentUser ? formatVND(currentUser.balance) : '0 ₫'}
                  </strong>
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Amount Selection */}
            <div>
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2.5">
                1. Chọn Mệnh Giá Nạp Tiền
              </label>
              <div className="grid grid-cols-4 gap-2.5">
                {PRESET_AMOUNTS.map((amt) => {
                  const isSelected = !customAmount && selectedAmount === amt;
                  return (
                    <button
                      key={amt}
                      onClick={() => {
                        setSelectedAmount(amt);
                        setCustomAmount('');
                      }}
                      className={`p-2.5 rounded-xl border text-xs font-mono font-bold transition-all ${
                        isSelected
                          ? 'border-blue-500 bg-blue-500/15 text-blue-300 shadow-[0_0_15px_rgba(37,99,235,0.25)]'
                          : 'border-white/10 bg-[#111111] text-slate-300 hover:border-white/20 hover:text-white'
                      }`}
                    >
                      {amt >= 1000000 ? `${amt / 1000000} Triệu` : `${amt / 1000}k`}
                    </button>
                  );
                })}
              </div>

              {/* Custom amount */}
              <div className="mt-3">
                <input
                  type="number"
                  placeholder="Hoặc nhập số tiền tùy chọn (VD: 350000)..."
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-600 font-mono transition-colors"
                />
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2.5">
                2. Chọn Kênh Nạp Tiền Tự Động
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('vietqr')}
                  className={`p-3.5 rounded-xl border flex items-center gap-3 transition-all text-left ${
                    paymentMethod === 'vietqr'
                      ? 'border-blue-500 bg-blue-500/10 shadow-[0_0_20px_rgba(37,99,235,0.2)]'
                      : 'border-white/10 bg-[#111111] hover:border-white/20'
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">VietQR Pro 24/7</div>
                    <div className="text-[10px] text-blue-400">Tự động duyệt 3 giây</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('momo')}
                  className={`p-3.5 rounded-xl border flex items-center gap-3 transition-all text-left ${
                    paymentMethod === 'momo'
                      ? 'border-pink-500 bg-pink-500/10 shadow-[0_0_20px_rgba(236,72,153,0.2)]'
                      : 'border-white/10 bg-[#111111] hover:border-white/20'
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center shrink-0">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Ví MoMo</div>
                    <div className="text-[10px] text-pink-400">Quét mã QR MoMo</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Total summary */}
            <div className="p-4 rounded-xl bg-[#111111] border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400">Số tiền cần thanh toán:</span>
                <div className="text-lg font-mono font-bold text-emerald-400 mt-0.5">
                  {formatVND(currentAmount)}
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-500 block">Khuyến mãi cộng thêm:</span>
                <span className="text-xs font-mono font-semibold text-blue-400">+0% (Miễn phí nạp)</span>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="p-5 border-t border-white/10 bg-[#050505] flex items-center justify-between">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition-colors"
            >
              Hủy
            </button>
            <button
              onClick={handleStartTopup}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all"
            >
              <span>Tiếp Tục Tạo Mã QR</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* VietQR Payment Modal */}
      {showQRModal && (
        <VietQRPaymentModal
          isOpen={showQRModal}
          onClose={() => setShowQRModal(false)}
          amount={currentAmount}
          orderCode={activeTxRef}
          onPaymentSuccess={handlePaymentSuccess}
          title={`Nạp ${formatVND(currentAmount)} Vào Ví`}
          description="Quét mã QR bằng App Ngân Hàng hoặc Ví MoMo để hoàn tất"
        />
      )}
    </>
  );
};
