import React, { useState, useEffect } from 'react';
import { storage } from '../../services/storage';
import { useSystem } from '../../contexts/SystemContext';
import { useAuth } from '../../contexts/AuthContext';
import { PurchasedLicense } from '../../types';
import {
  ShieldCheck,
  Search,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Key,
  X,
  Sparkles,
  Zap,
  Download,
  Copy,
  Check,
  Monitor,
  RefreshCw,
  Clock,
  ArrowRight,
  UserCheck,
  ExternalLink
} from 'lucide-react';

interface KeyValidatorModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  defaultTab?: 'activate' | 'validate';
}

export const KeyValidatorModal: React.FC<KeyValidatorModalProps> = ({
  isOpen: propIsOpen,
  onClose: propOnClose,
  defaultTab = 'activate'
}) => {
  const {
    formatDate,
    showToast,
    setActiveView,
    isKeyValidatorOpen,
    setIsKeyValidatorOpen,
    keyValidatorInitialTab
  } = useSystem();
  const { currentUser } = useAuth();

  const isOpen = propIsOpen !== undefined ? propIsOpen : isKeyValidatorOpen;
  const onClose = propOnClose || (() => setIsKeyValidatorOpen(false));

  const [activeTab, setActiveTab] = useState<'activate' | 'validate'>('activate');
  const [keyCodeInput, setKeyCodeInput] = useState('');
  const [hwidInput, setHwidInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  // Results
  const [activationResult, setActivationResult] = useState<{
    success: boolean;
    message: string;
    license?: PurchasedLicense;
  } | null>(null);

  const [validationResult, setValidationResult] = useState<{
    found: boolean;
    toolName?: string;
    planName?: string;
    version?: string;
    status?: 'active' | 'expired' | 'revoked' | 'available';
    expiresAt?: string;
    hwid?: string;
    hwidResetsRemaining?: number;
    purchasedAt?: string;
    message?: string;
    downloadUrl?: string;
  } | null>(null);

  // Generate or retrieve current device HWID
  const getDeviceHwid = () => {
    let savedHwid = localStorage.getItem('toolstore_device_hwid');
    if (!savedHwid) {
      savedHwid = `WIN-PC-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      localStorage.setItem('toolstore_device_hwid', savedHwid);
    }
    return savedHwid;
  };

  useEffect(() => {
    if (isOpen) {
      setActiveTab(keyValidatorInitialTab || defaultTab || 'activate');
      setActivationResult(null);
      setValidationResult(null);
      if (!hwidInput) {
        setHwidInput(getDeviceHwid());
      }
    }
  }, [isOpen, keyValidatorInitialTab, defaultTab]);

  if (!isOpen) return null;

  // Handle Activate Key
  const handleActivateKey = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanKey = keyCodeInput.trim();
    if (!cleanKey) {
      showToast('Vui lòng nhập mã Key cần kích hoạt', undefined, 'error');
      return;
    }

    setIsProcessing(true);
    setActivationResult(null);

    setTimeout(() => {
      try {
        const res = storage.activateKey({
          keyCode: cleanKey,
          hwid: hwidInput.trim() || getDeviceHwid(),
          userId: currentUser?.id,
          userEmail: currentUser?.email,
        });

        setIsProcessing(false);
        setActivationResult({
          success: true,
          message: res.message,
          license: res.license,
        });
        showToast('Kích hoạt thành công!', `Key cho ${res.license.toolName} đã được kích hoạt.`, 'success');
      } catch (err: any) {
        setIsProcessing(false);
        setActivationResult({
          success: false,
          message: err.message || 'Lỗi khi kích hoạt Key bản quyền!',
        });
        showToast('Kích hoạt thất bại', err.message, 'error');
      }
    }, 600);
  };

  // Handle Validate / Check Key
  const handleValidateKey = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanKey = keyCodeInput.trim();
    if (!cleanKey) {
      showToast('Vui lòng nhập mã Key cần kiểm tra', undefined, 'error');
      return;
    }

    setIsProcessing(true);
    setValidationResult(null);

    setTimeout(() => {
      setIsProcessing(false);

      // 1. Check in purchased licenses
      const purchasedLicenses = storage.getPurchasedLicenses();
      const matchLicense = purchasedLicenses.find(
        (l) => l.keyCode.trim().toLowerCase() === cleanKey.toLowerCase()
      );

      if (matchLicense) {
        setValidationResult({
          found: true,
          toolName: matchLicense.toolName,
          planName: matchLicense.planName,
          version: matchLicense.version,
          status: matchLicense.status,
          expiresAt: matchLicense.expiresAt,
          hwid: matchLicense.hwid || 'Chưa gán máy tính',
          hwidResetsRemaining: matchLicense.hwidResetsRemaining,
          purchasedAt: matchLicense.purchasedAt,
          downloadUrl: matchLicense.downloadUrl,
          message: 'Key hợp lệ! Đã được kích hoạt trên hệ thống bản quyền chính hãng.',
        });
        return;
      }

      // 2. Check in available vault keys
      const vault = storage.getKeyVault();
      const matchVault = vault.find(
        (k) => k.keyCode.trim().toLowerCase() === cleanKey.toLowerCase()
      );

      if (matchVault) {
        const tool = storage.getToolById(matchVault.toolId);
        const plan = tool?.plans.find((p) => p.id === matchVault.planId);
        setValidationResult({
          found: true,
          toolName: tool?.name || 'Tool Bản Quyền',
          planName: plan?.name || 'Gói Tiêu Chuẩn',
          version: tool?.version || '1.0.0',
          status: 'available',
          expiresAt:
            plan?.durationDays && plan.durationDays > 90000
              ? 'Lifetime'
              : `${plan?.durationDays || 30} ngày sau khi kích hoạt`,
          hwid: 'Chưa kích hoạt',
          hwidResetsRemaining: 3,
          downloadUrl: tool?.downloadUrl,
          message: 'Key chính hãng hoàn toàn mới 100%! Chưa từng được kích hoạt hoặc gán thiết bị.',
        });
        return;
      }

      // 3. Not found
      setValidationResult({
        found: false,
        message: 'Mã Key không tồn tại trên hệ thống máy chủ bản quyền hoặc đã bị hủy bỏ!',
      });
    }, 500);
  };

  const handleCopyKey = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
    showToast('Đã sao chép vào bộ nhớ đệm', undefined, 'success');
  };

  const handleGoToDashboard = () => {
    onClose();
    setActiveView('user_dashboard');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0a0a0a] border border-blue-500/30 rounded-2xl shadow-[0_0_50px_rgba(37,99,235,0.25)] overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#050505]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              {activeTab === 'activate' ? <Zap className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">
                {activeTab === 'activate' ? 'Kích Hoạt Key Bản Quyền' : 'Tra Cứu & Xác Thực Key'}
              </h3>
              <p className="text-xs text-slate-400">
                {activeTab === 'activate'
                  ? 'Gán bản quyền vào máy tính & tài khoản của bạn'
                  : 'Xác minh tính xác thực, hạn dùng và mã HWID máy tính'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-white/10 bg-[#0d0d0d] p-1.5 gap-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveTab('activate');
              setActivationResult(null);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              activeTab === 'activate'
                ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>⚡ Kích Hoạt Key Mới</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('validate');
              setValidationResult(null);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              activeTab === 'validate'
                ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>🔍 Tra Cứu Trạng Thái</span>
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* TAB 1: KÍCH HOẠT KEY */}
          {activeTab === 'activate' && (
            <div className="space-y-4">
              <form onSubmit={handleActivateKey} className="space-y-4">
                {/* Key Code Input */}
                <div>
                  <label className="text-xs font-semibold text-slate-300 block uppercase tracking-wider mb-1.5 flex items-center justify-between">
                    <span>Mã Key Bản Quyền (License Key):</span>
                    <span className="text-[11px] text-blue-400 font-normal">Bắt buộc</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="VD: TIKTOK-1_YEAR-A9F2-4KC8-89Z1-XP29..."
                      value={keyCodeInput}
                      onChange={(e) => setKeyCodeInput(e.target.value)}
                      className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl px-4 py-3 text-xs text-blue-300 font-mono tracking-wider placeholder:text-slate-600 transition-all uppercase"
                    />
                    <Key className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
                  </div>
                </div>

                {/* HWID Device Input */}
                <div>
                  <label className="text-xs font-semibold text-slate-300 block uppercase tracking-wider mb-1.5 flex items-center justify-between">
                    <span>Mã Phần Cứng Máy Tính (HWID):</span>
                    <button
                      type="button"
                      onClick={() => setHwidInput(getDeviceHwid())}
                      className="text-[11px] text-emerald-400 hover:text-emerald-300 font-normal flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Lấy HWID máy này</span>
                    </button>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="VD: WIN-PC-89A1-CC42"
                      value={hwidInput}
                      onChange={(e) => setHwidInput(e.target.value)}
                      className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl px-4 py-3 text-xs text-emerald-300 font-mono tracking-wider placeholder:text-slate-600 transition-all uppercase"
                    />
                    <Monitor className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Bản quyền sẽ được khóa và bảo vệ theo mã phần cứng này để chống sao chép trái phép.
                  </p>
                </div>

                {/* Account Link notice */}
                <div className="p-3 rounded-xl bg-[#111111] border border-white/5 flex items-center gap-3 text-xs">
                  <UserCheck className="w-4 h-4 text-blue-400 shrink-0" />
                  <div className="text-slate-300">
                    Kích hoạt cho: <strong className="text-white font-mono">{currentUser?.email || 'Khách (Tự động liên kết)'}</strong>
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-3.5 rounded-xl font-bold text-xs bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-[0_0_25px_rgba(37,99,235,0.4)] transition-all flex items-center justify-center gap-2"
                >
                  {isProcessing ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin" />
                      <span>Đang Kích Hoạt Bản Quyền...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>XÁC NHẬN KÍCH HOẠT BẢN QUYỀN</span>
                    </>
                  )}
                </button>
              </form>

              {/* Activation Result */}
              {activationResult && (
                <div className="animate-in fade-in zoom-in-95 duration-200">
                  {activationResult.success && activationResult.license ? (
                    <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/40 space-y-3">
                      <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold pb-2 border-b border-white/10">
                        <CheckCircle className="w-4 h-4 shrink-0" />
                        <span>{activationResult.message}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2.5 text-xs">
                        <div>
                          <span className="text-slate-500 block text-[11px]">Phần Mềm:</span>
                          <strong className="text-white font-medium">{activationResult.license.toolName}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Gói Thời Hạn:</span>
                          <strong className="text-blue-400 font-medium">{activationResult.license.planName}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Trạng Thái:</span>
                          <span className="inline-block px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[11px] font-bold mt-0.5">
                            Đã Kích Hoạt Hoạt Động
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Hạn Dùng Đến:</span>
                          <strong className="text-amber-300 font-mono">
                            {formatDate(activationResult.license.expiresAt)}
                          </strong>
                        </div>
                        <div className="col-span-2">
                          <span className="text-slate-500 block text-[11px]">Mã Máy Tính (HWID):</span>
                          <div className="mt-0.5 p-2 rounded bg-[#050505] border border-white/10 text-[11px] font-mono text-emerald-300 flex items-center justify-between">
                            <span>{activationResult.license.hwid}</span>
                            <span className="text-slate-500">
                              {activationResult.license.hwidResetsRemaining} lượt đổi máy còn lại
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 flex flex-wrap gap-2">
                        <a
                          href={activationResult.license.downloadUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex-1 py-2 px-3 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Tải Bộ Cài Tool</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => handleCopyKey(activationResult.license?.keyCode || '')}
                          className="py-2 px-3 rounded-lg text-xs font-semibold bg-[#1a1a1a] hover:bg-white/10 text-slate-300 border border-white/10 flex items-center gap-1.5 transition-colors"
                        >
                          {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedKey ? 'Đã Sao Chép' : 'Sao Chép Key'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleGoToDashboard}
                          className="py-2 px-3 rounded-lg text-xs font-semibold bg-[#1a1a1a] hover:bg-white/10 text-blue-400 border border-white/10 flex items-center gap-1.5 transition-colors"
                        >
                          <span>Quản Lý Bản Quyền</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-500/40 flex items-start gap-3">
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="text-xs font-bold text-rose-300">Kích Hoạt Không Thành Công</h5>
                        <p className="text-xs text-slate-300 mt-1">{activationResult.message}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Quick sample keys */}
              <div className="p-3 rounded-xl bg-[#111111] border border-white/10 text-xs text-slate-400">
                <span className="text-[11px] text-slate-500 font-semibold uppercase block mb-1.5">
                  Mã Key Mẫu Thử Nghiệm Kích Hoạt:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setKeyCodeInput('TIKTOK-1_YEAR-A9F2-4KC8-89Z1-XP29')}
                    className="px-2.5 py-1 rounded bg-[#181818] hover:bg-white/10 text-[11px] font-mono text-blue-300 border border-white/10"
                  >
                    TIKTOK-1_YEAR...
                  </button>
                  <button
                    type="button"
                    onClick={() => setKeyCodeInput('SHOPEE-LIFETIME-GOLD-77AF-901B-44CC-8899')}
                    className="px-2.5 py-1 rounded bg-[#181818] hover:bg-white/10 text-[11px] font-mono text-blue-300 border border-white/10"
                  >
                    SHOPEE-LIFETIME...
                  </button>
                  <button
                    type="button"
                    onClick={() => setKeyCodeInput('CAPCUT-1_YEAR-CC90-B882-11AA-9988')}
                    className="px-2.5 py-1 rounded bg-[#181818] hover:bg-white/10 text-[11px] font-mono text-blue-300 border border-white/10"
                  >
                    CAPCUT-1_YEAR...
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TRA CỨU KEY */}
          {activeTab === 'validate' && (
            <div className="space-y-4">
              <form onSubmit={handleValidateKey} className="space-y-3">
                <label className="text-xs font-semibold text-slate-300 block uppercase tracking-wider">
                  Nhập Mã Key Cần Tra Cứu / Kiểm Tra:
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="VD: TIKTOK-1_YEAR-A9F2-4KC8-89Z1-XP29..."
                    value={keyCodeInput}
                    onChange={(e) => setKeyCodeInput(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl px-4 py-3 text-xs text-blue-300 font-mono tracking-wider placeholder:text-slate-600 transition-all pr-24 uppercase"
                  />
                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="absolute right-1.5 top-1.5 bottom-1.5 px-4 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white transition-all flex items-center gap-1.5"
                  >
                    {isProcessing ? (
                      <Sparkles className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Search className="w-3.5 h-3.5" />
                    )}
                    <span>{isProcessing ? 'Đang Tra...' : 'Tra Cứu'}</span>
                  </button>
                </div>
              </form>

              {/* Result Card */}
              {validationResult && (
                <div className="animate-in fade-in zoom-in-95 duration-200">
                  {validationResult.found ? (
                    <div className="p-4 rounded-xl bg-[#111111] border border-blue-500/40 space-y-3">
                      <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold pb-2 border-b border-white/10">
                        <CheckCircle className="w-4 h-4 shrink-0" />
                        <span>{validationResult.message}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2.5 text-xs">
                        <div>
                          <span className="text-slate-500 block text-[11px]">Phần Mềm:</span>
                          <strong className="text-white font-medium">{validationResult.toolName}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Gói Bản Quyền:</span>
                          <strong className="text-blue-400 font-medium">{validationResult.planName}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Trạng Thái:</span>
                          <span className="inline-block px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[11px] font-bold mt-0.5">
                            {validationResult.status === 'available' ? 'Chưa Kích Hoạt (Mới 100%)' : 'Đang Hoạt Động'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Hạn Sử Dụng:</span>
                          <strong className="text-amber-300 font-mono">
                            {formatDate(validationResult.expiresAt || '')}
                          </strong>
                        </div>
                        <div className="col-span-2">
                          <span className="text-slate-500 block text-[11px]">Mã Phần Cứng (HWID Máy Tính):</span>
                          <div className="mt-0.5 p-2 rounded bg-[#050505] border border-white/10 text-[11px] font-mono text-slate-300 flex items-center justify-between">
                            <span>{validationResult.hwid}</span>
                            <span className="text-slate-500">
                              {validationResult.hwidResetsRemaining} lần đổi máy còn lại
                            </span>
                          </div>
                        </div>
                      </div>

                      {validationResult.status === 'available' && (
                        <div className="pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              setActiveTab('activate');
                              setActivationResult(null);
                            }}
                            className="w-full py-2.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center gap-1.5 transition-colors"
                          >
                            <Zap className="w-3.5 h-3.5" />
                            <span>Kích Hoạt Key Này Ngay Bây Giờ</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-500/40 flex items-start gap-3">
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="text-xs font-bold text-rose-300">Không Tìm Thấy Thông Tin Key</h5>
                        <p className="text-xs text-slate-300 mt-1">{validationResult.message}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#050505] flex items-center justify-between">
          <div className="text-[11px] text-slate-500">
            Hỗ trợ kỹ thuật: <a href="https://zalo.me/0826130621" target="_blank" rel="noreferrer" className="text-blue-400 font-mono hover:underline">Zalo 0826130621</a>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold bg-[#141414] hover:bg-white/10 text-slate-300 transition-colors"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
