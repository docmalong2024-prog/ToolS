import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useSystem } from '../../contexts/SystemContext';
import { storage } from '../../services/storage';
import { ToolItem, PricingPlan, PurchasedLicense, WithdrawalRequest } from '../../types';
import { KeyRevealModal } from '../common/KeyRevealModal';
import {
  Crown,
  TrendingUp,
  Wallet,
  Key,
  Users,
  Code2,
  DollarSign,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Copy,
  Download,
  Plus,
  RefreshCw,
  Clock,
  Sparkles,
  Layers
} from 'lucide-react';

export const ResellerDashboard: React.FC = () => {
  const { currentUser, refreshUserData } = useAuth();
  const { formatVND, formatDate, showToast } = useSystem();

  const [activeTab, setActiveTab] = useState<'overview' | 'resell' | 'clients' | 'payout' | 'api'>('overview');

  // Withdrawal form state
  const [withdrawAmount, setWithdrawAmount] = useState<string>('2000000');
  const [bankName, setBankName] = useState<string>('Techcombank');
  const [bankAccount, setBankAccount] = useState<string>('19034567890123');
  const [bankAccountName, setBankAccountName] = useState<string>(currentUser?.name?.toUpperCase() || 'HOANG NAM');
  const [isSubmittingWdr, setIsSubmittingWdr] = useState<boolean>(false);

  // Sub-key resell state
  const [selectedToolId, setSelectedToolId] = useState<string>('tool_tiktok_auto_pro');
  const [selectedPlanId, setSelectedPlanId] = useState<string>('plan_tiktok_1m');
  const [clientName, setClientName] = useState<string>('Khách Hàng Tuyến Đại Lý');
  const [clientEmail, setClientEmail] = useState<string>('client.nam@gmail.com');
  const [clientCustomPrice, setClientCustomPrice] = useState<string>('');
  const [generatedLicenses, setGeneratedLicenses] = useState<PurchasedLicense[]>([]);
  const [showKeyModal, setShowKeyModal] = useState<boolean>(false);
  const [orderIdDelivered, setOrderIdDelivered] = useState<string>('');

  if (!currentUser) return null;

  const tools = storage.getTools();
  const withdrawals = storage.getWithdrawals(currentUser.id);
  const allPurchased = storage.getPurchasedLicenses();
  const resellerClients = allPurchased.filter((l) => l.resellerId === currentUser.id);

  // Reseller tier stats
  const discountPct = currentUser.resellerDiscountPercent || 20;
  const currentTier = currentUser.resellerTier || 'gold';
  const tierColors = {
    silver: 'from-slate-400 to-slate-200 text-slate-950',
    gold: 'from-amber-400 to-yellow-500 text-slate-950',
    diamond: 'from-cyan-400 to-blue-500 text-slate-950',
  };

  const selectedTool = tools.find((t) => t.id === selectedToolId) || tools[0];
  const selectedPlan = selectedTool?.plans.find((p) => p.id === selectedPlanId) || selectedTool?.plans[0];
  const wholesalePrice = selectedPlan ? Math.round(selectedPlan.salePrice * (1 - discountPct / 100)) : 0;
  const availableStock = selectedTool && selectedPlan ? storage.getAvailableKeyCount(selectedTool.id, selectedPlan.id) : 0;

  const handleRequestWithdrawal = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseInt(withdrawAmount.replace(/\D/g, ''), 10) || 0;
    if (amountNum < 200000) {
      showToast('Số tiền rút tối thiểu là 200.000 ₫!', undefined, 'error');
      return;
    }
    if (currentUser.resellerWalletBalance < amountNum) {
      showToast('Số dư ví hoa hồng không đủ để rút!', undefined, 'error');
      return;
    }

    try {
      setIsSubmittingWdr(true);
      storage.requestWithdrawal({
        resellerId: currentUser.id,
        amount: amountNum,
        bankName,
        bankAccount,
        bankAccountName,
      });
      refreshUserData();
      showToast('Gửi yêu cầu rút tiền thành công!', `Admin sẽ chuyển ${formatVND(amountNum)} trong vòng 1-2h.`, 'success');
    } catch (e: any) {
      showToast('Lỗi rút tiền', e.message, 'error');
    } finally {
      setIsSubmittingWdr(false);
    }
  };

  const handleGenerateSubKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTool || !selectedPlan) return;

    if (currentUser.balance < wholesalePrice) {
      showToast('Số dư ví chính không đủ để mua sỉ key!', `Cần: ${formatVND(wholesalePrice)}, Có: ${formatVND(currentUser.balance)}`, 'error');
      return;
    }

    try {
      const res = storage.purchaseItems({
        userId: currentUser.id,
        items: [{ tool: selectedTool, plan: selectedPlan, quantity: 1 }],
        paymentMethod: 'wallet',
        resellerId: currentUser.id,
        customCustomerName: clientName,
      });

      refreshUserData();
      setGeneratedLicenses(res.licenses);
      setOrderIdDelivered(res.orderId);
      setShowKeyModal(true);
      showToast('Xuất Key cho khách thành công!', `Đã trừ ${formatVND(wholesalePrice)} (Giá sỉ -${discountPct}%)`, 'success');
    } catch (e: any) {
      showToast('Lỗi xuất key', e.message, 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Reseller Banner Card */}
      <div className="relative p-6 sm:p-8 rounded-3xl bg-[#0a0a0a] border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-xs font-mono font-extrabold uppercase bg-gradient-to-r ${tierColors[currentTier]} shadow`}>
              ⭐ CẤP ĐỘ {currentTier.toUpperCase()}
            </span>
            <span className="text-xs font-mono text-amber-300 font-bold">
              Chiết khấu độc quyền: -{discountPct}%
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Trung Tâm Quản Trị Đại Lý & Đối Tác
          </h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Tạo sub-key bán lại cho khách hàng của bạn, theo dõi doanh thu hoa hồng tự động và rút tiền về ngân hàng 24/7.
          </p>
        </div>

        {/* Reseller Wallet Cards */}
        <div className="flex flex-wrap gap-3">
          <div className="p-4 rounded-2xl bg-[#111111] border border-amber-500/40 min-w-44 text-left shadow-lg">
            <span className="text-[11px] text-amber-400 uppercase font-semibold block">Ví Hoa Hồng Rút Được</span>
            <div className="text-2xl font-mono font-bold text-amber-300 mt-0.5">
              {formatVND(currentUser.resellerWalletBalance)}
            </div>
            <span className="text-[10px] text-slate-400 mt-1 block">Rút tiền về Bank tức thì</span>
          </div>

          <div className="p-4 rounded-2xl bg-[#111111] border border-white/10 min-w-44 text-left shadow-lg">
            <span className="text-[11px] text-blue-400 uppercase font-semibold block">Ví Mua Sỉ (Ví Chính)</span>
            <div className="text-2xl font-mono font-bold text-emerald-400 mt-0.5">
              {formatVND(currentUser.balance)}
            </div>
            <span className="text-[10px] text-slate-400 mt-1 block">Dùng để tạo sub-key giá sỉ</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-[#0a0a0a] p-1 rounded-xl gap-1">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'overview'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Tổng Quan & Doanh Số</span>
        </button>

        <button
          onClick={() => setActiveTab('resell')}
          className={`flex-1 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'resell'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Tạo & Bán Sub-Key (-{discountPct}%)</span>
        </button>

        <button
          onClick={() => setActiveTab('clients')}
          className={`flex-1 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'clients'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Khách Hàng Nhánh ({resellerClients.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('payout')}
          className={`flex-1 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'payout'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Rút Tiền Hoa Hồng ({withdrawals.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('api')}
          className={`flex-1 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'api'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Code2 className="w-4 h-4" />
          <span>Tài Liệu API Bot</span>
        </button>
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Stat metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Tổng Hoa Hồng Đã Nhận</span>
              <div className="text-2xl font-mono font-bold text-amber-400">11,250,000 ₫</div>
              <span className="text-[11px] text-emerald-400 font-mono">Tự động cộng sau mỗi đơn</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Sub-Key Đã Bán Lại</span>
              <div className="text-2xl font-mono font-bold text-blue-400">38 Key</div>
              <span className="text-[11px] text-slate-400">Cho 24 khách hàng tuyến</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Tiền Đã Rút Về Bank</span>
              <div className="text-2xl font-mono font-bold text-emerald-400">3,000,000 ₫</div>
              <span className="text-[11px] text-slate-400">1 lệnh đã hoàn tất</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Hạn Mức Chiết Khấu</span>
              <div className="text-2xl font-mono font-bold text-purple-400">-{discountPct}% Sỉ</div>
              <span className="text-[11px] text-slate-400">Đạt 50 key/tháng lên Kim Cương (-35%)</span>
            </div>
          </div>

          {/* Tier Policy Progression Table */}
          <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase text-blue-400">
              Bảng Cấp Bậc & Chính Sách Chiết Khấu Đại Lý:
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-[#111111] border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300 text-sm">🥈 Đại Lý Bạc (Silver)</span>
                  <span className="px-2 py-0.5 rounded bg-[#181818] text-slate-300 font-mono text-xs font-bold">-10%</span>
                </div>
                <p className="text-xs text-slate-400">Dành cho đối tác mới bắt đầu, không yêu cầu cọc hoặc cam kết doanh số.</p>
              </div>

              <div className="p-4 rounded-xl bg-[#111111] border border-amber-500/40 shadow space-y-2 relative">
                <span className="absolute -top-2 right-3 px-2 py-0.5 rounded-full text-[9px] bg-amber-500 text-slate-950 font-bold font-mono">
                  CẤP HIỆN TẠI
                </span>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 text-sm">🥇 Đại Lý Vàng (Gold)</span>
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-xs font-bold">-20%</span>
                </div>
                <p className="text-xs text-slate-400">Doanh số từ 10.000.000 ₫/tháng hoặc nạp tích lũy trên 5 triệu đồng.</p>
              </div>

              <div className="p-4 rounded-xl bg-[#111111] border border-blue-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-300 text-sm">💎 Đại Lý Kim Cương (Diamond)</span>
                  <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono text-xs font-bold">-35%</span>
                </div>
                <p className="text-xs text-slate-400">Cấp cao nhất, hỗ trợ cấp API Webhook tích hợp website riêng và Telegram Bot.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Resell Sub-Keys */}
      {activeTab === 'resell' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Create Sub-key form */}
          <div className="md:col-span-7 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white tracking-wide">
              Tạo & Cấp Sub-Key Cho Khách Hàng Tuyến
            </h3>
            <p className="text-xs text-slate-400">
              Bạn mua với giá sỉ đã chiết khấu <strong>-{discountPct}%</strong> và có thể bán lại cho khách với mức giá tùy ý.
            </p>

            <form onSubmit={handleGenerateSubKey} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1.5">1. Chọn Phần Mềm Cần Bán:</label>
                <select
                  value={selectedToolId}
                  onChange={(e) => {
                    setSelectedToolId(e.target.value);
                    const t = tools.find((tool) => tool.id === e.target.value);
                    if (t && t.plans.length > 0) setSelectedPlanId(t.plans[0].id);
                  }}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2.5 text-white font-medium focus:border-blue-500"
                >
                  {tools.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} (v{t.version})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1.5">2. Chọn Gói Thời Hạn:</label>
                <div className="grid grid-cols-2 gap-2">
                  {selectedTool?.plans.map((p) => {
                    const isSel = selectedPlanId === p.id;
                    const wsPrice = Math.round(p.salePrice * (1 - discountPct / 100));
                    return (
                      <button
                        type="button"
                        key={p.id}
                        onClick={() => setSelectedPlanId(p.id)}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSel
                            ? 'border-blue-500 bg-blue-500/10 text-white'
                            : 'border-white/10 bg-[#111111] text-slate-400 hover:border-white/20'
                        }`}
                      >
                        <div className="font-bold text-xs">{p.name}</div>
                        <div className="font-mono text-amber-300 font-bold mt-1">
                          Giá sỉ: {formatVND(wsPrice)}
                        </div>
                        <div className="text-[10px] text-slate-500 line-through">
                          Giá gốc: {formatVND(p.salePrice)}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Tên khách hàng:</label>
                  <input
                    type="text"
                    required
                    placeholder="Nguyễn Văn B..."
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Email / SĐT khách:</label>
                  <input
                    type="text"
                    required
                    placeholder="client@gmail.com..."
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#050505] border border-white/10 flex items-center justify-between font-mono">
                <div>
                  <span className="text-slate-400 text-[11px] block">Số tiền thanh toán trừ vào ví:</span>
                  <span className="text-lg font-bold text-emerald-400">{formatVND(wholesalePrice)}</span>
                </div>
                <div className="text-right text-[11px]">
                  <span className="text-slate-400 block">Kho key sẵn có:</span>
                  <span className={availableStock > 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {availableStock > 0 ? `${availableStock} Key` : 'Hết key'}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                disabled={availableStock === 0}
                className="w-full py-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all flex items-center justify-center gap-2"
              >
                <Key className="w-4 h-4" />
                <span>Mua Giá Sỉ & Xuất Key Ngay</span>
              </button>
            </form>
          </div>

          {/* Quick instructions */}
          <div className="md:col-span-5 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4 text-xs">
            <h4 className="font-bold text-white uppercase text-blue-400">
              Quyền Lợi Dành Riêng Cho Đại Lý:
            </h4>
            <ul className="space-y-2.5 text-slate-300">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Key cấp cho khách hoàn toàn chính hãng, có bảo hành đầy đủ 3 lần đổi máy HWID.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Khách hàng của bạn có thể tra cứu key trực tiếp trên web bằng công cụ tra cứu.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Được quyền tự tạo link bán hoặc tích hợp Telegram Bot tự động.</span>
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab 3: Reseller Clients */}
      {activeTab === 'clients' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white tracking-wide">
              Danh Sách Khách Hàng Tuyến Đại Lý
            </h3>
            <span className="text-xs text-slate-400">Theo dõi key đã xuất cho khách</span>
          </div>

          <div className="rounded-2xl bg-[#0a0a0a] border border-white/10 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#050505] border-b border-white/10 text-slate-400 uppercase tracking-wider font-mono">
                  <tr>
                    <th className="p-3.5">Mã Đơn</th>
                    <th className="p-3.5">Phần Mềm</th>
                    <th className="p-3.5">Gói Bản Quyền</th>
                    <th className="p-3.5">Mã Key</th>
                    <th className="p-3.5">Giá Sỉ</th>
                    <th className="p-3.5">Hạn Dùng</th>
                    <th className="p-3.5">Trạng Thái</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono">
                  {resellerClients.map((lic) => (
                    <tr key={lic.id} className="hover:bg-white/5 transition-colors">
                      <td className="p-3.5 text-blue-400 font-bold">{lic.orderId}</td>
                      <td className="p-3.5 font-sans font-medium text-white">{lic.toolName}</td>
                      <td className="p-3.5 text-amber-300">{lic.planName}</td>
                      <td className="p-3.5 text-slate-300 font-bold select-all">{lic.keyCode}</td>
                      <td className="p-3.5 text-emerald-400">{formatVND(lic.pricePaid)}</td>
                      <td className="p-3.5 text-slate-400">{formatDate(lic.expiresAt)}</td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                          Hoạt động
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Payout & Withdrawals */}
      {activeTab === 'payout' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Withdrawal Request Form */}
          <div className="md:col-span-6 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white tracking-wide">
              Yêu Cầu Rút Tiền Về Tài Khoản Ngân Hàng
            </h3>
            <p className="text-xs text-slate-400">
              Số dư hoa hồng khả dụng để rút:{' '}
              <strong className="text-amber-400 font-mono text-sm">
                {formatVND(currentUser.resellerWalletBalance)}
              </strong>
            </p>

            <form onSubmit={handleRequestWithdrawal} className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Số tiền cần rút (Tối thiểu 200.000 ₫):</label>
                <input
                  type="number"
                  required
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-sm font-mono text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Tên Ngân Hàng:</label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2.5 text-white font-medium"
                >
                  <option value="Techcombank">Techcombank (TCB)</option>
                  <option value="MBBank">MBBank - Ngân Hàng Quân Đội</option>
                  <option value="Vietcombank">Vietcombank (VCB)</option>
                  <option value="Vietinbank">Vietinbank (CTG)</option>
                  <option value="ACB">ACB - Á Châu</option>
                  <option value="VPBank">VPBank</option>
                  <option value="TPBank">TPBank - Tiên Phong</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Số Tài Khoản:</label>
                <input
                  type="text"
                  required
                  placeholder="1903456789..."
                  value={bankAccount}
                  onChange={(e) => setBankAccount(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Tên Chủ Tài Khoản (Không dấu):</label>
                <input
                  type="text"
                  required
                  placeholder="NGUYEN VAN A..."
                  value={bankAccountName}
                  onChange={(e) => setBankAccountName(e.target.value.toUpperCase())}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2.5 text-white font-mono uppercase"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingWdr || currentUser.resellerWalletBalance < 200000}
                className="w-full py-3 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all flex items-center justify-center gap-2"
              >
                <DollarSign className="w-4 h-4" />
                <span>Gửi Yêu Cầu Rút Tiền</span>
              </button>
            </form>
          </div>

          {/* Withdrawal History Table */}
          <div className="md:col-span-6 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white tracking-wide">
              Lịch Sử Yêu Cầu Rút Tiền
            </h3>

            <div className="space-y-3">
              {withdrawals.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-8">Chưa có yêu cầu rút tiền nào</p>
              ) : (
                withdrawals.map((w) => (
                  <div
                    key={w.id}
                    className="p-4 rounded-xl bg-[#111111] border border-white/10 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-base text-amber-300">
                        {formatVND(w.amount)}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        w.status === 'approved'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : w.status === 'pending'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {w.status === 'approved' && '✓ Đã Chuyển Tiền'}
                        {w.status === 'pending' && '⌛ Đang Chờ Duyệt'}
                        {w.status === 'rejected' && '✕ Bị Từ Chối'}
                      </span>
                    </div>

                    <div className="text-slate-400 flex items-center justify-between text-[11px] font-mono">
                      <span>{w.bankName} - {w.bankAccount} ({w.bankAccountName})</span>
                      <span>{formatDate(w.createdAt)}</span>
                    </div>

                    {w.adminNote && (
                      <div className="p-2 rounded bg-[#050505] text-[11px] text-blue-300 border border-white/10">
                        Ghi chú Admin: {w.adminNote}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Reseller REST API */}
      {activeTab === 'api' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
              <Code2 className="w-5 h-5 text-blue-400" />
              <span>Tài Liệu API & Webhook Bán Tool Tự Động (Reseller API v1)</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Tích hợp hệ thống phân phối Key tự động vào Website riêng của bạn hoặc Telegram Bot bán hàng tự động 24/7.
            </p>

            {/* API Key Box */}
            <div className="p-4 rounded-xl bg-[#111111] border border-blue-500/30 space-y-2">
              <span className="text-xs text-slate-400 font-semibold uppercase">API Secret Key Của Bạn:</span>
              <div className="flex items-center justify-between p-3 rounded-lg bg-[#050505] border border-white/10 font-mono text-xs text-blue-300">
                <span>ts_live_key_98a72b89f81a74e8912cb890</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('ts_live_key_98a72b89f81a74e8912cb890');
                    showToast('Đã sao chép API Key!', undefined, 'success');
                  }}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Code example */}
            <div className="space-y-2 text-xs">
              <span className="font-bold text-white uppercase text-blue-400">
                Ví Dụ Gọi API Mua Key Bản Quyền (cURL):
              </span>
              <pre className="p-4 rounded-xl bg-[#050505] border border-white/10 text-blue-300 font-mono text-xs overflow-x-auto">
{`curl -X POST https://api.toolstore.pro/v1/reseller/order \\
  -H "Authorization: Bearer ts_live_key_98a72b89f81a74e8912cb890" \\
  -H "Content-Type: application/json" \\
  -d '{
    "tool_id": "tool_tiktok_auto_pro",
    "plan_id": "plan_tiktok_1m",
    "customer_name": "Nguyen Van B",
    "customer_email": "client@gmail.com"
  }'`}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Key Reveal Modal */}
      {showKeyModal && (
        <KeyRevealModal
          isOpen={showKeyModal}
          onClose={() => setShowKeyModal(false)}
          licenses={generatedLicenses}
          orderId={orderIdDelivered}
        />
      )}
    </div>
  );
};
