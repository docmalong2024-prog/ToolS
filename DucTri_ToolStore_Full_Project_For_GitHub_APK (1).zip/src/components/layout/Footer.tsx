import React from 'react';
import { useSystem } from '../../contexts/SystemContext';
import {
  Cpu,
  ShieldCheck,
  Zap,
  RefreshCw,
  Award,
  PhoneCall,
  Send,
  MessageSquare,
  Mail,
  ExternalLink,
  Lock
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { settings, setActiveView, openKeyValidator } = useSystem();

  return (
    <footer className="bg-[#050505] border-t border-white/10 text-slate-400 text-xs">
      {/* 4 Tech Trust Pillars */}
      <div className="border-b border-white/10 bg-[#0a0a0a] py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-[#111111] border border-white/10 hover:border-blue-500/40 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Xuất Key Tự Động 24/7</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                Hệ thống API kết nối VietQR & MoMo tự động cấp key và link tải trong 3 giây.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-[#111111] border border-white/10 hover:border-emerald-500/40 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Bảo Hành 100% Trọn Gói</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                Cam kết hỗ trợ kỹ thuật, đổi mới key 1-1 nếu có sự cố và hỗ trợ reset HWID máy tính.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-[#111111] border border-white/10 hover:border-indigo-500/40 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Update Fix Lỗi Liên Tục</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                Luôn cập nhật thuật toán Anti-detect, lách mã hash và chống Checkpoint mới nhất.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-[#111111] border border-white/10 hover:border-amber-500/40 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Chiết Khấu Đại Lý Tới 35%</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                Cung cấp hệ thống tạo sub-key, API bán lại tự động và rút tiền hoa hồng linh hoạt.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Info */}
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Col */}
        <div className="space-y-4 md:col-span-1">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <Cpu className="w-5 h-5" />
            </div>
            <span className="font-bold text-base text-white tracking-wider font-mono">
              {settings.appName}
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            {settings.slogan}. Đơn vị tiên phong cung cấp giải pháp tự động hóa phần mềm, bot và công cụ MMO số 1.
          </p>
          <div className="pt-2 flex items-center gap-3 text-xs text-blue-400">
            <span className="flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>Bảo mật 256-bit</span>
            </span>
            <span>•</span>
            <span className="text-slate-400">Uptime 99.98%</span>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3 font-mono text-blue-400">
            Danh Mục Phần Mềm
          </h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => setActiveView('catalog')} className="hover:text-blue-300 transition-colors">
                TikTok Automation & Livestream Bot
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('catalog')} className="hover:text-blue-300 transition-colors">
                Facebook Nuôi Nick & Quét UID
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('catalog')} className="hover:text-blue-300 transition-colors">
                Shopee / Lazada Auto Săn Sale 0.01s
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('catalog')} className="hover:text-blue-300 transition-colors">
                AI Video & Lồng Tiếng CapCut Tự Động
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('catalog')} className="hover:text-blue-300 transition-colors">
                Crypto DEX Sniper Bot & Arbitrage
              </button>
            </li>
          </ul>
        </div>

        {/* Reseller & Support */}
        <div>
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3 font-mono text-blue-400">
            Dịch Vụ & Bản Quyền
          </h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => openKeyValidator('activate')} className="text-emerald-400 hover:underline font-semibold flex items-center gap-1">
                <Zap className="w-3 h-3" />
                <span>Kích hoạt Key bản quyền</span>
              </button>
            </li>
            <li>
              <button onClick={() => openKeyValidator('validate')} className="hover:text-blue-300 transition-colors">
                Tra cứu tình trạng & HWID Key
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('reseller_dashboard')} className="text-amber-400 hover:underline">
                ⭐ Đăng ký làm Đại lý phân phối
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('user_dashboard')} className="hover:text-blue-300 transition-colors">
                Kho Key & Reset HWID máy tính
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('catalog')} className="hover:text-blue-300 transition-colors">
                Chính sách bảo hành & Hoàn tiền
              </button>
            </li>
          </ul>
        </div>

        {/* Contact info & Hotline */}
        <div className="space-y-3">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3 font-mono text-blue-400">
            Hỗ Trợ Kỹ Thuật • App By DucTri
          </h4>
          <div className="space-y-2 text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <MessageSquare className="w-4 h-4 text-blue-400 shrink-0" />
              <span>Zalo hỗ trợ: <a href="https://zalo.me/0826130621" target="_blank" rel="noreferrer" className="text-white hover:text-blue-400 font-mono font-bold underline">0826130621</a> (DucTri)</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Hotline/Zalo: <a href="tel:0826130621" className="text-white font-mono font-bold hover:underline">0826130621</a></span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Send className="w-4 h-4 text-blue-400 shrink-0" />
              <span>Telegram: <strong className="text-blue-300 font-mono">@DucTri_Support</strong></span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Mail className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Email: <strong className="text-slate-300 font-mono">doductri6a6@gmail.com</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment methods & Copyright */}
      <div className="border-t border-white/5 bg-[#050505] py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-slate-400 text-xs">
            © {new Date().getFullYear()} <strong className="text-slate-200">{settings.appName}</strong> • <span className="text-blue-400 font-semibold font-mono">App By DucTri (Zalo: 0826130621)</span>. All rights reserved.
          </div>

          <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
            <span>Hỗ trợ thanh toán:</span>
            <span className="px-2 py-0.5 rounded bg-[#111111] border border-white/10 text-blue-400 font-mono font-bold">
              VietQR
            </span>
            <span className="px-2 py-0.5 rounded bg-[#111111] border border-white/10 text-emerald-400 font-mono font-bold">
              Napas 247
            </span>
            <span className="px-2 py-0.5 rounded bg-[#111111] border border-white/10 text-pink-400 font-mono font-bold">
              MoMo
            </span>
            <span className="px-2 py-0.5 rounded bg-[#111111] border border-white/10 text-blue-400 font-mono font-bold">
              MBBank
            </span>
            <span className="px-2 py-0.5 rounded bg-[#111111] border border-white/10 text-amber-400 font-mono font-bold">
              USDT
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
