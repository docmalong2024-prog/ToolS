import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import { useSystem } from '../../contexts/SystemContext';
import {
  Cpu,
  ShoppingBag,
  Wallet,
  Bell,
  Search,
  Shield,
  Key,
  Crown,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Layers,
  Sparkles,
  PlusCircle,
  Menu,
  X,
  Zap,
  Calculator,
  Command,
  Activity,
  Download
} from 'lucide-react';

interface NavbarProps {
  onSearchChange?: (query: string) => void;
  searchQuery?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onSearchChange, searchQuery = '' }) => {
  const { currentUser, isAdmin, isReseller, switchDemoUser, logout, notifications, unreadNotifsCount, markNotificationsAsRead } = useAuth();
  const { totalItemsCount, setIsCartOpen } = useCart();
  const {
    settings,
    formatVND,
    activeView,
    setActiveView,
    setIsKeyValidatorOpen,
    openKeyValidator,
    setIsTopupModalOpen,
    setIsAuthModalOpen,
    setIsRoiModalOpen,
    setIsCommandPaletteOpen,
    setIsAppDownloadModalOpen,
  } = useSystem();

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#0a0a0a]/95 backdrop-blur-xl border-b border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.8)]">
      {/* Top Demo Bar for easy evaluator testing & Author credits */}
      <div className="bg-[#050505] border-b border-white/5 px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3 text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-[11px] text-blue-400 font-bold">
                App By DucTri
              </span>
            </div>
            <span className="text-slate-600 hidden sm:inline">|</span>
            <a
              href="https://zalo.me/0826130621"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-blue-400 transition-colors font-mono"
            >
              <span className="text-slate-500">Zalo:</span>
              <strong className="text-white hover:underline">0826130621</strong>
            </a>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
            <span className="text-[11px] text-slate-400 hidden sm:inline">Chuyển vai trò:</span>
            <button
              onClick={() => switchDemoUser('user')}
              className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold transition-all ${
                currentUser?.role === 'user'
                  ? 'bg-blue-600 text-white font-bold shadow-[0_0_12px_rgba(37,99,235,0.4)]'
                  : 'bg-[#141414] text-slate-300 hover:bg-white/10'
              }`}
            >
              Khách Hàng (VIP)
            </button>
            <button
              onClick={() => switchDemoUser('reseller')}
              className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold transition-all ${
                currentUser?.role === 'reseller'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                  : 'bg-[#141414] text-slate-300 hover:bg-white/10'
              }`}
            >
              Đại Lý (Gold -20%)
            </button>
            <button
              onClick={() => switchDemoUser('admin')}
              className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold transition-all ${
                currentUser?.role === 'admin'
                  ? 'bg-purple-600 text-white font-bold shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                  : 'bg-[#141414] text-slate-300 hover:bg-white/10'
              }`}
            >
              Super Admin
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => setActiveView('home')}>
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 via-indigo-600 to-blue-700 p-0.5 shadow-[0_0_20px_rgba(37,99,235,0.3)]">
              <div className="w-full h-full bg-[#0a0a0a] rounded-[10px] flex items-center justify-center">
                <Cpu className="w-6 h-6 text-blue-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-slate-100 tracking-wider font-mono">
                  {settings.appName}
                </span>
                <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-blue-500/15 text-blue-300 rounded border border-blue-500/30">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono tracking-tight -mt-0.5 hidden sm:block">
                License & Tool Marketplace
              </p>
            </div>
          </div>

          {/* Nav Links Desktop */}
          <nav className="hidden lg:flex items-center gap-1 bg-[#111111] p-1 rounded-xl border border-white/10">
            <button
              onClick={() => setActiveView('home')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeView === 'home'
                  ? 'bg-blue-600 text-white shadow-[0_0_12px_rgba(37,99,235,0.3)]'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              Trang Chủ
            </button>
            <button
              onClick={() => setActiveView('catalog')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeView === 'catalog'
                  ? 'bg-blue-600 text-white shadow-[0_0_12px_rgba(37,99,235,0.3)]'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              Kho Tool Bản Quyền
            </button>
            <button
              onClick={() => setActiveView('user_dashboard')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeView === 'user_dashboard'
                  ? 'bg-blue-600 text-white shadow-[0_0_12px_rgba(37,99,235,0.3)]'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Key className="w-3.5 h-3.5 text-blue-400" />
              <span>Kho Key Của Tôi</span>
            </button>
            <button
              onClick={() => setActiveView('reseller_dashboard')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeView === 'reseller_dashboard'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-slate-300 hover:text-amber-400 hover:bg-white/5'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>Phân Hệ Đại Lý</span>
            </button>
            <button
              onClick={() => setIsRoiModalOpen(true)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-300 hover:text-white hover:bg-emerald-950/40 border border-transparent hover:border-emerald-500/30 transition-all flex items-center gap-1.5"
              title="Tính toán thời gian & chi phí tiết kiệm khi dùng tool"
            >
              <Calculator className="w-3.5 h-3.5 text-emerald-400" />
              <span>Tính ROI</span>
            </button>
            {isAdmin && (
              <button
                onClick={() => setActiveView('admin_dashboard')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeView === 'admin_dashboard'
                    ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.3)]'
                    : 'text-purple-300 hover:text-white hover:bg-purple-950/40'
                }`}
              >
                <Shield className="w-3.5 h-3.5 text-purple-400" />
                <span>Admin Quản Trị</span>
              </button>
            )}
          </nav>

          {/* Quick Search with Command Palette trigger */}
          <div
            onClick={() => setIsCommandPaletteOpen(true)}
            className="hidden md:flex items-center relative w-52 lg:w-60 bg-[#111111] hover:bg-[#161616] border border-white/10 hover:border-blue-500/40 rounded-xl px-3 py-1.5 cursor-pointer transition-all group"
          >
            <Search className="w-4 h-4 text-slate-500 group-hover:text-blue-400 mr-2" />
            <span className="text-xs text-slate-400 truncate flex-1">Tìm kiếm nhanh...</span>
            <kbd className="hidden lg:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-[#1f1f1f] border border-white/10 rounded">
              Ctrl K
            </kbd>
          </div>

          {/* Right Action Icons & User Balance */}
          <div className="flex items-center gap-2.5">
            {/* Exclusive Beta App Download Button */}
            <button
              onClick={() => setIsAppDownloadModalOpen(true)}
              title="Tải File Ứng Dụng Client (Chỉ có trên bản thử nghiệm này)"
              className="relative group hidden lg:flex items-center gap-1.5 text-xs text-cyan-300 hover:text-white bg-cyan-950/40 border border-cyan-500/40 hover:bg-cyan-500 hover:text-slate-950 px-3 py-1.5 rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.25)]"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400 group-hover:text-slate-950 animate-bounce" style={{ animationDuration: '3s' }} />
              <span className="font-bold">Tải App Client</span>
              <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-cyan-400/20 text-cyan-200 border border-cyan-400/40 group-hover:bg-slate-950 group-hover:text-cyan-300">
                Beta
              </span>
            </button>

            {/* Activate Key Button */}
            <button
              onClick={() => openKeyValidator('activate')}
              title="Kích hoạt Key bản quyền vào máy tính"
              className="hidden sm:flex items-center gap-1.5 text-xs text-emerald-300 hover:text-white bg-emerald-950/40 border border-emerald-500/40 hover:bg-emerald-600 px-3 py-1.5 rounded-xl transition-all shadow-[0_0_12px_rgba(16,185,129,0.2)]"
            >
              <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
              <span className="font-semibold">Kích Hoạt Key</span>
            </button>

            {/* Key Validator Button */}
            <button
              onClick={() => openKeyValidator('validate')}
              title="Tra cứu & Kiểm tra Key"
              className="hidden xl:flex items-center gap-1 text-xs text-slate-300 hover:text-white bg-[#111111] border border-white/10 hover:border-blue-500/40 px-3 py-1.5 rounded-xl transition-all"
            >
              <Shield className="w-3.5 h-3.5 text-blue-400" />
              <span>Tra Cứu Key</span>
            </button>

            {/* Wallet Balance & Deposit Button */}
            <div className="flex items-center bg-[#111111] border border-white/10 hover:border-emerald-500/30 rounded-xl p-1 shadow-inner transition-colors">
              <button
                onClick={() => setActiveView('user_dashboard')}
                title="Xem ví và tài khoản của bạn"
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs hover:text-emerald-300 transition-colors"
              >
                <Wallet className="w-4 h-4 text-emerald-400" />
                <span className="font-mono font-bold text-white text-xs">
                  {currentUser ? formatVND(currentUser.balance) : '0 ₫'}
                </span>
              </button>
              <button
                onClick={() => setIsTopupModalOpen(true)}
                title="Nạp tiền vào ví tự động"
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow-[0_0_12px_rgba(16,185,129,0.3)] transition-all"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Nạp Tiền</span>
              </button>
            </div>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 rounded-xl bg-[#111111] border border-white/10 hover:border-blue-500/40 text-slate-300 hover:text-white transition-colors"
            >
              <ShoppingBag className="w-5 h-5 text-blue-400" />
              {totalItemsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-blue-600 text-white font-mono text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#0a0a0a] shadow-[0_0_10px_rgba(37,99,235,0.6)] animate-bounce">
                  {totalItemsCount}
                </span>
              )}
            </button>

            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => {
                  setIsNotifOpen(!isNotifOpen);
                  if (!isNotifOpen && unreadNotifsCount > 0) {
                    markNotificationsAsRead();
                  }
                }}
                className="relative p-2 rounded-xl bg-[#111111] border border-white/10 hover:border-blue-500/40 text-slate-300 hover:text-white transition-colors"
              >
                <Bell className="w-5 h-5 text-slate-300" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-blue-600 text-white font-bold font-mono text-[10px] w-4 h-4 rounded-full flex items-center justify-center border border-[#0a0a0a]">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              {/* Notification Popover */}
              {isNotifOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.8)] overflow-hidden z-50 animate-in fade-in zoom-in-95">
                  <div className="p-3.5 border-b border-white/10 flex items-center justify-between bg-[#111111]">
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Thông Báo Hệ Thống</span>
                    <button
                      onClick={markNotificationsAsRead}
                      className="text-[10px] text-blue-400 hover:underline"
                    >
                      Đánh dấu đã đọc
                    </button>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-white/5 p-1">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-xs text-slate-500">Chưa có thông báo nào</div>
                    ) : (
                      notifications.map((n) => (
                        <div key={n.id} className={`p-3 rounded-lg text-xs space-y-1 ${n.isRead ? 'opacity-70' : 'bg-blue-500/10'}`}>
                          <div className="font-semibold text-white">{n.title}</div>
                          <p className="text-slate-400 text-[11px] leading-relaxed">{n.message}</p>
                          <span className="text-[10px] font-mono text-slate-500 block">
                            {new Date(n.createdAt).toLocaleTimeString('vi-VN')}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Profile / Auth Button */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-xl bg-[#111111] border border-white/10 hover:border-blue-500/40 transition-colors"
                >
                  <img
                    src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'}
                    alt={currentUser.name}
                    className="w-7 h-7 rounded-lg object-cover border border-white/10"
                  />
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
                </button>

                {/* Dropdown Menu */}
                {isUserMenuOpen && (
                  <div
                    onClick={() => setIsUserMenuOpen(false)}
                    className="absolute right-0 mt-2 w-64 bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.8)] overflow-hidden z-50 p-2 text-xs animate-in fade-in"
                  >
                    <div className="p-3 border-b border-white/10 mb-1">
                      <div className="font-bold text-white text-sm">{currentUser.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono truncate">{currentUser.email}</div>
                      <div className="mt-2 flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                          currentUser.role === 'admin'
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                            : currentUser.role === 'reseller'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                        }`}>
                          {currentUser.role === 'admin' && '👑 Super Admin'}
                          {currentUser.role === 'reseller' && '⭐ Đại Lý Gold'}
                          {currentUser.role === 'user' && '🛡️ Khách Hàng VIP'}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveView('user_dashboard')}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 text-slate-300 hover:text-white flex items-center gap-2"
                    >
                      <Key className="w-4 h-4 text-blue-400" />
                      <span>Kho Key & Lịch Sử Mua</span>
                    </button>

                    <button
                      onClick={() => setIsTopupModalOpen(true)}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 text-slate-300 hover:text-white flex items-center gap-2"
                    >
                      <Wallet className="w-4 h-4 text-emerald-400" />
                      <span>Nạp Tiền Vào Ví</span>
                    </button>

                    {currentUser.role === 'reseller' && (
                      <button
                        onClick={() => setActiveView('reseller_dashboard')}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-amber-500/10 text-amber-300 flex items-center gap-2"
                      >
                        <Crown className="w-4 h-4 text-amber-400" />
                        <span>Bảng Điều Khiển Đại Lý</span>
                      </button>
                    )}

                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => setActiveView('admin_dashboard')}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-purple-500/10 text-purple-300 flex items-center gap-2"
                      >
                        <Shield className="w-4 h-4 text-purple-400" />
                        <span>Trang Quản Trị Hệ Thống</span>
                      </button>
                    )}

                    <div className="my-1 border-t border-white/10" />

                    <button
                      onClick={() => setIsAuthModalOpen(true)}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 text-blue-400 flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Đổi Tài Khoản / Phân Quyền</span>
                    </button>

                    <button
                      onClick={logout}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-rose-500/10 text-rose-400 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Đăng Xuất</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] transition-all"
              >
                Đăng Nhập
              </button>
            )}

            {/* Mobile menu hamburger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-[#111111] border border-white/10 text-slate-300"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-white/10 space-y-2 animate-in slide-in-from-top-2">
            <div className="relative mb-3">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Tìm kiếm tool..."
                value={searchQuery}
                onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
                className="w-full bg-[#111111] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white"
              />
            </div>

            <button
              onClick={() => {
                setActiveView('home');
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-300 hover:bg-[#111111] hover:text-white"
            >
              Trang Chủ
            </button>
            <button
              onClick={() => {
                setActiveView('catalog');
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-300 hover:bg-[#111111] hover:text-white"
            >
              Kho Tool Bản Quyền
            </button>
            <button
              onClick={() => {
                setActiveView('user_dashboard');
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-300 hover:bg-[#111111] hover:text-white"
            >
              Kho Key Của Tôi
            </button>
            <button
              onClick={() => {
                setActiveView('reseller_dashboard');
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-amber-400 hover:bg-[#111111]"
            >
              Phân Hệ Đại Lý (Chiết khấu 35%)
            </button>
            {isAdmin && (
              <button
                onClick={() => {
                  setActiveView('admin_dashboard');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-purple-400 hover:bg-[#111111]"
              >
                Admin Quản Trị Hệ Thống
              </button>
            )}
            <button
              onClick={() => {
                setIsAppDownloadModalOpen(true);
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-bold text-cyan-300 hover:bg-cyan-950/30 border border-cyan-500/20 flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>📥 Tải File App Client (Bản Thử Nghiệm)</span>
              </div>
              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-200">
                Exclusive
              </span>
            </button>
            <button
              onClick={() => {
                setIsRoiModalOpen(true);
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-emerald-300 hover:bg-[#111111] flex items-center gap-2"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>📊 Bảng Tính Tiết Kiệm (ROI MMO)</span>
            </button>
            <button
              onClick={() => {
                setIsCommandPaletteOpen(true);
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-300 hover:bg-[#111111] flex items-center gap-2"
            >
              <Command className="w-3.5 h-3.5 text-blue-400" />
              <span>🔍 Tìm Kiếm Nhanh (Ctrl + K)</span>
            </button>
            <button
              onClick={() => {
                setIsTopupModalOpen(true);
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-emerald-400 hover:bg-[#111111] flex items-center gap-2"
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>💰 Nạp Tiền Vào Ví (Tự động)</span>
            </button>
            <button
              onClick={() => {
                openKeyValidator('activate');
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-teal-400 hover:bg-[#111111] flex items-center gap-2"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>⚡ Kích Hoạt Key Bản Quyền</span>
            </button>
            <button
              onClick={() => {
                openKeyValidator('validate');
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-blue-400 hover:bg-[#111111]"
            >
              Tra Cứu & Kiểm Tra Key
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
