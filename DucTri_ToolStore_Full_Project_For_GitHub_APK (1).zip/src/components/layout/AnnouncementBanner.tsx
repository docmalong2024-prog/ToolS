import React from 'react';
import { useSystem } from '../../contexts/SystemContext';
import { Sparkles, AlertTriangle, Info, Download, Flame } from 'lucide-react';

export const AnnouncementBanner: React.FC = () => {
  const { settings, setIsAppDownloadModalOpen } = useSystem();
  const banner = settings.announcementBanner;

  if (!banner.enabled || !banner.text) return null;

  return (
    <div className="relative border-b border-cyan-500/30 bg-[#06101d]/90 backdrop-blur-xl py-2 px-4 text-xs transition-all overflow-hidden shadow-[0_4px_20px_rgba(6,182,212,0.15)]">
      {/* Top Glass Glow Line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
      
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto py-0.5 scrollbar-none font-medium text-cyan-200">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0 animate-pulse" />
          <span className="truncate">{banner.text}</span>
          <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 text-[10px] font-mono">
            <Flame className="w-3 h-3 text-cyan-300" /> Bản Thử Nghiệm Beta
          </span>
        </div>

        <div className="flex items-center gap-3 text-[11px] text-slate-300 shrink-0">
          <button
            onClick={() => setIsAppDownloadModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 border border-cyan-400/40 transition-all font-mono font-bold shadow-[0_0_10px_rgba(6,182,212,0.3)]"
          >
            <Download className="w-3 h-3" />
            <span>Tải App Client (.EXE)</span>
          </button>
          <span className="hidden md:inline text-slate-600">|</span>
          <span className="hidden md:inline font-mono">Zalo: <strong className="text-white">{settings.contactInfo.hotline}</strong></span>
        </div>
      </div>
    </div>
  );
};

