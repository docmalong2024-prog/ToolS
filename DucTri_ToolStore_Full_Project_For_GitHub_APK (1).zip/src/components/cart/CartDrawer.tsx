import React, { useState } from 'react';
import { useCart } from '../../contexts/CartContext';
import { useAuth } from '../../contexts/AuthContext';
import { useSystem } from '../../contexts/SystemContext';
import { storage } from '../../services/storage';
import { PurchasedLicense } from '../../types';
import { KeyRevealModal } from '../common/KeyRevealModal';
import { VietQRPaymentModal } from '../common/VietQRPaymentModal';
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  Wallet,
  QrCode,
  Smartphone,
  ArrowRight,
  ShieldCheck,
  Zap,
  Tag,
  X
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    cartItems,
    removeFromCart,
    updateQuantity,
    clearCart,
    totalAmount,
    totalOriginalAmount,
    totalSavings,
    isCartOpen,
    setIsCartOpen,
  } = useCart();

  const { currentUser, refreshUserData } = useAuth();
  const { formatVND, showToast, setIsTopupModalOpen } = useSystem();

  const [paymentMethod, setPaymentMethod] = useState<'wallet' | 'vietqr' | 'momo'>('wallet');
  const [promoCode, setPromoCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  // Modals for delivery
  const [revealLicenses, setRevealLicenses] = useState<PurchasedLicense[]>([]);
  const [deliveredOrderId, setDeliveredOrderId] = useState<string>('');
  const [showRevealModal, setShowRevealModal] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [activeQRRef, setActiveQRRef] = useState<string>('');

  if (!isCartOpen) return null;

  // Reseller wholesale discount logic
  const isResellerApproved = currentUser?.role === 'reseller' && currentUser?.resellerStatus === 'approved';
  const resellerDiscountPct = isResellerApproved ? (currentUser?.resellerDiscountPercent || 15) : 0;

  // Final amount calculation
  const subtotal = totalAmount;
  const resellerDiscountAmt = isResellerApproved ? Math.round((subtotal * resellerDiscountPct) / 100) : 0;
  const promoDiscountAmt = Math.round(((subtotal - resellerDiscountAmt) * appliedDiscount) / 100);
  const finalAmount = Math.max(0, subtotal - resellerDiscountAmt - promoDiscountAmt);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promoCode.trim().toUpperCase();
    if (clean === 'TOOLSTORE20' || clean === 'VIP20') {
      setAppliedDiscount(20);
      showToast('Áp dụng mã giảm 20% thành công!', 'TOOLSTORE20', 'success');
    } else if (clean === 'PRO10') {
      setAppliedDiscount(10);
      showToast('Áp dụng mã giảm 10% thành công!', 'PRO10', 'success');
    } else {
      showToast('Mã giảm giá không hợp lệ hoặc đã hết hạn!', undefined, 'error');
    }
  };

  const handleProcessPurchase = (method: 'wallet' | 'vietqr' | 'momo') => {
    if (!currentUser) {
      showToast('Vui lòng đăng nhập để hoàn tất đơn hàng!', undefined, 'warning');
      return;
    }

    if (cartItems.length === 0) return;

    if (method === 'wallet' && currentUser.balance < finalAmount) {
      showToast('Số dư ví không đủ! Vui lòng nạp thêm hoặc chọn VietQR.', undefined, 'error');
      return;
    }

    if (method === 'vietqr' || method === 'momo') {
      const txRef = `ORD${Math.floor(100000 + Math.random() * 900000)}`;
      setActiveQRRef(txRef);
      setShowQRModal(true);
      return;
    }

    // Execute wallet atomic purchase
    try {
      setIsCheckingOut(true);
      const res = storage.purchaseItems({
        userId: currentUser.id,
        items: cartItems,
        paymentMethod: 'wallet',
      });

      refreshUserData();
      clearCart();
      setIsCartOpen(false);
      setRevealLicenses(res.licenses);
      setDeliveredOrderId(res.orderId);
      setShowRevealModal(true);
    } catch (e: any) {
      showToast('Lỗi xử lý đơn hàng', e.message, 'error');
    } finally {
      setIsCheckingOut(false);
    }
  };

  const handleQRPaymentSuccess = () => {
    if (!currentUser) return;
    try {
      const res = storage.purchaseItems({
        userId: currentUser.id,
        items: cartItems,
        paymentMethod: 'vietqr',
      });

      refreshUserData();
      clearCart();
      setShowQRModal(false);
      setIsCartOpen(false);
      setRevealLicenses(res.licenses);
      setDeliveredOrderId(res.orderId);
      setShowRevealModal(true);
    } catch (e: any) {
      showToast('Lỗi cấp key sau thanh toán QR', e.message, 'error');
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Backdrop */}
        <div
          onClick={() => setIsCartOpen(false)}
          className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        />

        <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
          <div className="w-screen max-w-md bg-[#0a0a0a] border-l border-white/10 flex flex-col shadow-[0_0_50px_rgba(0,0,0,0.95)]">
            {/* Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#050505]">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-wide">Giỏ Hàng Bản Quyền</h3>
                  <p className="text-xs text-slate-400">
                    {cartItems.length} sản phẩm đang chờ thanh toán
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Reseller VIP badge notification */}
            {isResellerApproved && (
              <div className="p-3 bg-amber-500/10 border-b border-amber-500/20 flex items-center gap-2 text-xs text-amber-300">
                <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  Đã áp dụng mức chiết khấu Đại Lý <strong>-{resellerDiscountPct}%</strong> cho toàn bộ đơn hàng!
                </span>
              </div>
            )}

            {/* Cart Items Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-3">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#111111] border border-white/10 flex items-center justify-center text-slate-500">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-white">Giỏ hàng của bạn đang trống</h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs">
                      Khám phá ngay các tool MMO, Auto Marketing và Bot đỉnh cao để tối ưu công việc!
                    </p>
                  </div>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] transition-all"
                  >
                    Xem Danh Mục Tool
                  </button>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div
                    key={`${item.tool.id}_${item.plan.id}`}
                    className="p-3.5 rounded-xl bg-[#111111] border border-white/10 hover:border-white/20 transition-all space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={item.tool.images[0]}
                          alt={item.tool.name}
                          className="w-10 h-10 rounded-lg object-cover border border-white/10 shrink-0"
                        />
                        <div>
                          <h4 className="text-xs font-bold text-white line-clamp-1">
                            {item.tool.name}
                          </h4>
                          <span className="text-[11px] font-mono text-blue-400">
                            {item.plan.name} ({item.plan.durationDays > 90000 ? 'Trọn đời' : `${item.plan.durationDays} ngày`})
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.tool.id, item.plan.id)}
                        className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                      {/* Quantity buttons */}
                      <div className="flex items-center gap-2 bg-[#050505] border border-white/10 rounded-lg p-1">
                        <button
                          onClick={() => updateQuantity(item.tool.id, item.plan.id, item.quantity - 1)}
                          className="p-0.5 text-slate-400 hover:text-white rounded transition-colors"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="font-mono text-xs font-bold text-white px-1.5">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.tool.id, item.plan.id, item.quantity + 1)}
                          className="p-0.5 text-slate-400 hover:text-white rounded transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Price */}
                      <div className="text-right font-mono">
                        <span className="text-xs font-bold text-emerald-400 block">
                          {formatVND(item.plan.salePrice * item.quantity)}
                        </span>
                        {item.plan.originalPrice > item.plan.salePrice && (
                          <span className="text-[10px] text-slate-500 line-through">
                            {formatVND(item.plan.originalPrice * item.quantity)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Cart Footer */}
            {cartItems.length > 0 && (
              <div className="p-5 border-t border-white/10 bg-[#050505] space-y-4">
                {/* Promo Code Form */}
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="text"
                      placeholder="Mã giảm giá (VD: TOOLSTORE20)..."
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="w-full bg-[#111111] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder:text-slate-600 uppercase font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#141414] hover:bg-white/10 text-blue-300 border border-white/10 transition-colors"
                  >
                    Áp Dụng
                  </button>
                </form>

                {/* Bill Breakdown */}
                <div className="space-y-1.5 text-xs text-slate-400 font-mono">
                  <div className="flex justify-between">
                    <span>Tạm tính:</span>
                    <span className="text-slate-200">{formatVND(subtotal)}</span>
                  </div>
                  {isResellerApproved && resellerDiscountAmt > 0 && (
                    <div className="flex justify-between text-amber-400">
                      <span>Chiết khấu đại lý (-{resellerDiscountPct}%):</span>
                      <span>-{formatVND(resellerDiscountAmt)}</span>
                    </div>
                  )}
                  {appliedDiscount > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Voucher giảm giá (-{appliedDiscount}%):</span>
                      <span>-{formatVND(promoDiscountAmt)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-white/10">
                    <span>Tổng thanh toán:</span>
                    <span className="text-emerald-400 text-base">{formatVND(finalAmount)}</span>
                  </div>
                </div>

                {/* Payment Methods Choice */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('wallet')}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all ${
                      paymentMethod === 'wallet'
                        ? 'border-blue-500 bg-blue-500/15 text-white shadow-[0_0_15px_rgba(37,99,235,0.2)]'
                        : 'border-white/10 bg-[#111111] text-slate-400'
                    }`}
                  >
                    <Wallet className="w-4 h-4 text-blue-400 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[11px] font-bold">Số Dư Ví</div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {currentUser ? formatVND(currentUser.balance) : '0 ₫'}
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('vietqr')}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all ${
                      paymentMethod === 'vietqr'
                        ? 'border-blue-500 bg-blue-500/15 text-white shadow-[0_0_15px_rgba(37,99,235,0.2)]'
                        : 'border-white/10 bg-[#111111] text-slate-400'
                    }`}
                  >
                    <QrCode className="w-4 h-4 text-blue-400 shrink-0" />
                    <div>
                      <div className="text-[11px] font-bold">VietQR Tức Thì</div>
                      <div className="text-[10px] text-blue-400">Quét App Bank</div>
                    </div>
                  </button>
                </div>

                {/* Top-up shortcut if wallet balance insufficient */}
                {paymentMethod === 'wallet' && currentUser && currentUser.balance < finalAmount && (
                  <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-500/30 flex items-center justify-between text-xs">
                    <span className="text-rose-300 text-[11px]">
                      Thiếu {formatVND(finalAmount - currentUser.balance)}
                    </span>
                    <button
                      onClick={() => setIsTopupModalOpen(true)}
                      className="text-blue-400 font-bold hover:underline text-[11px]"
                    >
                      + Nạp Thêm Ngay
                    </button>
                  </div>
                )}

                {/* Checkout Submit Button */}
                <button
                  onClick={() => handleProcessPurchase(paymentMethod)}
                  disabled={isCheckingOut}
                  className="w-full py-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_25px_rgba(37,99,235,0.4)] transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Xác Nhận Thanh Toán & Nhận Key Ngay</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Payment Confirmation Modals */}
      {showQRModal && (
        <VietQRPaymentModal
          isOpen={showQRModal}
          onClose={() => setShowQRModal(false)}
          amount={finalAmount}
          orderCode={activeQRRef}
          onPaymentSuccess={handleQRPaymentSuccess}
          title="Thanh Toán Đơn Hàng Qua VietQR"
          description="Quét mã QR để hoàn tất và nhận Key bản quyền tức thì"
        />
      )}

      {showRevealModal && (
        <KeyRevealModal
          isOpen={showRevealModal}
          onClose={() => setShowRevealModal(false)}
          licenses={revealLicenses}
          orderId={deliveredOrderId}
        />
      )}
    </>
  );
};
