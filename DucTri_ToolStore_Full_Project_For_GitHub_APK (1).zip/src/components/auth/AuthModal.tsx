import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useSystem } from '../../contexts/SystemContext';
import {
  Lock,
  Mail,
  User as UserIcon,
  Shield,
  Zap,
  KeyRound,
  ArrowRight,
  CheckCircle2,
  X,
  Sparkles,
  Layers,
  Crown
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, showToast } = useSystem();
  const { login, register, switchDemoUser } = useAuth();

  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [registerRole, setRegisterRole] = useState<'user' | 'reseller'>('user');
  const [forgotOtpSent, setForgotOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');

  if (!isAuthModalOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      showToast('Vui lòng nhập email!', undefined, 'error');
      return;
    }
    try {
      login(email);
      showToast('Đăng nhập thành công!', 'Chào mừng bạn quay trở lại ToolStore Pro.', 'success');
      setIsAuthModalOpen(false);
    } catch (e: any) {
      showToast('Lỗi đăng nhập', e.message, 'error');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) {
      showToast('Vui lòng điền đủ họ tên và email!', undefined, 'error');
      return;
    }
    try {
      register(name, email, registerRole);
      showToast(
        'Đăng ký tài khoản thành công!',
        registerRole === 'reseller'
          ? 'Đơn đăng ký Đại lý của bạn đang chờ Admin duyệt.'
          : 'Tài khoản đã sẵn sàng sử dụng.',
        'success'
      );
      setIsAuthModalOpen(false);
    } catch (e: any) {
      showToast('Lỗi đăng ký', e.message, 'error');
    }
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      showToast('Vui lòng nhập email!', undefined, 'error');
      return;
    }
    setForgotOtpSent(true);
    showToast('Đã gửi mã OTP xác nhận!', 'Mã OTP thử nghiệm là 888999', 'info');
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode !== '888999' && otpCode !== '123456') {
      showToast('Mã OTP không chính xác!', 'Vui lòng nhập 888999 để thử nghiệm', 'error');
      return;
    }
    showToast('Đặt lại mật khẩu thành công!', 'Vui lòng đăng nhập với mật khẩu mới.', 'success');
    setActiveTab('login');
    setForgotOtpSent(false);
  };

  const handleQuickDemo = (role: 'user' | 'reseller' | 'admin') => {
    switchDemoUser(role);
    const roleNames = {
      user: 'Khách hàng VIP (Minh Trí)',
      reseller: 'Đại Lý Cấp 1 (Hoàng Nam Gold)',
      admin: 'Quản Trị Viên (Super Admin)',
    };
    showToast(`Đã chuyển sang tài khoản Demo: ${roleNames[role]}`, undefined, 'success');
    setIsAuthModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.9)] overflow-hidden my-6">
        {/* Top Glow Bar */}
        <div className="h-1.5 w-full bg-gradient-to-r from-blue-600 via-indigo-500 to-blue-400" />

        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#050505]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">
                {activeTab === 'login' && 'Đăng Nhập Hệ Thống'}
                {activeTab === 'register' && 'Đăng Ký Tài Khoản Mới'}
                {activeTab === 'forgot' && 'Khôi Phục Mật Khẩu'}
              </h3>
              <p className="text-xs text-slate-400">Bảo mật tài khoản với công nghệ mã hóa RBAC</p>
            </div>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10 bg-[#050505] p-1">
          <button
            onClick={() => setActiveTab('login')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'login'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Đăng Nhập
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'register'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Đăng Ký
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Quick 1-Click Demo Logins */}
          <div className="p-3.5 rounded-xl bg-[#111111] border border-white/10 space-y-2">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase text-blue-400 tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Đăng nhập nhanh 1-Click (Tài khoản thử nghiệm):</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('user')}
                className="p-2 rounded-lg bg-[#050505] hover:bg-white/10 border border-white/10 hover:border-blue-500/40 text-left transition-all group"
              >
                <div className="text-[11px] font-bold text-white group-hover:text-blue-300">Khách Hàng</div>
                <div className="text-[9px] text-slate-400">Minh Trí (VIP)</div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('reseller')}
                className="p-2 rounded-lg bg-[#050505] hover:bg-amber-500/20 border border-white/10 hover:border-amber-500/40 text-left transition-all group"
              >
                <div className="text-[11px] font-bold text-amber-400 group-hover:text-amber-300">Đại Lý Gold</div>
                <div className="text-[9px] text-slate-400">Chiết khấu 20%</div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('admin')}
                className="p-2 rounded-lg bg-[#050505] hover:bg-purple-500/20 border border-white/10 hover:border-purple-500/40 text-left transition-all group"
              >
                <div className="text-[11px] font-bold text-purple-400 group-hover:text-purple-300">Super Admin</div>
                <div className="text-[9px] text-slate-400">Toàn quyền sàn</div>
              </button>
            </div>
          </div>

          {/* Login Form */}
          {activeTab === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1.5">Email:</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-600 transition-colors font-mono"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs text-slate-300 font-semibold">Mật khẩu:</label>
                  <button
                    type="button"
                    onClick={() => setActiveTab('forgot')}
                    className="text-[11px] text-blue-400 hover:underline"
                  >
                    Quên mật khẩu?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-600 transition-colors font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all flex items-center justify-center gap-2"
              >
                <span>Đăng Nhập Ngay</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Register Form */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1.5">Họ và tên:</label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="Nguyễn Văn A"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-600 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1.5">Địa chỉ Email:</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="email@domain.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-600 transition-colors font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1.5">Mật khẩu:</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    placeholder="Tối thiểu 6 ký tự..."
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-600 transition-colors font-mono"
                  />
                </div>
              </div>

              {/* Account Type Selection */}
              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1.5">Loại tài khoản:</label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setRegisterRole('user')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      registerRole === 'user'
                        ? 'border-blue-500 bg-blue-500/10 text-blue-300'
                        : 'border-white/10 bg-[#111111] text-slate-400'
                    }`}
                  >
                    <div className="text-xs font-bold">Khách Hàng</div>
                    <div className="text-[10px] text-slate-400">Mua lẻ & Dùng cá nhân</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRegisterRole('reseller')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      registerRole === 'reseller'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                        : 'border-white/10 bg-[#111111] text-slate-400'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1">
                      <span>Đại Lý / Đối Tác</span>
                      <Crown className="w-3 h-3 text-amber-400" />
                    </div>
                    <div className="text-[10px] text-slate-400">Chiết khấu sỉ tới 35%</div>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all flex items-center justify-center gap-2"
              >
                <span>Tạo Tài Khoản Ngay</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Forgot Password Flow */}
          {activeTab === 'forgot' && (
            <div className="space-y-4">
              {!forgotOtpSent ? (
                <form onSubmit={handleSendOtp} className="space-y-4">
                  <p className="text-xs text-slate-300">
                    Nhập email tài khoản của bạn để nhận mã OTP khôi phục mật khẩu 6 số:
                  </p>
                  <div>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                      <input
                        type="email"
                        required
                        placeholder="name@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-600 transition-colors font-mono"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white transition-all flex items-center justify-center gap-2"
                  >
                    <span>Gửi Mã OTP Xác Thực</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div className="p-2.5 rounded-lg bg-blue-950/30 border border-blue-500/30 text-xs text-blue-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                    <span>Mã OTP thử nghiệm demo: <strong>888999</strong></span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 font-semibold block mb-1.5">Mã OTP (6 số):</label>
                    <input
                      type="text"
                      maxLength={6}
                      required
                      placeholder="888999"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl px-4 py-2.5 text-center font-mono text-base tracking-widest text-blue-300"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 font-semibold block mb-1.5">Mật khẩu mới:</label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl px-4 py-2.5 text-xs text-white font-mono"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-500 text-white transition-all flex items-center justify-center gap-2"
                  >
                    <span>Xác Nhận & Đổi Mật Khẩu</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                </form>
              )}

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('login')}
                  className="text-xs text-slate-400 hover:text-blue-300 transition-colors"
                >
                  ← Quay lại Đăng Nhập
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
