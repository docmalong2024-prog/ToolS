import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useSystem } from '../../contexts/SystemContext';
import { storage } from '../../services/storage';
import {
  ToolItem,
  User,
  LicenseKeyRecord,
  WithdrawalRequest,
  Transaction,
  SystemSettings,
  PricingPlan,
  ToolCategory,
  ResellerTier
} from '../../types';
import {
  Shield,
  Layers,
  Key,
  Users,
  DollarSign,
  Settings,
  TrendingUp,
  Plus,
  Trash2,
  Edit,
  CheckCircle2,
  XCircle,
  Lock,
  Unlock,
  AlertTriangle,
  Upload,
  Search,
  RefreshCw,
  Sparkles,
  Save,
  Check,
  X,
  CreditCard,
  QrCode
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { currentUser, refreshUserData } = useAuth();
  const { settings, updateSettings, formatVND, formatDate, showToast } = useSystem();

  const [activeTab, setActiveTab] = useState<
    'analytics' | 'tools' | 'keys' | 'users' | 'finance' | 'settings'
  >('analytics');

  // Tools Management State
  const [toolsList, setToolsList] = useState<ToolItem[]>(storage.getTools());
  const [editingTool, setEditingTool] = useState<ToolItem | null>(null);
  const [isToolModalOpen, setIsToolModalOpen] = useState(false);

  // Key Vault Management State
  const [keyVault, setKeyVault] = useState<LicenseKeyRecord[]>(storage.getKeyVault());
  const [selectedKeyToolId, setSelectedKeyToolId] = useState<string>(toolsList[0]?.id || '');
  const [selectedKeyPlanId, setSelectedKeyPlanId] = useState<string>(toolsList[0]?.plans[0]?.id || '');
  const [bulkKeysInput, setBulkKeysInput] = useState<string>('');
  const [bulkKeyNotes, setBulkKeyNotes] = useState<string>('Import bởi Super Admin');

  // Users & RBAC Management State
  const [usersList, setUsersList] = useState<User[]>(storage.getUsers());
  const [userSearch, setUserSearch] = useState<string>('');
  const [balanceModalUser, setBalanceModalUser] = useState<User | null>(null);
  const [balanceAdjustmentAmount, setBalanceAdjustmentAmount] = useState<string>('500000');
  const [balanceAdjustmentReason, setBalanceAdjustmentReason] = useState<string>('Thưởng đại lý xuất sắc');

  // Financial & Withdrawals State
  const [withdrawalsList, setWithdrawalsList] = useState<WithdrawalRequest[]>(storage.getWithdrawals());
  const [transactionsList, setTransactionsList] = useState<Transaction[]>(storage.getTransactions());

  // Settings State Form
  const [settingsForm, setSettingsForm] = useState<SystemSettings>(settings);

  if (currentUser?.role !== 'admin') {
    return (
      <div className="max-w-md mx-auto my-20 p-8 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-center space-y-4">
        <Shield className="w-12 h-12 text-rose-400 mx-auto" />
        <h2 className="text-lg font-bold text-white">Yêu Cầu Quyền Super Admin</h2>
        <p className="text-xs text-slate-300">
          Bạn cần đăng nhập với vai trò Quản Trị Viên để truy cập phân hệ quản lý hệ thống.
        </p>
      </div>
    );
  }

  // Refresh lists
  const reloadData = () => {
    setToolsList(storage.getTools());
    setKeyVault(storage.getKeyVault());
    setUsersList(storage.getUsers());
    setWithdrawalsList(storage.getWithdrawals());
    setTransactionsList(storage.getTransactions());
    refreshUserData();
  };

  // Analytics Metrics
  const totalGMV = transactionsList
    .filter((t) => t.type === 'deposit' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalKeysSold = keyVault.filter((k) => k.status === 'sold').length;
  const totalAvailableKeys = keyVault.filter((k) => k.status === 'available').length;
  const pendingWithdrawalsCount = withdrawalsList.filter((w) => w.status === 'pending').length;

  // --- Handlers: Tool CRUD ---
  const handleSaveTool = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTool) return;
    storage.saveTool(editingTool);
    setIsToolModalOpen(false);
    reloadData();
    showToast('Đã lưu thông tin Tool thành công!', undefined, 'success');
  };

  const handleDeleteTool = (toolId: string) => {
    if (confirm('Bạn có chắc chắn muốn xóa Tool này khỏi hệ thống?')) {
      storage.deleteTool(toolId);
      reloadData();
      showToast('Đã xóa Tool thành công!', undefined, 'success');
    }
  };

  // --- Handlers: Key Vault ---
  const handleBulkImportKeys = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bulkKeysInput.trim()) {
      showToast('Vui lòng nhập danh sách mã Key!', undefined, 'error');
      return;
    }
    const count = storage.addBulkKeys(selectedKeyToolId, selectedKeyPlanId, bulkKeysInput, bulkKeyNotes);
    setBulkKeysInput('');
    reloadData();
    showToast(`Đã nạp thành công +${count} Key vào kho!`, undefined, 'success');
  };

  // --- Handlers: User & RBAC ---
  const handleToggleLockUser = (user: User) => {
    try {
      const isLocked = storage.toggleLockUser(user.id);
      reloadData();
      showToast(isLocked ? `Đã khóa tài khoản ${user.name}` : `Đã mở khóa tài khoản ${user.name}`, undefined, 'info');
    } catch (e: any) {
      showToast('Lỗi thao tác', e.message, 'error');
    }
  };

  const handleApproveResellerRole = (user: User, tier: ResellerTier) => {
    storage.setUserRole(user.id, 'reseller', tier);
    reloadData();
    showToast(`Đã duyệt quyền Đại Lý (${tier.toUpperCase()}) cho ${user.name}!`, undefined, 'success');
  };

  const handleAdjustBalance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!balanceModalUser) return;
    const amountNum = parseInt(balanceAdjustmentAmount.replace(/\D/g, ''), 10) || 0;
    try {
      storage.adjustUserBalance(balanceModalUser.id, amountNum, balanceAdjustmentReason);
      reloadData();
      setBalanceModalUser(null);
      showToast(`Đã điều chỉnh ${formatVND(amountNum)} cho ${balanceModalUser.name}!`, undefined, 'success');
    } catch (e: any) {
      showToast('Lỗi điều chỉnh số dư', e.message, 'error');
    }
  };

  // --- Handlers: Withdrawals ---
  const handleApproveWithdrawal = (wdrId: string) => {
    try {
      storage.approveWithdrawal(wdrId, 'Admin đã giải ngân thành công qua ngân hàng');
      reloadData();
      showToast('Đã duyệt và hoàn tất lệnh rút tiền!', undefined, 'success');
    } catch (e: any) {
      showToast('Lỗi duyệt', e.message, 'error');
    }
  };

  const handleRejectWithdrawal = (wdrId: string) => {
    const reason = prompt('Nhập lý do từ chối lệnh rút tiền:', 'Sai thông tin số tài khoản thụ hưởng');
    if (!reason) return;
    try {
      storage.rejectWithdrawal(wdrId, reason);
      reloadData();
      showToast('Đã từ chối và hoàn tiền về ví đại lý!', undefined, 'info');
    } catch (e: any) {
      showToast('Lỗi từ chối', e.message, 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Admin Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#0a0a0a] border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.8)] flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-mono font-extrabold uppercase bg-blue-600 text-white shadow">
              👑 SUPER ADMIN CONTROL PANEL
            </span>
            <span className="text-xs font-mono text-blue-300">
              Quyền quản trị tối cao toàn sàn
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Trung Tâm Quản Trị Hệ Thống ToolStore Pro
          </h1>
          <p className="text-xs text-slate-300">
            Quản trị kho tool, nạp xuất key tự động, phân quyền RBAC đại lý, duyệt rút tiền và cấu hình cổng thanh toán.
          </p>
        </div>

        {/* Quick alerts */}
        <div className="flex items-center gap-3">
          {pendingWithdrawalsCount > 0 && (
            <div className="px-4 py-3 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-2 animate-pulse">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>{pendingWithdrawalsCount} Lệnh Rút Tiền Chờ Duyệt</span>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-[#0a0a0a] p-1 rounded-xl gap-1 overflow-x-auto">
        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex-1 min-w-32 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'analytics'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Thống Kê Tổng Quan</span>
        </button>

        <button
          onClick={() => setActiveTab('tools')}
          className={`flex-1 min-w-32 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'tools'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Kho Tool ({toolsList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('keys')}
          className={`flex-1 min-w-32 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'keys'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Kho Key ({totalAvailableKeys} Sẵn)</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`flex-1 min-w-32 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'users'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Người Dùng & RBAC ({usersList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('finance')}
          className={`flex-1 min-w-32 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'finance'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Tài Chính & Duyệt Rút ({withdrawalsList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex-1 min-w-32 py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'settings'
              ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Cài Đặt Hệ Thống</span>
        </button>
      </div>

      {/* Tab 1: Analytics */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Tổng Doanh Thu Nạp Sàn (GMV)</span>
              <div className="text-2xl font-mono font-bold text-emerald-400">{formatVND(totalGMV)}</div>
              <span className="text-[11px] text-slate-500 font-mono">Qua VietQR & MoMo tự động</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Tổng Key Đã Xuất Bán</span>
              <div className="text-2xl font-mono font-bold text-blue-400">{totalKeysSold} Key</div>
              <span className="text-[11px] text-slate-500">Tự động trừ kho FIFO</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Key Bản Quyền Sẵn Có</span>
              <div className="text-2xl font-mono font-bold text-amber-400">{totalAvailableKeys} Key</div>
              <span className="text-[11px] text-slate-500">Trong kho lưu trữ</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Tổng Tài Khoản Khách</span>
              <div className="text-2xl font-mono font-bold text-purple-400">{usersList.length} User</div>
              <span className="text-[11px] text-slate-500">Phân quyền chặt chẽ RBAC</span>
            </div>
          </div>

          {/* Low inventory alert table */}
          <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase text-amber-400 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Cảnh Báo Tồn Kho Key Sắp Hết (Cần Nạp Thêm):</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              {toolsList.map((tool) => {
                const stock = storage.getAvailableKeyCount(tool.id);
                const isLow = stock <= tool.warningStockThreshold;
                return (
                  <div
                    key={tool.id}
                    className={`p-4 rounded-xl border flex items-center justify-between ${
                      isLow ? 'bg-amber-950/30 border-amber-500/40' : 'bg-[#111111] border-white/10'
                    }`}
                  >
                    <div>
                      <h4 className="font-bold text-white line-clamp-1">{tool.name}</h4>
                      <span className="text-slate-400 text-[11px]">Ngưỡng cảnh báo: {tool.warningStockThreshold} key</span>
                    </div>
                    <div className="text-right">
                      <span className={`text-base font-mono font-bold ${isLow ? 'text-amber-400' : 'text-emerald-400'}`}>
                        {stock} Key
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Tools Management */}
      {activeTab === 'tools' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white tracking-wide">
              Danh Sách Phần Mềm & Tool Trong Hệ Thống
            </h3>
            <button
              onClick={() => {
                setEditingTool({
                  id: `tool_${Date.now()}`,
                  slug: 'new-tool-slug',
                  name: 'Tool Mới Bản Quyền 2026',
                  tagline: 'Mô tả ngắn tính năng nổi bật của tool...',
                  description: 'Chi tiết tính năng và công nghệ...',
                  features: ['Tính năng tự động 1', 'Tính năng chống checkpoint 2'],
                  category: 'marketing_mmo',
                  version: '1.0.0',
                  lastUpdated: new Date().toISOString().split('T')[0],
                  downloadUrl: 'https://downloads.toolstore.pro/setup/New_Tool.exe',
                  fileSize: '95 MB',
                  osCompatibility: ['Windows 10 / 11'],
                  requirements: ['RAM 8GB'],
                  images: ['https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80'],
                  plans: [
                    {
                      id: `plan_${Date.now()}_1m`,
                      duration: '1_month',
                      name: 'Gói 1 Tháng',
                      durationDays: 30,
                      originalPrice: 500000,
                      salePrice: 350000,
                    },
                    {
                      id: `plan_${Date.now()}_lifetime`,
                      duration: 'lifetime',
                      name: 'Gói Vĩnh Viễn',
                      durationDays: 99999,
                      originalPrice: 5000000,
                      salePrice: 3500000,
                      badge: 'VIP'
                    }
                  ],
                  tags: ['Hot', 'New'],
                  rating: 5.0,
                  reviewCount: 0,
                  totalSold: 0,
                  isActive: true,
                  warningStockThreshold: 5,
                });
                setIsToolModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 shadow-[0_0_15px_rgba(37,99,235,0.3)] transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm Tool Mới</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {toolsList.map((tool) => (
              <div
                key={tool.id}
                className="p-5 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={tool.images[0]}
                      alt={tool.name}
                      className="w-12 h-12 rounded-xl object-cover border border-white/10 shrink-0"
                    />
                    <div>
                      <h4 className="font-bold text-white text-sm">{tool.name}</h4>
                      <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                        <span className="text-blue-400 font-mono">v{tool.version}</span>
                        <span>•</span>
                        <span>Đã bán: <strong className="text-amber-300 font-mono">{tool.totalSold}</strong></span>
                        <span>•</span>
                        <span className="text-emerald-400 font-mono">Sẵn: {storage.getAvailableKeyCount(tool.id)} Key</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setEditingTool(tool);
                        setIsToolModalOpen(true);
                      }}
                      className="p-2 rounded-lg bg-[#111111] hover:bg-blue-600/20 text-blue-300 border border-white/10"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteTool(tool.id)}
                      className="p-2 rounded-lg bg-[#111111] hover:bg-rose-500/20 text-rose-400 border border-white/10"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="pt-2 border-t border-white/10 flex flex-wrap gap-2 text-xs">
                  {tool.plans.map((p) => (
                    <span key={p.id} className="px-2 py-0.5 rounded bg-[#050505] text-slate-300 font-mono border border-white/10">
                      {p.name}: <strong>{formatVND(p.salePrice)}</strong>
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Key Vault & Bulk Import */}
      {activeTab === 'keys' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Bulk Import Keys */}
          <div className="md:col-span-5 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
              <Upload className="w-4 h-4 text-blue-400" />
              <span>Nạp Key Bản Quyền Vào Kho Hàng Loạt</span>
            </h3>

            <form onSubmit={handleBulkImportKeys} className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">1. Chọn Tool:</label>
                <select
                  value={selectedKeyToolId}
                  onChange={(e) => {
                    setSelectedKeyToolId(e.target.value);
                    const t = toolsList.find((tool) => tool.id === e.target.value);
                    if (t && t.plans.length > 0) setSelectedKeyPlanId(t.plans[0].id);
                  }}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white"
                >
                  {toolsList.map((t) => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">2. Chọn Gói Bản Quyền:</label>
                <select
                  value={selectedKeyPlanId}
                  onChange={(e) => setSelectedKeyPlanId(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white"
                >
                  {toolsList.find((t) => t.id === selectedKeyToolId)?.plans.map((p) => (
                    <option key={p.id} value={p.id}>{p.name} ({formatVND(p.salePrice)})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  3. Dán Danh Sách Key (Mỗi dòng 1 key):
                </label>
                <textarea
                  rows={6}
                  required
                  placeholder="TIKTOK-1M-XXXX-YYYY-ZZZZ-1234&#10;TIKTOK-1M-AAAA-BBBB-CCCC-5678&#10;TIKTOK-1M-9999-8888-7777-6666"
                  value={bulkKeysInput}
                  onChange={(e) => setBulkKeysInput(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 focus:border-blue-500 focus:outline-none rounded-xl p-3 font-mono text-xs text-blue-300 placeholder:text-slate-600"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Ghi chú nguồn key:</label>
                <input
                  type="text"
                  value={bulkKeyNotes}
                  onChange={(e) => setBulkKeyNotes(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] flex items-center justify-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>Nạp Key Vào Kho Tức Thì</span>
              </button>
            </form>
          </div>

          {/* Key Inventory Table */}
          <div className="md:col-span-7 p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white tracking-wide">
                Kho Key Bản Quyền Hiện Có ({keyVault.length} Key)
              </h3>
              <span className="text-xs text-emerald-400 font-mono">
                {totalAvailableKeys} Key Khả Dụng
              </span>
            </div>

            <div className="max-h-96 overflow-y-auto space-y-2">
              {keyVault.slice(0, 30).map((k) => {
                const tool = toolsList.find((t) => t.id === k.toolId);
                const plan = tool?.plans.find((p) => p.id === k.planId);
                return (
                  <div
                    key={k.id}
                    className="p-3 rounded-xl bg-[#050505] border border-white/10 text-xs flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="font-bold text-white font-mono text-xs text-blue-300">{k.keyCode}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {tool?.name || 'Tool'} - <span className="text-amber-300">{plan?.name}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        k.status === 'available'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : k.status === 'sold'
                          ? 'bg-blue-500/20 text-blue-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {k.status === 'available' && 'Khả Dụng'}
                        {k.status === 'sold' && 'Đã Bán'}
                        {k.status === 'revoked' && 'Đã Hủy'}
                      </span>

                      {k.status === 'available' && (
                        <button
                          onClick={() => {
                            storage.revokeKey(k.id);
                            reloadData();
                          }}
                          className="text-[10px] text-rose-400 hover:underline"
                        >
                          Hủy Key
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Users & RBAC */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className="text-base font-bold text-white tracking-wide">
              Quản Lý Người Dùng & Phân Quyền RBAC
            </h3>
            <div className="relative w-72">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Tìm user theo tên, email..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="rounded-2xl bg-[#0a0a0a] border border-white/10 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#050505] border-b border-white/10 text-slate-400 uppercase tracking-wider font-mono">
                  <tr>
                    <th className="p-3.5">Người Dùng</th>
                    <th className="p-3.5">Vai Trò RBAC</th>
                    <th className="p-3.5">Số Dư Ví Chính</th>
                    <th className="p-3.5">Ví Hoa Hồng</th>
                    <th className="p-3.5">Chiết Khấu</th>
                    <th className="p-3.5">Trạng Thái</th>
                    <th className="p-3.5 text-right">Thao Tác Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono">
                  {usersList
                    .filter((u) => u.name.toLowerCase().includes(userSearch.toLowerCase()) || u.email.toLowerCase().includes(userSearch.toLowerCase()))
                    .map((user) => (
                      <tr key={user.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-3.5">
                          <div className="font-bold text-white font-sans">{user.name}</div>
                          <div className="text-[11px] text-slate-400">{user.email}</div>
                        </td>
                        <td className="p-3.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            user.role === 'admin'
                              ? 'bg-purple-500/20 text-purple-300'
                              : user.role === 'reseller'
                              ? 'bg-amber-500/20 text-amber-300'
                              : 'bg-blue-500/20 text-blue-300'
                          }`}>
                            {user.role.toUpperCase()}
                          </span>
                        </td>
                        <td className="p-3.5 font-bold text-emerald-400">{formatVND(user.balance)}</td>
                        <td className="p-3.5 text-amber-300">{formatVND(user.resellerWalletBalance)}</td>
                        <td className="p-3.5 text-slate-300">
                          {user.resellerDiscountPercent ? `-${user.resellerDiscountPercent}%` : '0%'}
                        </td>
                        <td className="p-3.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] ${user.isLocked ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                            {user.isLocked ? 'Đã Khóa' : 'Hoạt Động'}
                          </span>
                        </td>
                        <td className="p-3.5 text-right space-x-1.5">
                          <button
                            onClick={() => setBalanceModalUser(user)}
                            className="px-2.5 py-1 rounded bg-[#111111] hover:bg-white/10 text-blue-300 border border-white/10 text-[11px]"
                          >
                            +/- Số Dư
                          </button>

                          {user.role !== 'admin' && (
                            <>
                              <button
                                onClick={() => handleApproveResellerRole(user, 'gold')}
                                className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[11px]"
                              >
                                Sét Đại Lý Gold
                              </button>
                              <button
                                onClick={() => handleToggleLockUser(user)}
                                className={`px-2.5 py-1 rounded text-[11px] ${user.isLocked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}
                              >
                                {user.isLocked ? 'Mở Khóa' : 'Khóa'}
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Finance & Withdrawals */}
      {activeTab === 'finance' && (
        <div className="space-y-6">
          {/* Pending Withdrawals */}
          <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white tracking-wide">
              Yêu Cầu Rút Tiền Hoa Hồng Chờ Duyệt ({withdrawalsList.length})
            </h3>

            <div className="space-y-3">
              {withdrawalsList.map((w) => (
                <div
                  key={w.id}
                  className="p-4 rounded-xl bg-[#050505] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-base text-amber-400">{formatVND(w.amount)}</span>
                      <span className="text-white font-bold">({w.resellerName})</span>
                    </div>
                    <div className="text-slate-400 font-mono mt-1">
                      {w.bankName} - STK: <strong className="text-blue-300">{w.bankAccount}</strong> ({w.bankAccountName})
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {w.status === 'pending' ? (
                      <>
                        <button
                          onClick={() => handleApproveWithdrawal(w.id)}
                          className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white"
                        >
                          ✓ Duyệt & Chuyển Tiền
                        </button>
                        <button
                          onClick={() => handleRejectWithdrawal(w.id)}
                          className="px-3 py-2 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 hover:bg-rose-500/30"
                        >
                          ✕ Từ Chối
                        </button>
                      </>
                    ) : (
                      <span className={`px-2.5 py-1 rounded text-[11px] font-mono font-bold ${w.status === 'approved' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
                        {w.status === 'approved' ? 'Đã Giải Ngân' : 'Bị Từ Chối'}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: System Settings Form */}
      {activeTab === 'settings' && (
        <div className="p-6 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-6 text-xs">
          <h3 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-400" />
            <span>Cấu Hình Tên Ứng Dụng, Avatar Logo & Cổng Thanh Toán</span>
          </h3>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              updateSettings(settingsForm);
            }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Tên Ứng Dụng (App Name):</label>
                <input
                  type="text"
                  value={settingsForm.appName}
                  onChange={(e) => setSettingsForm({ ...settingsForm, appName: e.target.value })}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Slogan / Khẩu hiệu:</label>
                <input
                  type="text"
                  value={settingsForm.slogan}
                  onChange={(e) => setSettingsForm({ ...settingsForm, slogan: e.target.value })}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2.5 text-white"
                />
              </div>
            </div>

            {/* VietQR Bank details */}
            <div className="p-4 rounded-xl bg-[#050505] border border-white/10 space-y-4">
              <h4 className="font-bold text-blue-400 uppercase text-xs">Cấu Hình Tài Khoản VietQR / Ngân Hàng:</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-slate-400 block mb-1">Mã Ngân Hàng (Bank ID):</label>
                  <input
                    type="text"
                    value={settingsForm.paymentConfig.vietqr.bankId}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        paymentConfig: {
                          ...settingsForm.paymentConfig,
                          vietqr: { ...settingsForm.paymentConfig.vietqr, bankId: e.target.value },
                        },
                      })
                    }
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Số Tài Khoản:</label>
                  <input
                    type="text"
                    value={settingsForm.paymentConfig.vietqr.accountNo}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        paymentConfig: {
                          ...settingsForm.paymentConfig,
                          vietqr: { ...settingsForm.paymentConfig.vietqr, accountNo: e.target.value },
                        },
                      })
                    }
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Tên Chủ Tài Khoản:</label>
                  <input
                    type="text"
                    value={settingsForm.paymentConfig.vietqr.accountName}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        paymentConfig: {
                          ...settingsForm.paymentConfig,
                          vietqr: { ...settingsForm.paymentConfig.vietqr, accountName: e.target.value },
                        },
                      })
                    }
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white uppercase font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Announcement Banner */}
            <div className="p-4 rounded-xl bg-[#050505] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-amber-400 uppercase text-xs">Thông Báo Khuyến Mãi Đầu Trang:</h4>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settingsForm.announcementBanner.enabled}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        announcementBanner: { ...settingsForm.announcementBanner, enabled: e.target.checked },
                      })
                    }
                    className="rounded"
                  />
                  <span>Bật banner</span>
                </label>
              </div>

              <input
                type="text"
                value={settingsForm.announcementBanner.text}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    announcementBanner: { ...settingsForm.announcementBanner, text: e.target.value },
                  })
                }
                className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>Lưu Cấu Hình Toàn Hệ Thống</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Adjust Balance Modal */}
      {balanceModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="font-bold text-white text-sm">
                Điều Chỉnh Số Dư: {balanceModalUser.name}
              </div>
              <button onClick={() => setBalanceModalUser(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAdjustBalance} className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">Số tiền (+ cộng thêm, - trừ bớt):</label>
                <input
                  type="text"
                  value={balanceAdjustmentAmount}
                  onChange={(e) => setBalanceAdjustmentAmount(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Lý do điều chỉnh (Lưu nhật ký kiểm toán):</label>
                <input
                  type="text"
                  required
                  value={balanceAdjustmentReason}
                  onChange={(e) => setBalanceAdjustmentReason(e.target.value)}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setBalanceModalUser(null)}
                  className="px-4 py-2 rounded-xl bg-[#111111] text-slate-300 border border-white/10"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] transition-all"
                >
                  Xác Nhận Thay Đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Tool Edit Modal */}
      {isToolModalOpen && editingTool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in">
          <div className="relative w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 shadow-2xl space-y-4 text-xs my-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="font-bold text-white text-base">
                Cập Nhật Thông Tin Tool: {editingTool.name}
              </div>
              <button onClick={() => setIsToolModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSaveTool} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Tên Tool:</label>
                  <input
                    type="text"
                    required
                    value={editingTool.name}
                    onChange={(e) => setEditingTool({ ...editingTool, name: e.target.value })}
                    className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Phiên Bản (Version):</label>
                  <input
                    type="text"
                    required
                    value={editingTool.version}
                    onChange={(e) => setEditingTool({ ...editingTool, version: e.target.value })}
                    className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Tagline ngắn:</label>
                <input
                  type="text"
                  required
                  value={editingTool.tagline}
                  onChange={(e) => setEditingTool({ ...editingTool, tagline: e.target.value })}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Đường dẫn tải file cài đặt (Download URL):</label>
                <input
                  type="text"
                  required
                  value={editingTool.downloadUrl}
                  onChange={(e) => setEditingTool({ ...editingTool, downloadUrl: e.target.value })}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Hình ảnh banner URL:</label>
                <input
                  type="text"
                  value={editingTool.images[0] || ''}
                  onChange={(e) => setEditingTool({ ...editingTool, images: [e.target.value] })}
                  className="w-full bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsToolModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-[#111111] text-slate-300 border border-white/10"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] transition-all"
                >
                  Lưu Thay Đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
