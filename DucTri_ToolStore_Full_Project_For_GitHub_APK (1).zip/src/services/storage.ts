import {
  User,
  ToolItem,
  LicenseKeyRecord,
  PurchasedLicense,
  Transaction,
  WithdrawalRequest,
  Review,
  SystemSettings,
  NotificationItem,
  CartItem,
  ResellerTier
} from '../types';

const STORAGE_KEYS = {
  USERS: 'toolstore_users_v1',
  CURRENT_USER_ID: 'toolstore_current_user_id_v1',
  TOOLS: 'toolstore_tools_v1',
  KEY_VAULT: 'toolstore_key_vault_v1',
  PURCHASED_LICENSES: 'toolstore_purchased_licenses_v1',
  TRANSACTIONS: 'toolstore_transactions_v1',
  WITHDRAWALS: 'toolstore_withdrawals_v1',
  REVIEWS: 'toolstore_reviews_v1',
  SYSTEM_SETTINGS: 'toolstore_settings_v1',
  NOTIFICATIONS: 'toolstore_notifications_v1',
  CART: 'toolstore_cart_v1',
};

// Default System Settings
export const DEFAULT_SYSTEM_SETTINGS: SystemSettings = {
  appName: 'ToolStore Pro',
  slogan: 'App By DucTri • Hệ Thống Phân Phối Tool & Key Bản Quyền Số 1 Việt Nam',
  logoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
  brandColor: '#2563eb', // Blue tech
  maintenanceMode: false,
  announcementBanner: {
    enabled: true,
    text: '🔥 App By DucTri (Zalo: 0826130621) - Giảm 20% toàn bộ Tool Auto Marketing & Tặng kèm Proxy sạch!',
    type: 'promotion',
  },
  contactInfo: {
    hotline: '0826130621',
    telegram: '@DucTri_Support',
    zalo: '0826130621',
    email: 'doductri6a6@gmail.com',
    workingHours: '24/7 (Hỗ trợ Zalo: 0826130621)',
  },
  paymentConfig: {
    vietqr: {
      bankId: 'MB',
      bankName: 'MBBank - Ngân hàng Quân Đội',
      accountNo: '888899998888',
      accountName: 'CONG TY TOOLSTORE PRO VN',
      qrTemplate: 'compact2',
    },
    momo: {
      phone: '0826130621',
      name: 'DO DUC TRI',
    },
    autoApproveDeposits: true,
  },
  resellerPolicy: {
    silverDiscount: 10,
    goldDiscount: 20,
    diamondDiscount: 35,
    minWithdrawalAmount: 200000,
  },
};

// Seed Users
const SEED_USERS: User[] = [
  {
    id: 'user_admin',
    email: 'admin@toolstore.pro',
    name: 'Quản Trị Viên (Super Admin)',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    balance: 50000000,
    resellerWalletBalance: 0,
    isLocked: false,
    createdAt: '2026-01-01T00:00:00.000Z',
    phone: '0988888999',
    telegram: '@toolstore_admin',
  },
  {
    id: 'user_reseller_gold',
    email: 'reseller.gold@toolstore.pro',
    name: 'Đại Lý Hoàng Nam (Gold Partner)',
    role: 'reseller',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    balance: 4500000,
    resellerWalletBalance: 8250000,
    resellerTier: 'gold',
    resellerStatus: 'approved',
    resellerDiscountPercent: 20,
    resellerNote: 'Đại lý phân phối cấp 1 khu vực miền Bắc - Doanh số > 50tr/tháng',
    isLocked: false,
    createdAt: '2026-01-15T00:00:00.000Z',
    phone: '0912345678',
    telegram: '@hoangnam_reseller',
  },
  {
    id: 'user_customer',
    email: 'customer@gmail.com',
    name: 'Minh Trí (Khách hàng VIP)',
    role: 'user',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    balance: 1850000,
    resellerWalletBalance: 0,
    resellerStatus: 'none',
    isLocked: false,
    createdAt: '2026-02-01T00:00:00.000Z',
    phone: '0909123456',
    telegram: '@minhtri_mmo',
  },
];

// Seed Tools
const SEED_TOOLS: ToolItem[] = [
  {
    id: 'tool_tiktok_auto_pro',
    slug: 'tiktok-automation-pro-master',
    name: 'TikTok Automation Pro Master',
    tagline: 'Nuôi tài khoản TikTok triệu view, Reup video tự động lách bản quyền & Auto Livestream 24/7',
    description: 'Phần mềm nuôi tài khoản và tự động hóa TikTok số 1 hiện nay. Tích hợp công nghệ chống Checkpoint, thay đổi vân tay trình duyệt (Anti-detect Browser), tự động lướt For You Page, thả tim, follow tệp mục tiêu, cào video Douyin không logo và render lách mã hash độc quyền bằng AI.',
    features: [
      'Nuôi hàng ngàn tài khoản TikTok cùng lúc với Proxy xoay IP và Giả lập vân tay thiết bị',
      'Tự động tải video Douyin/TikTok/Kuaishou không logo HD 4K hàng loạt',
      'Bộ lọc AI lách âm thanh, lật khung hình, chèn hiệu ứng mờ chống gậy bản quyền',
      'Auto Livestream lặp lại video 24/7 thu hút hàng chục nghìn mắt xem',
      'Tự động seeding comment, ghim link bio và kéo traffic về Zalo/Telegram',
      'Hỗ trợ xuất báo cáo tương tác và gửi thông báo qua Telegram Bot'
    ],
    category: 'marketing_mmo',
    version: '5.2.0',
    lastUpdated: '2026-08-15',
    downloadUrl: 'https://downloads.toolstore.pro/setup/TikTok_Auto_Pro_v5.2.exe',
    fileSize: '142 MB',
    osCompatibility: ['Windows 10 / 11 (64-bit)', 'Hỗ trợ VPS / Máy ảo'],
    requirements: ['RAM tối thiểu: 8GB (Khuyên dùng 16GB)', 'Ổ cứng SSD trống 5GB', '.NET Framework 4.8+'],
    tutorialUrl: 'https://wiki.toolstore.pro/tiktok-pro-guide',
    videoDemoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    images: [
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_tiktok_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng',
        durationDays: 30,
        originalPrice: 450000,
        salePrice: 350000,
        resellerPrice: 280000,
        badge: 'Trải nghiệm'
      },
      {
        id: 'plan_tiktok_3m',
        duration: '3_months',
        name: 'Gói 3 Tháng',
        durationDays: 90,
        originalPrice: 1200000,
        salePrice: 850000,
        resellerPrice: 680000,
        badge: 'Khuyên Dùng'
      },
      {
        id: 'plan_tiktok_1y',
        duration: '1_year',
        name: 'Gói 1 Năm',
        durationDays: 365,
        originalPrice: 3800000,
        salePrice: 2450000,
        resellerPrice: 1960000,
        badge: 'Tiết Kiệm 45%'
      },
      {
        id: 'plan_tiktok_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn (Lifetime)',
        durationDays: 99999,
        originalPrice: 7500000,
        salePrice: 4990000,
        resellerPrice: 3990000,
        badge: 'VIP Trọn Đời'
      }
    ],
    tags: ['Hot', 'Best Seller', 'Chống Checkpoint', 'Auto 24/7'],
    rating: 4.9,
    reviewCount: 328,
    totalSold: 1420,
    isActive: true,
    warningStockThreshold: 5
  },
  {
    id: 'tool_fb_growth_master',
    slug: 'facebook-all-in-one-growth-master',
    name: 'Facebook All-in-One Growth Master',
    tagline: 'Phần mềm nuôi nick Facebook, tương tác Group, gửi tin nhắn tự động & Quét Data khách hàng',
    description: 'Hệ thống tự động hóa Facebook đỉnh cao. Tích hợp Chromium Anti-detect độc lập cho mỗi profile, tự động kết bạn theo UID/Page/Group, chia sẻ bài viết hàng loạt không bị spam, nhắn tin tự động chăm sóc khách hàng và lọc tệp số điện thoại tiềm năng.',
    features: [
      'Quản lý 5,000+ tài khoản Facebook trên 1 máy tính với phân bổ Proxy riêng biệt',
      'Tự động đăng bài vào hàng nghìn Group mục tiêu kèm hình ảnh/video',
      'Cào UID thành viên mới tham gia nhóm, tương tác bài viết đối thủ',
      'Auto gửi tin nhắn Messenger theo kịch bản thông minh có Spintax nội dung',
      'Tự động kháng checkpoint 282, 956 và mở khóa qua email ảo tự động',
      'Bảo vệ tài khoản với thuật toán hành vi người dùng thật (Human Touch Simulator)'
    ],
    category: 'marketing_mmo',
    version: '6.4.1',
    lastUpdated: '2026-08-18',
    downloadUrl: 'https://downloads.toolstore.pro/setup/FB_Growth_Master_v6.4.exe',
    fileSize: '168 MB',
    osCompatibility: ['Windows 10 / 11 (64-bit)', 'Windows Server 2019/2022'],
    requirements: ['RAM 8GB trở lên', 'CPU i5 / Ryzen 5 trở lên', 'Kết nối Internet ổn định'],
    tutorialUrl: 'https://wiki.toolstore.pro/fb-master-guide',
    images: [
      'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_fb_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng',
        durationDays: 30,
        originalPrice: 500000,
        salePrice: 390000,
        resellerPrice: 310000,
      },
      {
        id: 'plan_fb_3m',
        duration: '3_months',
        name: 'Gói 3 Tháng',
        durationDays: 90,
        originalPrice: 1400000,
        salePrice: 990000,
        resellerPrice: 790000,
        badge: 'Phổ biến'
      },
      {
        id: 'plan_fb_1y',
        duration: '1_year',
        name: 'Gói 1 Năm',
        durationDays: 365,
        originalPrice: 4200000,
        salePrice: 2800000,
        resellerPrice: 2240000,
        badge: 'Tiết kiệm'
      },
      {
        id: 'plan_fb_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn',
        durationDays: 99999,
        originalPrice: 8000000,
        salePrice: 5500000,
        resellerPrice: 4400000,
        badge: 'Trọn đời'
      }
    ],
    tags: ['Best Seller', 'Nuôi Nick Đỉnh Cao', 'Anti-Checkpoint'],
    rating: 4.8,
    reviewCount: 254,
    totalSold: 1180,
    isActive: true,
    warningStockThreshold: 4
  },
  {
    id: 'tool_shopee_flash_sniper',
    slug: 'shopee-lazada-auto-flash-sniper',
    name: 'Shopee & Lazada Auto Flash Sniper Bot',
    tagline: 'Săn Deal 1K, Tự Động Giật Mã Giảm Giá 0.01 Giây & Đặt Hàng Tốc Độ Ánh Sáng',
    description: 'Công cụ săn mã giảm giá và đặt hàng tự động nhanh nhất sàn TMĐT. Sử dụng giao thức socket TCP/HTTP2 trực tiếp qua API Shopee/Lazada, bỏ qua giao diện web giúp tốc độ hoàn thành đơn hàng chỉ từ 0.02 giây vào đúng 00:00:00.',
    features: [
      'Tự động lưu mã giảm giá, mã freeship, voucher KOL đúng mili-giây mở bán',
      'Tự động chọn size, áp voucher tốt nhất và click thanh toán siêu tốc 0.01s',
      'Hỗ trợ săn hàng ngàn tài khoản cùng lúc qua multi-threading',
      'Tích hợp giải Captcha hình ảnh và trượt thanh trượt tự động bằng AI Vision',
      'Hỗ trợ thanh toán qua Ví ShopeePay, Thẻ Tín Dụng, COD không bị hủy đơn'
    ],
    category: 'automation',
    version: '3.8.4',
    lastUpdated: '2026-08-10',
    downloadUrl: 'https://downloads.toolstore.pro/setup/Shopee_Sniper_v3.8.zip',
    fileSize: '45 MB',
    osCompatibility: ['Windows 10 / 11', 'macOS (M1/M2/Intel)'],
    requirements: ['Mạng cáp quang Ping < 10ms', 'RAM 4GB'],
    images: [
      'https://images.unsplash.com/photo-1556742049-0a67c55768ac?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_shopee_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng',
        durationDays: 30,
        originalPrice: 350000,
        salePrice: 250000,
        resellerPrice: 190000,
      },
      {
        id: 'plan_shopee_1y',
        duration: '1_year',
        name: 'Gói 1 Năm',
        durationDays: 365,
        originalPrice: 2200000,
        salePrice: 1490000,
        resellerPrice: 1190000,
        badge: 'Ưu Đãi'
      },
      {
        id: 'plan_shopee_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn',
        durationDays: 99999,
        originalPrice: 4500000,
        salePrice: 2990000,
        resellerPrice: 2390000,
        badge: 'VIP'
      }
    ],
    tags: ['Hot', 'Tốc Độ 0.01s', 'Giải Captcha AI'],
    rating: 4.9,
    reviewCount: 412,
    totalSold: 1890,
    isActive: true,
    warningStockThreshold: 8
  },
  {
    id: 'tool_ai_video_automation',
    slug: 'ai-video-content-generator-pro',
    name: 'AI Video Content Generator & CapCut Bot',
    tagline: 'Sản xuất 100+ Video Shorts/Reels/TikTok chuẩn SEO tự động mỗi ngày bằng Trí Tuệ Nhân Tạo',
    description: 'Biến ý tưởng hoặc bài viết thành hàng trăm video ngắn hoàn chỉnh trong vài phút. Tự động viết kịch bản bằng Gemini AI, tổng hợp giọng đọc AI lồng tiếng tiếng Việt cảm xúc, tự cắt ghép kho footage 4K và chèn phụ đề hiệu ứng chữ động (Word-by-word) trên CapCut.',
    features: [
      'Nhập 1 chủ đề - Tự động tạo 50 kịch bản video Shorts/TikTok viral',
      'Giọng đọc AI thuyết minh siêu thực (Bắc / Trung / Nam) không bị méo tiếng',
      'Tự động chọn stock footage HD khớp từng câu chữ của kịch bản',
      'Tự động chèn phụ đề animated nhảy chữ đổi màu phong cách Alex Hormozi',
      'Tự động xuất file và đăng tải thẳng lên kênh YouTube Shorts, TikTok, FB Reels'
    ],
    category: 'ai_data',
    version: '4.1.2',
    lastUpdated: '2026-08-19',
    downloadUrl: 'https://downloads.toolstore.pro/setup/AIVideo_Generator_v4.1.exe',
    fileSize: '210 MB',
    osCompatibility: ['Windows 10 / 11 (64-bit)', 'macOS Sonoma+'],
    requirements: ['GPU rời tối thiểu 4GB VRAM để render nhanh', 'RAM 16GB'],
    images: [
      'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_aivideo_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng',
        durationDays: 30,
        originalPrice: 600000,
        salePrice: 450000,
        resellerPrice: 350000,
      },
      {
        id: 'plan_aivideo_3m',
        duration: '3_months',
        name: 'Gói 3 Tháng',
        durationDays: 90,
        originalPrice: 1600000,
        salePrice: 1150000,
        resellerPrice: 900000,
        badge: 'Khuyên Dùng'
      },
      {
        id: 'plan_aivideo_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn',
        durationDays: 99999,
        originalPrice: 9500000,
        salePrice: 6200000,
        resellerPrice: 4900000,
        badge: 'Độc Quyền AI'
      }
    ],
    tags: ['AI Đỉnh Cao', 'Xuất 100 Video/Ngày', 'Voice Việt AI'],
    rating: 5.0,
    reviewCount: 198,
    totalSold: 840,
    isActive: true,
    warningStockThreshold: 3
  },
  {
    id: 'tool_telegram_mass_dm',
    slug: 'telegram-scraper-and-mass-dm-pro',
    name: 'Telegram Scraper & Mass DM Turbo Pro',
    tagline: 'Cào thành viên nhóm đối thủ, lọc người online & Kéo Member vào Group/Channel tự động',
    description: 'Vũ khí tiếp cận khách hàng tiềm năng cho dự án Crypto, Forex, Game và MMO. Quét sạch thành viên hoạt động của bất kỳ nhóm Telegram nào (kể cả nhóm ẩn thành viên), tự động gửi tin nhắn kèm hình ảnh/nút bấm và thêm mem vào nhóm của bạn với tốc độ cực cao.',
    features: [
      'Cào 100,000 thành viên nhóm công khai & kín trong chưa đầy 5 phút',
      'Lọc tệp chính xác: Người dùng online trong 1 ngày, 3 ngày, có ảnh đại diện',
      'Auto Add Member vào Group/Channel riêng của bạn không bị gắn cờ',
      'Auto DM Mass tin nhắn riêng tư với hệ thống đa phiên đăng nhập (Multi-Session)',
      'Tích hợp bảo vệ Session chống ban số điện thoại bằng delay ngẫu nhiên'
    ],
    category: 'marketing_mmo',
    version: '7.0.0',
    lastUpdated: '2026-08-12',
    downloadUrl: 'https://downloads.toolstore.pro/setup/Telegram_Turbo_v7.0.zip',
    fileSize: '38 MB',
    osCompatibility: ['Windows', 'macOS', 'Linux Server'],
    requirements: ['Hỗ trợ Session / Tdata Telegram', 'Proxy HTTP/SOCKS5'],
    images: [
      'https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_tele_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng',
        durationDays: 30,
        originalPrice: 400000,
        salePrice: 290000,
        resellerPrice: 220000,
      },
      {
        id: 'plan_tele_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn',
        durationDays: 99999,
        originalPrice: 5000000,
        salePrice: 3200000,
        resellerPrice: 2500000,
        badge: 'Ưu Đãi Đặc Biệt'
      }
    ],
    tags: ['MMO Crypto', 'Quét Nhóm Ẩn', 'Kéo Mem Cực Nhanh'],
    rating: 4.8,
    reviewCount: 167,
    totalSold: 720,
    isActive: true,
    warningStockThreshold: 5
  },
  {
    id: 'tool_crypto_dex_sniper',
    slug: 'crypto-dex-solana-bsc-sniper-bot',
    name: 'Crypto DEX Sniper & MEV Arbitrage Bot',
    tagline: 'Bắt thanh khoản Raydium, Uniswap, PancakeSwap cực nhanh - Chống Rugpull & HoneyPot',
    description: 'Bot bắn token sàn phi tập trung tốc độ mili-giây. Tự động soi mempool, phát hiện thanh khoản mới mở, kiểm tra smart contract chống Honeypot, tự tính toán Slippage và thực hiện lệnh Mua/Bán trước các bot khác.',
    features: [
      'Hỗ trợ mạng Solana (Raydium, Pump.fun), BSC, Ethereum, Base, Arbitrum',
      'Tự động quét và mua ngay khi dev add pool thanh khoản',
      'Tự động chốt lời TP / cắt lỗ SL theo trailing stop-loss thông minh',
      'Tích hợp MEV Protection qua Jito & Flashbots tránh bị front-run kẹp sandwich',
      'Quản lý danh mục 20 ví cùng lúc với tính năng Copy Trading chuyên gia'
    ],
    category: 'automation',
    version: '3.2.1',
    lastUpdated: '2026-08-17',
    downloadUrl: 'https://downloads.toolstore.pro/setup/CryptoSniper_Pro_v3.2.exe',
    fileSize: '88 MB',
    osCompatibility: ['Windows 10 / 11', 'Ubuntu Linux VPS'],
    requirements: ['RPC Node riêng hoặc Helius / QuickNode URL', 'RAM 4GB'],
    images: [
      'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_crypto_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng',
        durationDays: 30,
        originalPrice: 1500000,
        salePrice: 990000,
        resellerPrice: 790000,
      },
      {
        id: 'plan_crypto_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn',
        durationDays: 99999,
        originalPrice: 15000000,
        salePrice: 8900000,
        resellerPrice: 7100000,
        badge: 'Chuyên Gia'
      }
    ],
    tags: ['Solana Pump.fun', 'Raydium Sniper', 'MEV Protected'],
    rating: 4.9,
    reviewCount: 142,
    totalSold: 490,
    isActive: true,
    warningStockThreshold: 3
  },
  {
    id: 'tool_google_seo_backlink_bot',
    slug: 'google-seo-auto-backlink-indexer',
    name: 'Google SEO Auto Backlink & Indexer Ultra',
    tagline: 'Ép Google Index bài viết sau 5 phút, bắn 500+ Backlink Profile & Web 2.0 chất lượng cao',
    description: 'Giải pháp SEO website tự động hóa toàn diện. Sử dụng Google Indexing API chính thống đẩy URL lên bảng xếp hạng ngay lập tức, tự động viết bài chuẩn SEO bằng AI và đăng lên mạng lưới Blog Web 2.0 vệ tinh.',
    features: [
      'Google Indexing API Batch: Ép index 2,000 URL mỗi ngày chỉ với 1 click',
      'Tự động tạo tài khoản và đặt backlink trên 500+ diễn đàn uy tín DA > 50',
      'Spin nội dung thông minh bằng AI đa ngôn ngữ không lo trùng lặp bài viết',
      'Theo dõi thứ hạng từ khóa (Rank Tracker) tự động mỗi ngày'
    ],
    category: 'seo_traffic',
    version: '4.8.0',
    lastUpdated: '2026-08-14',
    downloadUrl: 'https://downloads.toolstore.pro/setup/SEO_Indexer_v4.8.zip',
    fileSize: '54 MB',
    osCompatibility: ['Windows 10 / 11', 'macOS'],
    requirements: ['Tài khoản Google Cloud Console (miễn phí)'],
    images: [
      'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_seo_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng',
        durationDays: 30,
        originalPrice: 350000,
        salePrice: 280000,
        resellerPrice: 210000,
      },
      {
        id: 'plan_seo_1y',
        duration: '1_year',
        name: 'Gói 1 Năm',
        durationDays: 365,
        originalPrice: 2500000,
        salePrice: 1690000,
        resellerPrice: 1350000,
        badge: 'Ưa chuộng'
      },
      {
        id: 'plan_seo_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn',
        durationDays: 99999,
        originalPrice: 5500000,
        salePrice: 3490000,
        resellerPrice: 2790000,
        badge: 'VIP SEO'
      }
    ],
    tags: ['Ép Index 5 Phút', 'Tự Động 100%', 'Tăng Traffic'],
    rating: 4.7,
    reviewCount: 96,
    totalSold: 360,
    isActive: true,
    warningStockThreshold: 4
  },
  {
    id: 'tool_antidetect_browser_creator',
    slug: 'gologin-antidetect-multilogin-creator',
    name: 'Anti-Detect Browser Cluster Manager',
    tagline: 'Tạo hàng vạn Profile trình duyệt sạch, vượt Cloudflare, Canvas, WebGL & Audio Fingerprint',
    description: 'Công cụ tạo và quản trị cụm trình duyệt độc lập. Mỗi profile có vân tay máy tính hoàn toàn khác biệt từ CPU, RAM, Card màn hình đến Font chữ và WebGL. Phục vụ nuôi tài khoản Ads, eBay, Amazon, Crypto và Airdrop.',
    features: [
      'Tạo 10,000 profile trình duyệt độc lập với vân tay hệ điều hành Windows/Mac/Linux/Android',
      'Đồng bộ dữ liệu Cookie, LocalStorage và tiện ích mở rộng Extension mượt mà',
      'Tích hợp sẵn bộ tự động hóa kịch bản Puppeteer / Playwright không cần biết lập trình',
      'Gán Proxy tĩnh / xoay tự động cho từng Profile chỉ với 1 thao tác kéo thả'
    ],
    category: 'developer',
    version: '2.5.0',
    lastUpdated: '2026-08-16',
    downloadUrl: 'https://downloads.toolstore.pro/setup/AntiDetect_Cluster_v2.5.exe',
    fileSize: '195 MB',
    osCompatibility: ['Windows 10 / 11 (64-bit)', 'macOS (Apple Silicon & Intel)'],
    requirements: ['RAM 8GB tối thiểu'],
    images: [
      'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80'
    ],
    plans: [
      {
        id: 'plan_antidetect_1m',
        duration: '1_month',
        name: 'Gói 1 Tháng (100 Profile)',
        durationDays: 30,
        originalPrice: 400000,
        salePrice: 299000,
        resellerPrice: 230000,
      },
      {
        id: 'plan_antidetect_1y',
        duration: '1_year',
        name: 'Gói 1 Năm (Không giới hạn)',
        durationDays: 365,
        originalPrice: 3200000,
        salePrice: 1990000,
        resellerPrice: 1590000,
        badge: 'Siêu Hời'
      },
      {
        id: 'plan_antidetect_lifetime',
        duration: 'lifetime',
        name: 'Gói Vĩnh Viễn (Full Tính Năng)',
        durationDays: 99999,
        originalPrice: 7000000,
        salePrice: 4200000,
        resellerPrice: 3360000,
        badge: 'VIP Không Giới Hạn'
      }
    ],
    tags: ['Vượt Cloudflare', 'Chống Phát Hiện', 'Không Giới Hạn Profile'],
    rating: 4.9,
    reviewCount: 185,
    totalSold: 910,
    isActive: true,
    warningStockThreshold: 5
  }
];

// Helper to generate realistic seed keys for each tool
function generateSeedKeys(): LicenseKeyRecord[] {
  const keys: LicenseKeyRecord[] = [];
  SEED_TOOLS.forEach((tool) => {
    tool.plans.forEach((plan) => {
      // 10 available keys per plan
      for (let i = 1; i <= 10; i++) {
        const randHex = Math.random().toString(36).substring(2, 6).toUpperCase() + '-' +
                        Math.random().toString(36).substring(2, 6).toUpperCase() + '-' +
                        Math.random().toString(36).substring(2, 6).toUpperCase() + '-' +
                        Math.random().toString(36).substring(2, 6).toUpperCase();
        const prefix = tool.slug.split('-')[0].toUpperCase();
        const keyString = `${prefix}-${plan.duration.toUpperCase()}-${randHex}`;
        keys.push({
          id: `key_${tool.id}_${plan.id}_${i}`,
          toolId: tool.id,
          planId: plan.id,
          keyCode: keyString,
          status: 'available',
          createdAt: new Date(Date.now() - i * 86400000).toISOString(),
          maxHwidResets: 3,
          hwidResetCount: 0,
        });
      }
    });
  });
  return keys;
}

// Seed Initial Purchased Licenses for Customer demo
const SEED_PURCHASED_LICENSES: PurchasedLicense[] = [
  {
    id: 'lic_001',
    orderId: 'ORD-89213',
    userId: 'user_customer',
    userEmail: 'customer@gmail.com',
    toolId: 'tool_tiktok_auto_pro',
    toolName: 'TikTok Automation Pro Master',
    toolIcon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=150&auto=format&fit=crop&q=80',
    planName: 'Gói 1 Năm',
    durationDays: 365,
    keyCode: 'TIKTOK-1_YEAR-A9F2-4KC8-89Z1-XP29',
    downloadUrl: 'https://downloads.toolstore.pro/setup/TikTok_Auto_Pro_v5.2.exe',
    version: '5.2.0',
    pricePaid: 2450000,
    purchasedAt: '2026-08-01T10:30:00.000Z',
    expiresAt: '2027-08-01T10:30:00.000Z',
    status: 'active',
    hwid: 'HWID-WIN11-B78A-9812-CC89',
    hwidResetsRemaining: 3,
    notes: 'Kích hoạt thành công trên máy chính',
  },
  {
    id: 'lic_002',
    orderId: 'ORD-84521',
    userId: 'user_customer',
    userEmail: 'customer@gmail.com',
    toolId: 'tool_shopee_flash_sniper',
    toolName: 'Shopee & Lazada Auto Flash Sniper Bot',
    toolIcon: 'https://images.unsplash.com/photo-1556742049-0a67c55768ac?w=150&auto=format&fit=crop&q=80',
    planName: 'Gói Vĩnh Viễn (Lifetime)',
    durationDays: 99999,
    keyCode: 'SHOPEE-LIFETIME-GOLD-77AF-901B-44CC-8899',
    downloadUrl: 'https://downloads.toolstore.pro/setup/Shopee_Sniper_v3.8.zip',
    version: '3.8.4',
    pricePaid: 2990000,
    purchasedAt: '2026-07-20T14:15:00.000Z',
    expiresAt: 'Lifetime',
    status: 'active',
    hwid: 'HWID-WIN11-B78A-9812-CC89',
    hwidResetsRemaining: 2,
    notes: 'Gói vĩnh viễn không giới hạn',
  }
];

// Seed Transactions
const SEED_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx_001',
    code: 'TX98231',
    userId: 'user_customer',
    userName: 'Minh Trí',
    userEmail: 'customer@gmail.com',
    type: 'deposit',
    amount: 5000000,
    balanceBefore: 0,
    balanceAfter: 5000000,
    paymentMethod: 'vietqr',
    status: 'completed',
    description: 'Nạp tiền vào ví qua VietQR tự động (MBBank 888899998888)',
    createdAt: '2026-07-20T14:10:00.000Z',
  },
  {
    id: 'tx_002',
    code: 'TX98232',
    userId: 'user_customer',
    userName: 'Minh Trí',
    userEmail: 'customer@gmail.com',
    type: 'purchase',
    amount: -2990000,
    balanceBefore: 5000000,
    balanceAfter: 2010000,
    paymentMethod: 'wallet',
    status: 'completed',
    description: 'Mua bản quyền Shopee & Lazada Auto Flash Sniper Bot (Gói Vĩnh Viễn)',
    createdAt: '2026-07-20T14:15:00.000Z',
    metadata: {
      toolId: 'tool_shopee_flash_sniper',
      toolName: 'Shopee & Lazada Auto Flash Sniper Bot',
      keyCount: 1,
    }
  },
  {
    id: 'tx_003',
    code: 'TX98233',
    userId: 'user_customer',
    userName: 'Minh Trí',
    userEmail: 'customer@gmail.com',
    type: 'deposit',
    amount: 2290000,
    balanceBefore: 2010000,
    balanceAfter: 4300000,
    paymentMethod: 'vietqr',
    status: 'completed',
    description: 'Nạp tiền tài khoản qua VietQR',
    createdAt: '2026-08-01T10:25:00.000Z',
  },
  {
    id: 'tx_004',
    code: 'TX98234',
    userId: 'user_customer',
    userName: 'Minh Trí',
    userEmail: 'customer@gmail.com',
    type: 'purchase',
    amount: -2450000,
    balanceBefore: 4300000,
    balanceAfter: 1850000,
    paymentMethod: 'wallet',
    status: 'completed',
    description: 'Mua bản quyền TikTok Automation Pro Master (Gói 1 Năm)',
    createdAt: '2026-08-01T10:30:00.000Z',
    metadata: {
      toolId: 'tool_tiktok_auto_pro',
      toolName: 'TikTok Automation Pro Master',
      keyCount: 1,
    }
  },
  {
    id: 'tx_005',
    code: 'TX98235',
    userId: 'user_reseller_gold',
    userName: 'Đại Lý Hoàng Nam',
    userEmail: 'reseller.gold@toolstore.pro',
    type: 'reseller_commission',
    amount: 490000,
    balanceBefore: 7760000,
    balanceAfter: 8250000,
    paymentMethod: 'wallet',
    status: 'completed',
    description: 'Hoa hồng 20% từ đơn hàng khách phụ tuyến bán Tool TikTok Master',
    createdAt: '2026-08-18T16:20:00.000Z',
  }
];

// Seed Reviews
const SEED_REVIEWS: Review[] = [
  {
    id: 'rev_001',
    toolId: 'tool_tiktok_auto_pro',
    userId: 'user_098',
    userName: 'Nguyễn Tiến Đạt (MMO)',
    rating: 5,
    comment: 'Tool mượt vô cùng, mình nuôi hơn 300 nick TikTok chạy 24/24 không bị quét checkpoint một nick nào. Cảm ơn admin hỗ trợ nhiệt tình!',
    createdAt: '2026-08-12T09:00:00.000Z',
    isVerifiedBuyer: true,
  },
  {
    id: 'rev_002',
    toolId: 'tool_tiktok_auto_pro',
    userId: 'user_102',
    userName: 'Lê Văn Tuấn',
    rating: 5,
    comment: 'Hệ thống xuất key tức thì sau khi quét VietQR 3 giây. Đã reup video và lên xu hướng ngay ngày đầu tiên!',
    createdAt: '2026-08-14T15:30:00.000Z',
    isVerifiedBuyer: true,
  },
  {
    id: 'rev_003',
    toolId: 'tool_shopee_flash_sniper',
    userId: 'user_105',
    userName: 'Phạm Thu Trang',
    rating: 5,
    comment: 'Săn deal 0h siêu dính! Vừa giật được voucher 500k của Shopee. Quá xứng đáng đồng tiền bát gạo.',
    createdAt: '2026-08-10T00:05:00.000Z',
    isVerifiedBuyer: true,
  },
  {
    id: 'rev_004',
    toolId: 'tool_ai_video_automation',
    userId: 'user_110',
    userName: 'Hoàng Anh Studio',
    rating: 5,
    comment: '1 ngày render tự động 80 video CapCut tiếng Việt giọng đọc rất tự nhiên. Kênh TikTok của mình đã đạt 100k follow sau 2 tuần.',
    createdAt: '2026-08-17T20:10:00.000Z',
    isVerifiedBuyer: true,
  }
];

// Seed Reseller Withdrawal Requests
const SEED_WITHDRAWALS: WithdrawalRequest[] = [
  {
    id: 'wdr_001',
    resellerId: 'user_reseller_gold',
    resellerName: 'Đại Lý Hoàng Nam',
    resellerEmail: 'reseller.gold@toolstore.pro',
    amount: 3000000,
    bankName: 'Techcombank',
    bankAccount: '19034567890123',
    bankAccountName: 'HOANG NAM',
    status: 'approved',
    createdAt: '2026-08-10T08:00:00.000Z',
    processedAt: '2026-08-10T09:15:00.000Z',
    adminNote: 'Đã chuyển khoản thành công kèm biên lai UNC',
  },
  {
    id: 'wdr_002',
    resellerId: 'user_reseller_gold',
    resellerName: 'Đại Lý Hoàng Nam',
    resellerEmail: 'reseller.gold@toolstore.pro',
    amount: 2500000,
    bankName: 'Techcombank',
    bankAccount: '19034567890123',
    bankAccountName: 'HOANG NAM',
    status: 'pending',
    createdAt: '2026-08-19T14:00:00.000Z',
  }
];

// Seed Notifications
const SEED_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_001',
    userId: 'user_customer',
    title: 'Thanh toán & Nhận Key thành công',
    message: 'Bạn đã mua thành công TikTok Automation Pro Master (1 Năm). Key bản quyền đã được thêm vào Kho Key của bạn.',
    type: 'key',
    isRead: false,
    createdAt: '2026-08-01T10:30:00.000Z',
  },
  {
    id: 'notif_002',
    userId: 'user_customer',
    title: 'Cập nhật phiên bản mới v5.2.0',
    message: 'Tool TikTok Automation vừa được update thuật toán chống Checkpoint mới nhất. Vui lòng tải lại bản cài đặt.',
    type: 'system',
    isRead: true,
    createdAt: '2026-08-15T09:00:00.000Z',
  },
  {
    id: 'notif_003',
    userId: 'user_reseller_gold',
    title: 'Cộng hoa hồng đại lý +490.000 ₫',
    message: 'Khách hàng tuyến của bạn vừa hoàn tất đơn hàng bản quyền. Số dư ví đại lý đã được cộng tức thì.',
    type: 'reseller',
    isRead: false,
    createdAt: '2026-08-18T16:20:00.000Z',
  }
];

// In-memory / LocalStorage Database Service
class StorageService {
  constructor() {
    this.init();
  }

  private init() {
    if (typeof window === 'undefined') return;

    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(SEED_USERS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID)) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, 'user_customer');
    }
    if (!localStorage.getItem(STORAGE_KEYS.TOOLS)) {
      localStorage.setItem(STORAGE_KEYS.TOOLS, JSON.stringify(SEED_TOOLS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.KEY_VAULT)) {
      localStorage.setItem(STORAGE_KEYS.KEY_VAULT, JSON.stringify(generateSeedKeys()));
    }
    if (!localStorage.getItem(STORAGE_KEYS.PURCHASED_LICENSES)) {
      localStorage.setItem(STORAGE_KEYS.PURCHASED_LICENSES, JSON.stringify(SEED_PURCHASED_LICENSES));
    }
    if (!localStorage.getItem(STORAGE_KEYS.TRANSACTIONS)) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(SEED_TRANSACTIONS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.WITHDRAWALS)) {
      localStorage.setItem(STORAGE_KEYS.WITHDRAWALS, JSON.stringify(SEED_WITHDRAWALS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.REVIEWS)) {
      localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(SEED_REVIEWS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.SYSTEM_SETTINGS)) {
      localStorage.setItem(STORAGE_KEYS.SYSTEM_SETTINGS, JSON.stringify(DEFAULT_SYSTEM_SETTINGS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(SEED_NOTIFICATIONS));
    }
  }

  // Generic Get/Set
  private get<T>(key: string, fallback: T): T {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : fallback;
    } catch {
      return fallback;
    }
  }

  private set<T>(key: string, data: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      window.dispatchEvent(new Event('toolstore_storage_update'));
    } catch (e) {
      console.error('Storage set error:', e);
    }
  }

  // --- Users & Auth ---
  getUsers(): User[] {
    return this.get<User[]>(STORAGE_KEYS.USERS, SEED_USERS);
  }

  getUserById(id: string): User | undefined {
    return this.getUsers().find((u) => u.id === id);
  }

  getCurrentUser(): User {
    const currentId = localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID) || 'user_customer';
    const user = this.getUserById(currentId);
    return user || SEED_USERS[2];
  }

  setCurrentUser(userId: string): User | null {
    const user = this.getUserById(userId);
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, userId);
      window.dispatchEvent(new Event('toolstore_storage_update'));
      return user;
    }
    return null;
  }

  updateUser(user: User): void {
    const users = this.getUsers().map((u) => (u.id === user.id ? user : u));
    this.set(STORAGE_KEYS.USERS, users);
  }

  registerUser(name: string, email: string, role: 'user' | 'reseller' = 'user'): User {
    const users = this.getUsers();
    const existing = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      throw new Error('Email này đã được đăng ký trong hệ thống!');
    }

    const newUser: User = {
      id: `user_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      email,
      name,
      role,
      balance: 0,
      resellerWalletBalance: 0,
      resellerStatus: role === 'reseller' ? 'pending' : 'none',
      resellerTier: role === 'reseller' ? 'silver' : undefined,
      resellerDiscountPercent: role === 'reseller' ? 10 : 0,
      isLocked: false,
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    this.set(STORAGE_KEYS.USERS, users);
    this.setCurrentUser(newUser.id);
    return newUser;
  }

  loginUser(email: string): User {
    const users = this.getUsers();
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      throw new Error('Không tìm thấy tài khoản với email này!');
    }
    if (user.isLocked) {
      throw new Error('Tài khoản này hiện đang bị tạm khóa. Vui lòng liên hệ Admin!');
    }
    this.setCurrentUser(user.id);
    return user;
  }

  // --- Tools ---
  getTools(): ToolItem[] {
    return this.get<ToolItem[]>(STORAGE_KEYS.TOOLS, SEED_TOOLS);
  }

  getToolById(id: string): ToolItem | undefined {
    return this.getTools().find((t) => t.id === id);
  }

  saveTool(tool: ToolItem): void {
    const tools = this.getTools();
    const idx = tools.findIndex((t) => t.id === tool.id);
    if (idx >= 0) {
      tools[idx] = tool;
    } else {
      tools.unshift(tool);
    }
    this.set(STORAGE_KEYS.TOOLS, tools);
  }

  deleteTool(id: string): void {
    const tools = this.getTools().filter((t) => t.id !== id);
    this.set(STORAGE_KEYS.TOOLS, tools);
  }

  // --- Key Vault & Inventory ---
  getKeyVault(): LicenseKeyRecord[] {
    return this.get<LicenseKeyRecord[]>(STORAGE_KEYS.KEY_VAULT, []);
  }

  getAvailableKeyCount(toolId: string, planId?: string): number {
    const vault = this.getKeyVault();
    return vault.filter((k) => k.toolId === toolId && (!planId || k.planId === planId) && k.status === 'available').length;
  }

  addBulkKeys(toolId: string, planId: string, rawKeysText: string, notes?: string): number {
    const lines = rawKeysText
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    if (lines.length === 0) return 0;

    const vault = this.getKeyVault();
    let count = 0;
    lines.forEach((line) => {
      // Avoid duplicate active keys
      if (!vault.some((k) => k.keyCode === line && k.status === 'available')) {
        vault.push({
          id: `key_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          toolId,
          planId,
          keyCode: line,
          status: 'available',
          createdAt: new Date().toISOString(),
          maxHwidResets: 3,
          hwidResetCount: 0,
          notes: notes || 'Import thủ công bởi Admin',
        });
        count++;
      }
    });

    this.set(STORAGE_KEYS.KEY_VAULT, vault);
    return count;
  }

  deleteKey(keyId: string): void {
    const vault = this.getKeyVault().filter((k) => k.id !== keyId);
    this.set(STORAGE_KEYS.KEY_VAULT, vault);
  }

  revokeKey(keyId: string): void {
    const vault = this.getKeyVault().map((k) => (k.id === keyId ? { ...k, status: 'revoked' as const } : k));
    this.set(STORAGE_KEYS.KEY_VAULT, vault);
  }

  // --- Atomic Purchase & License Dispatch ---
  purchaseItems(params: {
    userId: string;
    items: CartItem[];
    paymentMethod: 'wallet' | 'vietqr' | 'momo' | 'banking';
    resellerId?: string;
    customCustomerName?: string;
  }): { success: boolean; licenses: PurchasedLicense[]; orderId: string; totalAmount: number } {
    const { userId, items, paymentMethod, resellerId } = params;
    const user = this.getUserById(userId);
    if (!user) throw new Error('Người dùng không tồn tại!');

    const vault = this.getKeyVault();
    const tools = this.getTools();
    const purchasedLicenses = this.getPurchasedLicenses();
    const transactions = this.getTransactions();

    // 1. Calculate total price and verify stock
    let totalAmount = 0;
    for (const item of items) {
      const plan = item.tool.plans.find((p) => p.id === item.plan.id);
      if (!plan) throw new Error(`Gói bản quyền không hợp lệ cho tool ${item.tool.name}`);

      // Apply reseller wholesale price if user is reseller
      let unitPrice = plan.salePrice;
      if (user.role === 'reseller' && user.resellerStatus === 'approved') {
        const discountPct = user.resellerDiscountPercent || 15;
        unitPrice = Math.round(plan.salePrice * (1 - discountPct / 100));
      }

      totalAmount += unitPrice * item.quantity;

      // Check available stock in vault
      const availableKeys = vault.filter(
        (k) => k.toolId === item.tool.id && k.planId === item.plan.id && k.status === 'available'
      );
      if (availableKeys.length < item.quantity) {
        throw new Error(
          `Kho key của "${item.tool.name}" (${plan.name}) hiện chỉ còn ${availableKeys.length} key, không đủ ${item.quantity} key yêu cầu!`
        );
      }
    }

    // 2. Check wallet balance if payment method is wallet
    if (paymentMethod === 'wallet') {
      if (user.balance < totalAmount) {
        throw new Error(
          `Số dư ví không đủ! Cần: ${totalAmount.toLocaleString('vi-VN')} ₫, Hiện có: ${user.balance.toLocaleString('vi-VN')} ₫. Vui lòng nạp thêm!`
        );
      }
      // Deduct balance
      user.balance -= totalAmount;
    }

    const orderId = `ORD-${Date.now().toString().slice(-6)}`;
    const newLicenses: PurchasedLicense[] = [];

    // 3. Atomically allocate keys (FIFO)
    for (const item of items) {
      const plan = item.tool.plans.find((p) => p.id === item.plan.id)!;
      let unitPrice = plan.salePrice;
      if (user.role === 'reseller' && user.resellerStatus === 'approved') {
        const discountPct = user.resellerDiscountPercent || 15;
        unitPrice = Math.round(plan.salePrice * (1 - discountPct / 100));
      }

      for (let q = 0; q < item.quantity; q++) {
        const keyIndex = vault.findIndex(
          (k) => k.toolId === item.tool.id && k.planId === item.plan.id && k.status === 'available'
        );
        if (keyIndex === -1) {
          throw new Error(`Lỗi cấp phát key cho tool ${item.tool.name}`);
        }

        const allocatedKey = vault[keyIndex];
        allocatedKey.status = 'sold';
        allocatedKey.soldAt = new Date().toISOString();
        allocatedKey.soldToUserId = user.id;
        allocatedKey.soldToOrderId = orderId;

        // Calculate expiration date
        let expiresAt = 'Lifetime';
        if (plan.durationDays < 90000) {
          const expDate = new Date();
          expDate.setDate(expDate.getDate() + plan.durationDays);
          expiresAt = expDate.toISOString();
        }

        const newLicense: PurchasedLicense = {
          id: `lic_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          orderId,
          userId: user.id,
          userEmail: user.email,
          toolId: item.tool.id,
          toolName: item.tool.name,
          toolIcon: item.tool.images[0] || '',
          planName: plan.name,
          durationDays: plan.durationDays,
          keyCode: allocatedKey.keyCode,
          downloadUrl: item.tool.downloadUrl,
          version: item.tool.version,
          pricePaid: unitPrice,
          purchasedAt: new Date().toISOString(),
          expiresAt,
          status: 'active',
          hwidResetsRemaining: 3,
          resellerId,
        };

        newLicenses.push(newLicense);
        purchasedLicenses.unshift(newLicense);

        // Increment totalSold on tool
        const toolIdx = tools.findIndex((t) => t.id === item.tool.id);
        if (toolIdx >= 0) {
          tools[toolIdx].totalSold += 1;
        }
      }
    }

    // 4. Log Transaction
    const txCode = `TX${Math.floor(100000 + Math.random() * 900000)}`;
    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      code: txCode,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      type: 'purchase',
      amount: -totalAmount,
      balanceBefore: paymentMethod === 'wallet' ? user.balance + totalAmount : user.balance,
      balanceAfter: user.balance,
      paymentMethod,
      status: 'completed',
      description: `Mua ${items.reduce((s, i) => s + i.quantity, 0)} Key bản quyền (${items.map((i) => i.tool.name).join(', ')})`,
      createdAt: new Date().toISOString(),
      metadata: {
        toolName: items.map((i) => i.tool.name).join(', '),
        keyCount: items.reduce((s, i) => s + i.quantity, 0),
        txRef: orderId,
      },
    };
    transactions.unshift(newTx);

    // 5. If purchased via Reseller reference, credit commission
    if (resellerId && resellerId !== user.id) {
      const reseller = this.getUserById(resellerId);
      if (reseller && reseller.role === 'reseller') {
        const commissionPct = reseller.resellerDiscountPercent || 15;
        const commissionAmount = Math.round((totalAmount * commissionPct) / 100);
        reseller.resellerWalletBalance += commissionAmount;
        this.updateUser(reseller);

        // Log reseller commission tx
        transactions.unshift({
          id: `tx_comm_${Date.now()}`,
          code: `TXC${Math.floor(100000 + Math.random() * 900000)}`,
          userId: reseller.id,
          userName: reseller.name,
          userEmail: reseller.email,
          type: 'reseller_commission',
          amount: commissionAmount,
          balanceBefore: reseller.resellerWalletBalance - commissionAmount,
          balanceAfter: reseller.resellerWalletBalance,
          paymentMethod: 'wallet',
          status: 'completed',
          description: `Hoa hồng bán hàng (${commissionPct}%) từ đơn hàng ${orderId}`,
          createdAt: new Date().toISOString(),
          metadata: { txRef: orderId },
        });

        this.addNotification({
          userId: reseller.id,
          title: `Cộng hoa hồng đại lý +${commissionAmount.toLocaleString('vi-VN')} ₫`,
          message: `Khách hàng vừa mua đơn ${orderId}. Hoa hồng của bạn đã được chuyển vào ví đại lý.`,
          type: 'reseller',
        });
      }
    }

    // 6. Save all updated tables
    this.updateUser(user);
    this.set(STORAGE_KEYS.KEY_VAULT, vault);
    this.set(STORAGE_KEYS.TOOLS, tools);
    this.set(STORAGE_KEYS.PURCHASED_LICENSES, purchasedLicenses);
    this.set(STORAGE_KEYS.TRANSACTIONS, transactions);

    // 7. Add Notification for buyer
    this.addNotification({
      userId: user.id,
      title: `Thanh toán thành công đơn hàng #${orderId}`,
      message: `Hệ thống đã tự động xuất ${newLicenses.length} Key bản quyền. Bạn có thể sao chép và kích hoạt ngay.`,
      type: 'key',
    });

    return {
      success: true,
      licenses: newLicenses,
      orderId,
      totalAmount,
    };
  }

  // --- Licenses ---
  getPurchasedLicenses(userId?: string): PurchasedLicense[] {
    const list = this.get<PurchasedLicense[]>(STORAGE_KEYS.PURCHASED_LICENSES, []);
    return userId ? list.filter((l) => l.userId === userId) : list;
  }

  activateKey(params: {
    keyCode: string;
    hwid?: string;
    userId?: string;
    userEmail?: string;
  }): {
    success: boolean;
    message: string;
    license: PurchasedLicense;
    isNewClaim: boolean;
  } {
    const { keyCode, hwid, userId, userEmail } = params;
    const cleanKey = keyCode.trim();
    if (!cleanKey) {
      throw new Error('Vui lòng nhập mã Key bản quyền!');
    }

    const assignedHwid = hwid?.trim() || `HWID-WIN-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    // 1. Check in purchased licenses first
    const purchasedLicenses = this.getPurchasedLicenses();
    const existingIndex = purchasedLicenses.findIndex(
      (l) => l.keyCode.trim().toLowerCase() === cleanKey.toLowerCase()
    );

    if (existingIndex !== -1) {
      const license = purchasedLicenses[existingIndex];
      if (license.status === 'revoked') {
        throw new Error('Key bản quyền này đã bị thu hồi hoặc khóa vĩnh viễn!');
      }

      // If user is claiming an unassigned or re-binding
      if (!license.hwid || license.hwid.includes('Chưa gán') || license.hwid.includes('Chưa kích hoạt')) {
        license.hwid = assignedHwid;
        license.status = 'active';
        if (userId && (!license.userId || license.userId.startsWith('guest'))) {
          license.userId = userId;
          license.userEmail = userEmail || license.userEmail;
        }
        purchasedLicenses[existingIndex] = license;
        this.set(STORAGE_KEYS.PURCHASED_LICENSES, purchasedLicenses);
        return {
          success: true,
          message: 'Kích hoạt gán thiết bị thành công! Key đã sẵn sàng sử dụng.',
          license,
          isNewClaim: false,
        };
      }

      // If already assigned HWID
      if (license.hwid.toLowerCase() === assignedHwid.toLowerCase()) {
        return {
          success: true,
          message: 'Key này đang được kích hoạt và hoạt động bình thường trên thiết bị này!',
          license,
          isNewClaim: false,
        };
      }

      // Different HWID
      return {
        success: true,
        message: `Key đã được kích hoạt trên thiết bị khác (HWID: ${license.hwid}). Sử dụng tính năng "Đổi Máy" nếu bạn muốn chuyển bản quyền sang máy này.`,
        license,
        isNewClaim: false,
      };
    }

    // 2. Check in Key Vault (available keys)
    const vault = this.getKeyVault();
    const vaultIndex = vault.findIndex(
      (k) => k.keyCode.trim().toLowerCase() === cleanKey.toLowerCase()
    );

    if (vaultIndex !== -1) {
      const keyRecord = vault[vaultIndex];
      if (keyRecord.status === 'revoked') {
        throw new Error('Key này đã bị vô hiệu hóa trong kho!');
      }

      const tools = this.getTools();
      const tool = tools.find((t) => t.id === keyRecord.toolId);
      const plan = tool?.plans.find((p) => p.id === keyRecord.planId);

      if (!tool || !plan) {
        throw new Error('Không tìm thấy thông tin sản phẩm tương ứng với Key này!');
      }

      // Mark vault key as sold
      keyRecord.status = 'sold';
      keyRecord.soldAt = new Date().toISOString();
      keyRecord.soldToUserId = userId || 'user_claimed';
      keyRecord.hwid = assignedHwid;
      this.set(STORAGE_KEYS.KEY_VAULT, vault);

      // Expiration
      let expiresAt = 'Lifetime';
      if (plan.durationDays < 90000) {
        const expDate = new Date();
        expDate.setDate(expDate.getDate() + plan.durationDays);
        expiresAt = expDate.toISOString();
      }

      const newLicense: PurchasedLicense = {
        id: `lic_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        orderId: `ACT-${Date.now().toString().slice(-6)}`,
        userId: userId || 'user_guest',
        userEmail: userEmail || 'support@toolstore.pro',
        toolId: tool.id,
        toolName: tool.name,
        toolIcon: tool.images[0] || '',
        planName: plan.name,
        durationDays: plan.durationDays,
        keyCode: keyRecord.keyCode,
        downloadUrl: tool.downloadUrl,
        version: tool.version,
        pricePaid: plan.salePrice,
        purchasedAt: new Date().toISOString(),
        expiresAt,
        status: 'active',
        hwid: assignedHwid,
        hwidResetsRemaining: 3,
        notes: 'Kích hoạt từ mã Key bản quyền',
      };

      purchasedLicenses.unshift(newLicense);
      this.set(STORAGE_KEYS.PURCHASED_LICENSES, purchasedLicenses);

      // Increment tool sold count
      const toolIdx = tools.findIndex((t) => t.id === tool.id);
      if (toolIdx >= 0) {
        tools[toolIdx].totalSold += 1;
        this.set(STORAGE_KEYS.TOOLS, tools);
      }

      // Notification
      if (userId) {
        this.addNotification({
          userId,
          title: `Kích hoạt thành công: ${tool.name}`,
          message: `Key ${newLicense.keyCode} (${plan.name}) đã được kích hoạt thành công trên máy ${assignedHwid}.`,
          type: 'key',
        });
      }

      return {
        success: true,
        message: 'Kích hoạt Key bản quyền thành công! Đã gán vào thiết bị và tài khoản của bạn.',
        license: newLicense,
        isNewClaim: true,
      };
    }

    throw new Error('Mã Key không tồn tại trên hệ thống máy chủ bản quyền hoặc đã bị xóa!');
  }

  resetHwid(licenseId: string, newHwid?: string): PurchasedLicense {
    const list = this.getPurchasedLicenses();
    const idx = list.findIndex((l) => l.id === licenseId);
    if (idx === -1) throw new Error('Không tìm thấy giấy phép này!');

    const license = list[idx];
    if (license.hwidResetsRemaining <= 0) {
      throw new Error('Bạn đã hết lượt đổi thiết bị (HWID Reset) cho Key này. Vui lòng liên hệ hỗ trợ!');
    }

    license.hwid = newHwid || `HWID-DEV-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    license.hwidResetsRemaining -= 1;
    list[idx] = license;
    this.set(STORAGE_KEYS.PURCHASED_LICENSES, list);
    return license;
  }

  // --- Top up Wallet ---
  topupWallet(params: {
    userId: string;
    amount: number;
    paymentMethod: 'vietqr' | 'momo' | 'banking';
    txRef?: string;
    description?: string;
  }): Transaction {
    const { userId, amount, paymentMethod, txRef, description } = params;
    const user = this.getUserById(userId);
    if (!user) throw new Error('Không tìm thấy tài khoản!');
    if (amount <= 0) throw new Error('Số tiền nạp phải lớn hơn 0 ₫!');

    const balanceBefore = user.balance;
    user.balance += amount;
    this.updateUser(user);

    const txCode = `TX${Math.floor(100000 + Math.random() * 900000)}`;
    const tx: Transaction = {
      id: `tx_${Date.now()}`,
      code: txCode,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      type: 'deposit',
      amount,
      balanceBefore,
      balanceAfter: user.balance,
      paymentMethod,
      status: 'completed',
      description: description || `Nạp tiền vào ví qua ${paymentMethod.toUpperCase()} (${txRef || 'Tự động'})`,
      createdAt: new Date().toISOString(),
      metadata: { txRef },
    };

    const transactions = this.getTransactions();
    transactions.unshift(tx);
    this.set(STORAGE_KEYS.TRANSACTIONS, transactions);

    this.addNotification({
      userId: user.id,
      title: `Nạp tiền thành công +${amount.toLocaleString('vi-VN')} ₫`,
      message: `Số dư ví của bạn hiện là ${user.balance.toLocaleString('vi-VN')} ₫.`,
      type: 'wallet',
    });

    return tx;
  }

  // --- Reseller Actions ---
  requestWithdrawal(params: {
    resellerId: string;
    amount: number;
    bankName: string;
    bankAccount: string;
    bankAccountName: string;
  }): WithdrawalRequest {
    const { resellerId, amount, bankName, bankAccount, bankAccountName } = params;
    const reseller = this.getUserById(resellerId);
    if (!reseller) throw new Error('Tài khoản đại lý không tồn tại!');
    if (amount < 200000) throw new Error('Số tiền rút tối thiểu là 200.000 ₫!');
    if (reseller.resellerWalletBalance < amount) {
      throw new Error('Số dư ví hoa hồng không đủ để rút!');
    }

    // Deduct reseller balance temporarily
    reseller.resellerWalletBalance -= amount;
    this.updateUser(reseller);

    const withdrawals = this.getWithdrawals();
    const newReq: WithdrawalRequest = {
      id: `wdr_${Date.now()}`,
      resellerId: reseller.id,
      resellerName: reseller.name,
      resellerEmail: reseller.email,
      amount,
      bankName,
      bankAccount,
      bankAccountName,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    withdrawals.unshift(newReq);
    this.set(STORAGE_KEYS.WITHDRAWALS, withdrawals);

    // Log transaction
    const transactions = this.getTransactions();
    transactions.unshift({
      id: `tx_wdr_${Date.now()}`,
      code: `TXW${Math.floor(100000 + Math.random() * 900000)}`,
      userId: reseller.id,
      userName: reseller.name,
      userEmail: reseller.email,
      type: 'withdrawal',
      amount: -amount,
      balanceBefore: reseller.resellerWalletBalance + amount,
      balanceAfter: reseller.resellerWalletBalance,
      paymentMethod: 'banking',
      status: 'pending',
      description: `Yêu cầu rút hoa hồng về ngân hàng ${bankName} (${bankAccount})`,
      createdAt: new Date().toISOString(),
    });
    this.set(STORAGE_KEYS.TRANSACTIONS, transactions);

    this.addNotification({
      userId: reseller.id,
      title: 'Yêu cầu rút tiền đã được tiếp nhận',
      message: `Yêu cầu rút ${amount.toLocaleString('vi-VN')} ₫ đang được Admin xử lý trong vòng 1-2 giờ làm việc.`,
      type: 'wallet',
    });

    return newReq;
  }

  approveWithdrawal(withdrawalId: string, note?: string): void {
    const withdrawals = this.getWithdrawals();
    const req = withdrawals.find((w) => w.id === withdrawalId);
    if (!req) throw new Error('Không tìm thấy yêu cầu rút tiền!');
    req.status = 'approved';
    req.processedAt = new Date().toISOString();
    req.adminNote = note || 'Admin đã duyệt và chuyển khoản thành công';
    this.set(STORAGE_KEYS.WITHDRAWALS, withdrawals);

    // Update tx status
    const txs = this.getTransactions();
    const tx = txs.find((t) => t.userId === req.resellerId && t.type === 'withdrawal' && t.status === 'pending');
    if (tx) {
      tx.status = 'completed';
      this.set(STORAGE_KEYS.TRANSACTIONS, txs);
    }

    this.addNotification({
      userId: req.resellerId,
      title: 'Rút tiền thành công 🎉',
      message: `Admin đã chuyển ${req.amount.toLocaleString('vi-VN')} ₫ về tài khoản ${req.bankName} (${req.bankAccount}).`,
      type: 'wallet',
    });
  }

  rejectWithdrawal(withdrawalId: string, note: string): void {
    const withdrawals = this.getWithdrawals();
    const req = withdrawals.find((w) => w.id === withdrawalId);
    if (!req) throw new Error('Không tìm thấy yêu cầu rút tiền!');
    req.status = 'rejected';
    req.processedAt = new Date().toISOString();
    req.adminNote = note || 'Yêu cầu bị từ chối do sai thông tin ngân hàng';
    this.set(STORAGE_KEYS.WITHDRAWALS, withdrawals);

    // Refund reseller balance
    const reseller = this.getUserById(req.resellerId);
    if (reseller) {
      reseller.resellerWalletBalance += req.amount;
      this.updateUser(reseller);

      this.addNotification({
        userId: req.resellerId,
        title: 'Yêu cầu rút tiền bị từ chối',
        message: `Số tiền ${req.amount.toLocaleString('vi-VN')} ₫ đã được hoàn về ví đại lý. Lý do: ${note}`,
        type: 'wallet',
      });
    }
  }

  getWithdrawals(resellerId?: string): WithdrawalRequest[] {
    const list = this.get<WithdrawalRequest[]>(STORAGE_KEYS.WITHDRAWALS, []);
    return resellerId ? list.filter((w) => w.resellerId === resellerId) : list;
  }

  // --- Admin User Management ---
  adjustUserBalance(userId: string, amount: number, reason: string): void {
    const user = this.getUserById(userId);
    if (!user) throw new Error('Không tìm thấy người dùng!');

    const before = user.balance;
    user.balance += amount;
    if (user.balance < 0) user.balance = 0;
    this.updateUser(user);

    const transactions = this.getTransactions();
    transactions.unshift({
      id: `tx_adj_${Date.now()}`,
      code: `TXA${Math.floor(100000 + Math.random() * 900000)}`,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      type: 'admin_adjustment',
      amount,
      balanceBefore: before,
      balanceAfter: user.balance,
      paymentMethod: 'wallet',
      status: 'completed',
      description: `Điều chỉnh số dư bởi Admin: ${reason}`,
      createdAt: new Date().toISOString(),
    });
    this.set(STORAGE_KEYS.TRANSACTIONS, transactions);

    this.addNotification({
      userId: user.id,
      title: 'Số dư ví đã được điều chỉnh',
      message: `Admin đã ${amount >= 0 ? 'cộng' : 'trừ'} ${Math.abs(amount).toLocaleString('vi-VN')} ₫ vào ví của bạn. Lý do: ${reason}`,
      type: 'wallet',
    });
  }

  setUserRole(userId: string, role: 'user' | 'reseller' | 'admin', tier?: ResellerTier, discountPercent?: number): void {
    const user = this.getUserById(userId);
    if (!user) throw new Error('Không tìm thấy người dùng!');

    user.role = role;
    if (role === 'reseller') {
      user.resellerStatus = 'approved';
      user.resellerTier = tier || 'silver';
      user.resellerDiscountPercent = discountPercent || (tier === 'diamond' ? 35 : tier === 'gold' ? 20 : 10);
    }
    this.updateUser(user);
  }

  toggleLockUser(userId: string): boolean {
    const user = this.getUserById(userId);
    if (!user) throw new Error('Không tìm thấy người dùng!');
    if (user.role === 'admin') throw new Error('Không thể khóa tài khoản Admin!');
    user.isLocked = !user.isLocked;
    this.updateUser(user);
    return user.isLocked;
  }

  // --- Transactions ---
  getTransactions(userId?: string): Transaction[] {
    const list = this.get<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    return userId ? list.filter((t) => t.userId === userId) : list;
  }

  // --- Reviews ---
  getReviews(toolId?: string): Review[] {
    const list = this.get<Review[]>(STORAGE_KEYS.REVIEWS, []);
    return toolId ? list.filter((r) => r.toolId === toolId) : list;
  }

  addReview(review: Omit<Review, 'id' | 'createdAt'>): Review {
    const reviews = this.getReviews();
    const newRev: Review = {
      ...review,
      id: `rev_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    reviews.unshift(newRev);
    this.set(STORAGE_KEYS.REVIEWS, reviews);
    return newRev;
  }

  // --- System Settings ---
  getSystemSettings(): SystemSettings {
    return this.get<SystemSettings>(STORAGE_KEYS.SYSTEM_SETTINGS, DEFAULT_SYSTEM_SETTINGS);
  }

  saveSystemSettings(settings: SystemSettings): void {
    this.set(STORAGE_KEYS.SYSTEM_SETTINGS, settings);
  }

  // --- Notifications ---
  getNotifications(userId?: string): NotificationItem[] {
    const list = this.get<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    return userId ? list.filter((n) => n.userId === userId) : list;
  }

  addNotification(notif: Omit<NotificationItem, 'id' | 'createdAt' | 'isRead'>): void {
    const list = this.getNotifications();
    list.unshift({
      ...notif,
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      isRead: false,
      createdAt: new Date().toISOString(),
    });
    this.set(STORAGE_KEYS.NOTIFICATIONS, list);
  }

  markAllNotificationsRead(userId: string): void {
    const list = this.getNotifications().map((n) => (n.userId === userId ? { ...n, isRead: true } : n));
    this.set(STORAGE_KEYS.NOTIFICATIONS, list);
  }
}

export const storage = new StorageService();
