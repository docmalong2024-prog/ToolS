export type UserRole = 'user' | 'reseller' | 'admin';

export type ResellerTier = 'silver' | 'gold' | 'diamond';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  balance: number; // VND
  resellerWalletBalance: number; // Profit/commission wallet for reseller
  resellerTier?: ResellerTier;
  resellerStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  resellerDiscountPercent?: number; // e.g., 15 for 15%
  resellerNote?: string;
  isLocked: boolean;
  createdAt: string;
  phone?: string;
  telegram?: string;
}

export type ToolCategory =
  | 'automation'
  | 'marketing_mmo'
  | 'ai_data'
  | 'games_utility'
  | 'developer'
  | 'seo_traffic';

export interface PricingPlan {
  id: string;
  duration: '1_month' | '3_months' | '6_months' | '1_year' | 'lifetime';
  name: string; // e.g., "1 Tháng", "Vĩnh Viễn"
  durationDays: number; // 30, 90, 180, 365, 99999
  originalPrice: number; // VND
  salePrice: number; // VND
  resellerPrice?: number; // Wholesale price for resellers
  badge?: string; // "Phổ biến nhất", "Tiết kiệm 40%"
}

export interface ToolItem {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  features: string[];
  category: ToolCategory;
  version: string;
  lastUpdated: string;
  downloadUrl: string;
  fileSize: string;
  osCompatibility: string[]; // ['Windows 10/11', 'macOS', 'Linux']
  requirements: string[];
  tutorialUrl?: string;
  videoDemoUrl?: string;
  images: string[];
  plans: PricingPlan[];
  tags: string[]; // ['Hot', 'Best Seller', 'New', 'Chống khóa acc', 'Tự động 24/7']
  rating: number; // 4.9
  reviewCount: number;
  totalSold: number;
  isActive: boolean;
  warningStockThreshold: number; // alert when available keys < this number
}

export type KeyStatus = 'available' | 'sold' | 'reserved' | 'revoked';

export interface LicenseKeyRecord {
  id: string;
  toolId: string;
  planId: string;
  keyCode: string;
  status: KeyStatus;
  createdAt: string;
  soldAt?: string;
  soldToUserId?: string;
  soldToOrderId?: string;
  hwid?: string;
  maxHwidResets?: number;
  hwidResetCount?: number;
  notes?: string;
}

export interface PurchasedLicense {
  id: string;
  orderId: string;
  userId: string;
  userEmail: string;
  toolId: string;
  toolName: string;
  toolIcon: string;
  planName: string;
  durationDays: number;
  keyCode: string;
  downloadUrl: string;
  version: string;
  pricePaid: number;
  purchasedAt: string;
  expiresAt: string; // ISO string or "Lifetime"
  status: 'active' | 'expiring_soon' | 'expired' | 'revoked';
  hwid?: string;
  hwidResetsRemaining: number;
  notes?: string;
  resellerClientId?: string; // If sold by a reseller
  resellerId?: string;
}

export type PaymentMethod = 'vietqr' | 'momo' | 'wallet' | 'banking';

export type TransactionType =
  | 'purchase'
  | 'deposit'
  | 'reseller_commission'
  | 'withdrawal'
  | 'admin_adjustment'
  | 'refund';

export type TransactionStatus = 'completed' | 'pending' | 'failed' | 'cancelled';

export interface Transaction {
  id: string;
  code: string; // e.g. "TX98234"
  userId: string;
  userName: string;
  userEmail: string;
  type: TransactionType;
  amount: number; // VND (+ or -)
  balanceBefore: number;
  balanceAfter: number;
  paymentMethod: PaymentMethod;
  status: TransactionStatus;
  description: string;
  createdAt: string;
  metadata?: {
    toolId?: string;
    toolName?: string;
    keyCount?: number;
    resellerId?: string;
    bankName?: string;
    bankAccount?: string;
    bankAccountName?: string;
    txRef?: string;
  };
}

export interface WithdrawalRequest {
  id: string;
  resellerId: string;
  resellerName: string;
  resellerEmail: string;
  amount: number;
  bankName: string;
  bankAccount: string;
  bankAccountName: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  processedAt?: string;
  adminNote?: string;
}

export interface Review {
  id: string;
  toolId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  createdAt: string;
  isVerifiedBuyer: boolean;
}

export interface CartItem {
  tool: ToolItem;
  plan: PricingPlan;
  quantity: number;
}

export interface SystemSettings {
  appName: string;
  slogan: string;
  logoUrl: string;
  brandColor: string; // Hex e.g., #00d2ff
  maintenanceMode: boolean;
  announcementBanner: {
    enabled: boolean;
    text: string;
    type: 'info' | 'warning' | 'promotion';
  };
  contactInfo: {
    hotline: string;
    telegram: string;
    zalo: string;
    email: string;
    workingHours: string;
  };
  paymentConfig: {
    vietqr: {
      bankId: string; // e.g., 'MB' | 'VCB' | 'ICB' | 'TCB'
      bankName: string; // MBBank Quân Đội
      accountNo: string;
      accountName: string;
      qrTemplate: string; // 'compact2' | 'compact'
    };
    momo: {
      phone: string;
      name: string;
    };
    autoApproveDeposits: boolean;
  };
  resellerPolicy: {
    silverDiscount: number; // %
    goldDiscount: number; // %
    diamondDiscount: number; // %
    minWithdrawalAmount: number; // VND
  };
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'key' | 'wallet' | 'reseller' | 'system';
  isRead: boolean;
  createdAt: string;
  link?: string;
}
