import React, { useState } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { SystemProvider, useSystem } from './contexts/SystemContext';

// Components
import { AnnouncementBanner } from './components/layout/AnnouncementBanner';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HeroBanner } from './components/customer/HeroBanner';
import { FlashSaleSection } from './components/customer/FlashSaleSection';
import { ToolCatalog } from './components/customer/ToolCatalog';
import { TestimonialsSection } from './components/customer/TestimonialsSection';
import { UserDashboard } from './components/customer/UserDashboard';
import { ResellerDashboard } from './components/reseller/ResellerDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';

// Modals & Drawers
import { AuthModal } from './components/auth/AuthModal';
import { CartDrawer } from './components/cart/CartDrawer';
import { WalletTopupModal } from './components/common/WalletTopupModal';
import { KeyValidatorModal } from './components/common/KeyValidatorModal';
import { RoiCalculatorModal } from './components/customer/RoiCalculatorModal';
import { CommandPaletteModal } from './components/common/CommandPaletteModal';
import { AppDownloadModal } from './components/common/AppDownloadModal';
import { LiveActivityTicker } from './components/common/LiveActivityTicker';
import { ToastContainer } from './components/common/ToastContainer';
import { FloatingZaloWidget } from './components/common/FloatingZaloWidget';
import { ToolCategory, ToolItem } from './types';

const MainAppContent: React.FC = () => {
  const {
    activeView,
    setActiveView,
    isRoiModalOpen,
    setIsRoiModalOpen,
    isCommandPaletteOpen,
    setIsCommandPaletteOpen
  } = useSystem();
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string>('');
  const [selectedCategoryFromHero, setSelectedCategoryFromHero] = useState<ToolCategory | 'all'>('all');
  const [selectedToolForDetail, setSelectedToolForDetail] = useState<ToolItem | null>(null);

  const handleHeroSelectCategory = (cat: string) => {
    setSelectedCategoryFromHero(cat as ToolCategory);
    setActiveView('catalog');
  };

  const handleSelectTool = (tool: ToolItem) => {
    setSelectedToolForDetail(tool);
    setActiveView('catalog');
  };

  return (
    <div className="min-h-screen bg-[#050505] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Announcement Banner */}
      <AnnouncementBanner />

      {/* Main Sticky Navbar */}
      <Navbar
        searchQuery={globalSearchQuery}
        onSearchChange={(q) => setGlobalSearchQuery(q)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {activeView === 'home' && (
          <div className="space-y-6">
            <HeroBanner
              searchQuery={globalSearchQuery}
              onSearchChange={(q) => setGlobalSearchQuery(q)}
              onSelectCategory={handleHeroSelectCategory}
            />

            {/* Flash Sale Section */}
            <FlashSaleSection onSelectTool={handleSelectTool} />

            {/* Catalog Grid Section */}
            <ToolCatalog
              initialCategory={selectedCategoryFromHero}
              searchQuery={globalSearchQuery}
              onSearchChange={(q) => setGlobalSearchQuery(q)}
            />

            {/* Testimonials & Reviews */}
            <TestimonialsSection />
          </div>
        )}

        {activeView === 'catalog' && (
          <ToolCatalog
            initialCategory={selectedCategoryFromHero}
            searchQuery={globalSearchQuery}
            onSearchChange={(q) => setGlobalSearchQuery(q)}
          />
        )}

        {activeView === 'user_dashboard' && <UserDashboard />}

        {activeView === 'reseller_dashboard' && <ResellerDashboard />}

        {activeView === 'admin_dashboard' && <AdminDashboard />}
      </main>

      {/* Footer */}
      <Footer />

      {/* Global Modals & Drawers */}
      <AuthModal />
      <CartDrawer />
      <WalletTopupModal />
      <KeyValidatorModal />
      <RoiCalculatorModal
        isOpen={isRoiModalOpen}
        onClose={() => setIsRoiModalOpen(false)}
      />
      <CommandPaletteModal
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectTool={handleSelectTool}
      />
      <AppDownloadModal />
      <LiveActivityTicker />
      <ToastContainer />
      <FloatingZaloWidget />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <SystemProvider>
        <CartProvider>
          <MainAppContent />
        </CartProvider>
      </SystemProvider>
    </AuthProvider>
  );
}
