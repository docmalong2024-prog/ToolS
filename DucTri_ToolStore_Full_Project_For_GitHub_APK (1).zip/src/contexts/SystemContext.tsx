import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { SystemSettings } from '../types';
import { storage, DEFAULT_SYSTEM_SETTINGS } from '../services/storage';

export interface Toast {
  id: string;
  title: string;
  message?: string;
  type: 'success' | 'error' | 'info' | 'warning';
  duration?: number;
}

interface SystemContextType {
  settings: SystemSettings;
  updateSettings: (newSettings: SystemSettings) => void;
  toasts: Toast[];
  showToast: (title: string, message?: string, type?: 'success' | 'error' | 'info' | 'warning', duration?: number) => void;
  removeToast: (id: string) => void;
  formatVND: (amount: number) => string;
  formatDate: (dateStr: string) => string;
  activeView: 'home' | 'catalog' | 'user_dashboard' | 'reseller_dashboard' | 'admin_dashboard';
  setActiveView: (view: 'home' | 'catalog' | 'user_dashboard' | 'reseller_dashboard' | 'admin_dashboard') => void;
  isKeyValidatorOpen: boolean;
  setIsKeyValidatorOpen: (open: boolean) => void;
  keyValidatorInitialTab: 'activate' | 'validate';
  openKeyValidator: (tab?: 'activate' | 'validate') => void;
  isTopupModalOpen: boolean;
  setIsTopupModalOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isRoiModalOpen: boolean;
  setIsRoiModalOpen: (open: boolean) => void;
  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;
  isAppDownloadModalOpen: boolean;
  setIsAppDownloadModalOpen: (open: boolean) => void;
}

const SystemContext = createContext<SystemContextType | undefined>(undefined);

export const SystemProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SYSTEM_SETTINGS);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [activeView, setActiveView] = useState<'home' | 'catalog' | 'user_dashboard' | 'reseller_dashboard' | 'admin_dashboard'>('home');
  const [isKeyValidatorOpen, setIsKeyValidatorOpen] = useState(false);
  const [keyValidatorInitialTab, setKeyValidatorInitialTab] = useState<'activate' | 'validate'>('activate');
  const [isTopupModalOpen, setIsTopupModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isRoiModalOpen, setIsRoiModalOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isAppDownloadModalOpen, setIsAppDownloadModalOpen] = useState(false);

  // Global Ctrl+K / Cmd+K listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const openKeyValidator = useCallback((tab: 'activate' | 'validate' = 'activate') => {
    setKeyValidatorInitialTab(tab);
    setIsKeyValidatorOpen(true);
  }, []);

  const loadSettings = useCallback(() => {
    setSettings(storage.getSystemSettings());
  }, []);

  useEffect(() => {
    loadSettings();
    const handleUpdate = () => loadSettings();
    window.addEventListener('toolstore_storage_update', handleUpdate);
    return () => window.removeEventListener('toolstore_storage_update', handleUpdate);
  }, [loadSettings]);

  const updateSettings = (newSettings: SystemSettings) => {
    storage.saveSystemSettings(newSettings);
    setSettings(newSettings);
    showToast('Đã lưu cấu hình hệ thống thành công', 'Cài đặt giao diện & cổng thanh toán đã được áp dụng.', 'success');
  };

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback(
    (title: string, message?: string, type: 'success' | 'error' | 'info' | 'warning' = 'info', duration = 4000) => {
      const id = `toast_${Date.now()}_${Math.random()}`;
      const newToast: Toast = { id, title, message, type, duration };
      setToasts((prev) => [...prev, newToast]);

      setTimeout(() => {
        removeToast(id);
      }, duration);
    },
    [removeToast]
  );

  const formatVND = (amount: number): string => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(amount);
  };

  const formatDate = (dateStr: string): string => {
    if (!dateStr || dateStr === 'Lifetime') return 'Vĩnh viễn';
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <SystemContext.Provider
      value={{
        settings,
        updateSettings,
        toasts,
        showToast,
        removeToast,
        formatVND,
        formatDate,
        activeView,
        setActiveView,
        isKeyValidatorOpen,
        setIsKeyValidatorOpen,
        keyValidatorInitialTab,
        openKeyValidator,
        isTopupModalOpen,
        setIsTopupModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isRoiModalOpen,
        setIsRoiModalOpen,
        isCommandPaletteOpen,
        setIsCommandPaletteOpen,
        isAppDownloadModalOpen,
        setIsAppDownloadModalOpen,
      }}
    >
      {children}
    </SystemContext.Provider>
  );
};

export const useSystem = () => {
  const context = useContext(SystemContext);
  if (!context) throw new Error('useSystem must be used within a SystemProvider');
  return context;
};
