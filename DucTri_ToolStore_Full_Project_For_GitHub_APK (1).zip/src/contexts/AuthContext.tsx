import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, UserRole, NotificationItem } from '../types';
import { storage } from '../services/storage';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isReseller: boolean;
  isCustomer: boolean;
  login: (email: string) => void;
  register: (name: string, email: string, role?: 'user' | 'reseller') => void;
  logout: () => void;
  switchDemoUser: (role: 'user' | 'reseller' | 'admin') => void;
  updateProfile: (data: Partial<User>) => void;
  refreshUserData: () => void;
  notifications: NotificationItem[];
  unreadNotifsCount: number;
  markNotificationsAsRead: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const loadUserData = useCallback(() => {
    try {
      const user = storage.getCurrentUser();
      setCurrentUser(user);
      if (user) {
        setNotifications(storage.getNotifications(user.id));
      }
    } catch (e) {
      console.error('Failed to load user data', e);
    }
  }, []);

  useEffect(() => {
    loadUserData();
    const handleStorageUpdate = () => {
      loadUserData();
    };
    window.addEventListener('toolstore_storage_update', handleStorageUpdate);
    return () => window.removeEventListener('toolstore_storage_update', handleStorageUpdate);
  }, [loadUserData]);

  const login = (email: string) => {
    const user = storage.loginUser(email);
    setCurrentUser(user);
    loadUserData();
  };

  const register = (name: string, email: string, role: 'user' | 'reseller' = 'user') => {
    const user = storage.registerUser(name, email, role);
    setCurrentUser(user);
    loadUserData();
  };

  const logout = () => {
    // Default back to regular user demo
    storage.setCurrentUser('user_customer');
    loadUserData();
  };

  const switchDemoUser = (role: 'user' | 'reseller' | 'admin') => {
    if (role === 'admin') {
      storage.setCurrentUser('user_admin');
    } else if (role === 'reseller') {
      storage.setCurrentUser('user_reseller_gold');
    } else {
      storage.setCurrentUser('user_customer');
    }
    loadUserData();
  };

  const updateProfile = (data: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...data };
    storage.updateUser(updated);
    setCurrentUser(updated);
  };

  const markNotificationsAsRead = () => {
    if (!currentUser) return;
    storage.markAllNotificationsRead(currentUser.id);
    setNotifications(storage.getNotifications(currentUser.id));
  };

  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        isAdmin: currentUser?.role === 'admin',
        isReseller: currentUser?.role === 'reseller',
        isCustomer: currentUser?.role === 'user',
        login,
        register,
        logout,
        switchDemoUser,
        updateProfile,
        refreshUserData: loadUserData,
        notifications,
        unreadNotifsCount,
        markNotificationsAsRead,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
