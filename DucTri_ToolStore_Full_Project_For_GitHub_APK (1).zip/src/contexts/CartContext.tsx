import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, ToolItem, PricingPlan } from '../types';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (tool: ToolItem, plan: PricingPlan, quantity?: number) => void;
  removeFromCart: (toolId: string, planId: string) => void;
  updateQuantity: (toolId: string, planId: string, quantity: number) => void;
  clearCart: () => void;
  totalAmount: number;
  totalOriginalAmount: number;
  totalSavings: number;
  totalItemsCount: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('toolstore_cart_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('toolstore_cart_v1', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (tool: ToolItem, plan: PricingPlan, quantity: number = 1) => {
    setCartItems((prev) => {
      const existingIdx = prev.findIndex(
        (item) => item.tool.id === tool.id && item.plan.id === plan.id
      );
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        return updated;
      }
      return [...prev, { tool, plan, quantity }];
    });
  };

  const removeFromCart = (toolId: string, planId: string) => {
    setCartItems((prev) =>
      prev.filter((item) => !(item.tool.id === toolId && item.plan.id === planId))
    );
  };

  const updateQuantity = (toolId: string, planId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(toolId, planId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.tool.id === toolId && item.plan.id === planId
          ? { ...item, quantity }
          : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const totalAmount = cartItems.reduce(
    (sum, item) => sum + item.plan.salePrice * item.quantity,
    0
  );

  const totalOriginalAmount = cartItems.reduce(
    (sum, item) => sum + item.plan.originalPrice * item.quantity,
    0
  );

  const totalSavings = totalOriginalAmount - totalAmount;

  const totalItemsCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalAmount,
        totalOriginalAmount,
        totalSavings,
        totalItemsCount,
        isCartOpen,
        setIsCartOpen,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
};
